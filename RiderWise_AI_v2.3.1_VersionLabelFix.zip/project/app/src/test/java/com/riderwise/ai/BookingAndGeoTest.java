package com.riderwise.ai;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

public class BookingAndGeoTest {
    @Test public void fareComponentsRemainSeparate() {
        Booking b = new Booking("San Mateo", "Quezon Avenue", 184, 34, Double.NaN, .9f, 1, 2);
        assertEquals(184, b.baseFare, .001); assertEquals(34, b.additionalFare, .001);
        assertEquals(218, b.totalFare, .001); assertTrue(BookingValidator.isValid(b));
    }
    @Test public void displayedFarePairIsParsedIntoSeparateComponents() {
        BookingExtractor.FareComponents fare = BookingExtractor.parseFareComponents("₱184.00 + ₱34.00");
        assertNotNull(fare); assertEquals(184, fare.baseFare, .001);
        assertEquals(34, fare.additionalFare, .001); assertEquals(218, fare.totalFare, .001);
    }
    @Test public void accentAndCaseInsensitiveAliasesResolve() {
        assertNotNull(GeographicDataset.get("QC")); assertNotNull(GeographicDataset.get("quezon city"));
        assertNotNull(GeographicDataset.get("Sta. Rosa"));
        assertEquals("dasmarinas", BookingValidator.normalize("Dasmariñas"));
    }
    @Test public void unknownOrUnverifiedCoordinatesRemainUnresolved() {
        assertNull(GeographicDataset.get("Imaginary Municipality"));
        assertNull(GeographicDataset.get("Puerto Princesa"));
    }
    @Test public void differentPickupCanBeAlongTheWay() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .9f, 1);
        Booking candidate = new Booking("Batasan", "Diliman", 80, Double.NaN, .9f, 1);
        assertNotNull(new RouteCompatibilityEngine().evaluate(ref, candidate));
    }
    @Test public void incompleteBookingRejected() {
        assertFalse(BookingValidator.isValid(new Booking("", "Quezon Avenue", 100, Double.NaN, .9f, 1)));
    }
    @Test public void fareTotalMustEqualSeparatedComponents() {
        Booking b = new Booking("San Mateo", "Quezon Avenue", 184, 34, Double.NaN, .9f, 1, 2);
        b.totalFare = 199;
        assertFalse(BookingValidator.isValid(b));
    }
    @Test public void recommendationUsesPickupBeforeDropoffSequence() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking extra = new Booking("Batasan", "Diliman", 80, Double.NaN, .90f, 2);
        List<RecommendationEngine.Recommendation> results =
                new RecommendationEngine().recommend(Arrays.asList(ref, extra), ref);
        assertFalse(results.isEmpty());
        assertTrue(results.get(0).sequence.indexOf("PICKUP Batasan") < results.get(0).sequence.indexOf("DROP Diliman"));
        assertEquals(264, results.get(0).totalFare, .001);
    }
    @Test public void referenceBookingIsNotReplacedByDuplicateCandidate() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking duplicate = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 2);
        assertEquals(ref.fingerprint, duplicate.fingerprint);
        assertEquals(ref.id, duplicate.id);
    }
}
