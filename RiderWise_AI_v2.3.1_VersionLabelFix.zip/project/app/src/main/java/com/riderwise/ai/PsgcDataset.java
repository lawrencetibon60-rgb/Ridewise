package com.riderwise.ai;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** PSA PSGC administrative index. PSGC does not contain latitude/longitude. */
public final class PsgcDataset {
    public static final String VERSION = "PSGC-3Q-2026";
    public static final class Record {
        public final String psgc, name, level, parentPsgc, oldNames, cityClass, incomeClassification, urbanRural, status;
        public final long population2024;
        private Record(JSONObject o) {
            psgc=o.optString("psgc", ""); name=o.optString("name", ""); level=o.optString("level", "");
            parentPsgc=o.isNull("parentPsgc")?null:o.optString("parentPsgc", null);
            oldNames=o.isNull("oldNames")?null:o.optString("oldNames", null);
            cityClass=o.optString("cityClass", ""); incomeClassification=o.optString("incomeClassification", "");
            urbanRural=o.optString("urbanRural", ""); status=o.optString("status", "");
            population2024=o.optLong("population2024", -1L);
        }
        public String displayLevel() {
            switch(level) { case "Reg": return "Region"; case "Prov": return "Province"; case "City": return "City";
                case "Mun": return "Municipality"; case "SubMun": return "Sub-municipality"; case "Bgy": return "Barangay"; default:return level; }
        }
    }
    private static final Map<String,Record> BY_CODE = new LinkedHashMap<>();
    private static final Map<String,List<Record>> BY_NAME = new HashMap<>();
    private static final Map<String,String> PARENT_NAMES = new HashMap<>();
    private static volatile boolean loaded;
    private static volatile String loadError;
    private PsgcDataset() {}

    public static synchronized void initialize(Context context) {
        if (loaded) return;
        try (GZIPInputStream in = new GZIPInputStream(context.getAssets().open("luzon_psgc_3q_2026.json.gz"));
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            StringBuilder json = new StringBuilder(); char[] buf = new char[8192]; int n;
            while ((n=reader.read(buf))!=-1) json.append(buf,0,n);
            JSONObject root = new JSONObject(json.toString()); JSONArray records = root.getJSONArray("records");
            for (int i=0;i<records.length();i++) {
                Record r = new Record(records.getJSONObject(i));
                if (r.psgc.isEmpty() || r.name.isEmpty()) continue;
                BY_CODE.put(r.psgc,r);
                addName(r.name,r);
                if (r.name.startsWith("City of ")) addName(r.name.substring(8),r);
                if (r.name.startsWith("Municipality of ")) addName(r.name.substring(16),r);
                if (r.oldNames!=null && !r.oldNames.trim().isEmpty()) addName(r.oldNames,r);
            }
            for (Record r: BY_CODE.values()) {
                Record parent = r.parentPsgc==null?null:BY_CODE.get(r.parentPsgc);
                if(parent!=null) PARENT_NAMES.put(r.psgc,parent.name);
            }
            loaded=true;
        } catch (Exception e) {
            BY_CODE.clear(); BY_NAME.clear(); PARENT_NAMES.clear();
            loadError=e.getClass().getSimpleName()+": "+e.getMessage();
        }
    }
    private static void addName(String name, Record r) {
        String key=normalize(name); if(key.isEmpty()) return;
        List<Record> list=BY_NAME.computeIfAbsent(key,k->new ArrayList<>());
        if(!list.contains(r)) list.add(r);
    }
    private static String normalize(String s) {
        return BookingValidator.normalize(s).replaceAll("[^a-z0-9]", "");
    }
    public static boolean isLoaded(){return loaded;}
    public static String getLoadError(){return loadError;}
    public static int size(){return BY_CODE.size();}
    public static Record byPsgc(String code){return BY_CODE.get(code==null?"":code.trim());}
    public static Record resolve(String name) {
        List<Record> found=BY_NAME.get(normalize(name));
        return found==null||found.size()!=1?null:found.get(0);
    }
    public static String canonicalize(String name) {
        Record r=resolve(name); return r==null?name:r.name;
    }
    public static Record resolve(String name, String parentName) {
        List<Record> found=BY_NAME.get(normalize(name)); if(found==null)return null;
        if(parentName!=null) for(Record r:found) {
            Record parent=r.parentPsgc==null?null:BY_CODE.get(r.parentPsgc);
            while(parent!=null) {
                if(normalize(parentName).equals(normalize(parent.name))) return r;
                parent=parent.parentPsgc==null?null:BY_CODE.get(parent.parentPsgc);
            }
        }
        return found.size()==1?found.get(0):null;
    }
    public static List<Record> search(String query, int limit) {
        if(query==null||query.trim().length()<2||limit<1)return Collections.emptyList();
        String q=normalize(query); List<Record> out=new ArrayList<>();
        for(Record r:BY_CODE.values()) {
            if(normalize(r.name).contains(q) || (r.oldNames!=null&&normalize(r.oldNames).contains(q))) {
                out.add(r); if(out.size()>=limit)break;
            }
        }
        return out;
    }
    public static String hierarchy(Record r) {
        if(r==null)return ""; List<String> parts=new ArrayList<>(); Record p=r;
        while(p!=null){parts.add(0,p.name);p=p.parentPsgc==null?null:BY_CODE.get(p.parentPsgc);}
        return android.text.TextUtils.join(" / ",parts);
    }
    public static Map<String,Integer> countsByLevel() {
        Map<String,Integer> out=new LinkedHashMap<>();
        for(Record r:BY_CODE.values()) out.put(r.displayLevel(),out.containsKey(r.displayLevel())?out.get(r.displayLevel())+1:1);
        return Collections.unmodifiableMap(out);
    }
}
