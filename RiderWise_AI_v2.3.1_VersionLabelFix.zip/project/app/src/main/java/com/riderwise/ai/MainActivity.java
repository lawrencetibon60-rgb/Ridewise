package com.riderwise.ai;
import android.app.*;import android.content.*;import android.os.*;import android.provider.Settings;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 private TextView status,mode;private android.content.SharedPreferences prefs;
 @Override protected void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(FloatingAssistantService.PREFS,0);
  PsgcDataset.initialize(getApplicationContext());
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,32,24,24);root.setBackgroundColor(0xFFF7F7F7);
  TextView title=new TextView(this);title.setText("RiderWise AI v2.3.1");title.setTextSize(25);title.setTextColor(0xFF202124);
  TextView sub=new TextView(this);sub.setText("Live Lalamove OCR • Luzon PSGC geographic index");sub.setTextSize(14);
  TextView geo=new TextView(this);geo.setText("Geographic index: "+(PsgcDataset.isLoaded()?PsgcDataset.size()+" PSA records ("+PsgcDataset.VERSION+")":"not loaded — "+PsgcDataset.getLoadError()));geo.setPadding(0,8,0,8);
  status=new TextView(this);status.setText("Status: Monitoring state is controlled by Android service");status.setPadding(0,20,0,12);
  mode=new TextView(this);updateModeLabel();
  Button toggle=new Button(this);toggle.setText("Toggle Ride Mode ON / OFF");toggle.setOnClickListener(v->{boolean next=!prefs.getBoolean(FloatingAssistantService.KEY_RIDE,false);prefs.edit().putBoolean(FloatingAssistantService.KEY_RIDE,next).apply();updateModeLabel();FloatingAssistantService.refreshMode(this);});
  Button overlay=new Button(this);overlay.setText("Show floating dashboard");overlay.setOnClickListener(v->{prefs.edit().putBoolean(FloatingAssistantService.KEY_VISIBLE,true).apply();if(!Settings.canDrawOverlays(this))PermissionManager.requestOverlay(this);else startService(new Intent(this,FloatingAssistantService.class));});
  Button hide=new Button(this);hide.setText("Hide floating dashboard");hide.setOnClickListener(v->{prefs.edit().putBoolean(FloatingAssistantService.KEY_VISIBLE,false).apply();stopService(new Intent(this,FloatingAssistantService.class));});
  Button start=new Button(this);start.setText("Authorize and start live screen monitoring");start.setOnClickListener(v->startActivityForResult(PermissionManager.captureIntent(this),PermissionManager.REQUEST_CAPTURE));
  Button stop=new Button(this);stop.setText("Stop monitoring");stop.setOnClickListener(v->{stopService(new Intent(this,ScreenCaptureService.class));status.setText("Status: Stopped");});
  TextView note=new TextView(this);note.setText("Safety: RiderWise is read-only and never accepts bookings. Use only while safely parked. Android/ColorOS may interrupt background capture. The five-second interval is a target, not a guarantee.");note.setTextSize(12);note.setPadding(0,22,0,0);
  root.addView(title);root.addView(sub);root.addView(geo);root.addView(status);root.addView(mode);root.addView(toggle);root.addView(overlay);root.addView(hide);root.addView(start);root.addView(stop);root.addView(note);setContentView(root);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 5101);
  if(prefs.getBoolean(FloatingAssistantService.KEY_VISIBLE,false)&&Settings.canDrawOverlays(this))
      startService(new Intent(this,FloatingAssistantService.class));
 }
 @Override protected void onResume(){super.onResume();if(prefs!=null){updateModeLabel();if(prefs.getBoolean(FloatingAssistantService.KEY_VISIBLE,false)&&Settings.canDrawOverlays(this))startService(new Intent(this,FloatingAssistantService.class));}}
 private void updateModeLabel(){mode.setText(prefs.getBoolean(FloatingAssistantService.KEY_RIDE,false)?"Ride Mode: ON (compact, non-interactive)":"Ride Mode: OFF (parked-use interaction)");}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PermissionManager.REQUEST_CAPTURE&&c==RESULT_OK&&d!=null){Intent i=new Intent(this,ScreenCaptureService.class);i.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE,c);i.putExtra(ScreenCaptureService.EXTRA_DATA,d);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);status.setText("Status: Live capture authorization granted; service starting");}else status.setText("Status: Capture permission not granted");}
}
