package com.riderwise.ai;

/** Route comparison uses great-circle estimates only; it never reports road distance or travel time. */
public class RouteCompatibilityEngine {
    public static final class Result {
        public final String label;
        public final double score, deviationKm;
        public final boolean feasible;
        public final String basis;
        Result(String label, double score, double deviationKm, boolean feasible) {
            this.label=label; this.score=score; this.deviationKm=deviationKm; this.feasible=feasible;
            this.basis="STRAIGHT-LINE GEOGRAPHIC ESTIMATE; NOT ROAD ROUTING";
        }
    }

    public Result evaluate(Booking reference, Booking candidate) {
        if (!BookingValidator.isValid(reference) || !BookingValidator.isValid(candidate))
            return new Result("INCOMPATIBLE", 0d, Double.NaN, false);
        GeographicDataset.Point start=GeographicDataset.get(reference.pickup);
        GeographicDataset.Point end=GeographicDataset.get(reference.dropoff);
        GeographicDataset.Point pickup=GeographicDataset.get(candidate.pickup);
        GeographicDataset.Point drop=GeographicDataset.get(candidate.dropoff);
        if (start==null||end==null||pickup==null||drop==null)
            return new Result("POSSIBLE COMPATIBILITY",0.25d,Double.NaN,false);

        double routeLength=GeoMatcher.distanceKm(start,end);
        double pickupDeviation=GeoMatcher.progress(start,end,pickup);
        double dropDeviation=GeoMatcher.progress(start,end,drop);
        double pickupProgress=GeoMatcher.distanceKm(start,pickup);
        double dropProgress=GeoMatcher.distanceKm(start,drop);
        double candidateLength=GeoMatcher.distanceKm(pickup,drop);
        double deviation=Math.max(pickupDeviation,dropDeviation);
        if (!Double.isFinite(routeLength)||!Double.isFinite(candidateLength)||routeLength<0.1d)
            return new Result("POSSIBLE COMPATIBILITY",0.2d,Double.NaN,false);
        if (candidateLength>60d || pickupProgress>Math.max(65d,routeLength+35d))
            return new Result("INCOMPATIBLE",0.03d,deviation,false);
        if (dropProgress+3d<pickupProgress)
            return new Result("REVERSE DIRECTION",0.10d,deviation,false);
        if (pickupProgress>routeLength+20d || pickupDeviation>20d || dropDeviation>25d)
            return new Result("EXCESSIVE BACKTRACKING",0.08d,deviation,false);
        if (pickupDeviation<=2d&&dropDeviation<=2d)
            return new Result("SAME ROUTE",0.95d,deviation,true);
        if (pickupDeviation<=5d&&dropDeviation<=7d)
            return new Result("ALONG THE WAY",0.82d,deviation,true);
        if (pickupDeviation<=10d||dropDeviation<=10d)
            return new Result("NEAR THE ROUTE",0.60d,deviation,true);
        return new Result("POSSIBLE COMPATIBILITY",0.30d,deviation,false);
    }
}
