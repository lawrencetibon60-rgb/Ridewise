package com.riderwise.ai;

import android.graphics.Bitmap;
import android.util.Log;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Single-flight ML Kit OCR processor; every accepted bitmap is released exactly once. */
public class OcrProcessor {
    public interface Callback { void onResult(List<Booking> bookings); }
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private final BookingExtractor extractor = new BookingExtractor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean closed;
    private volatile int lastDetectedCardCount;

    public int getLastDetectedCardCount() { return lastDetectedCardCount; }

    public boolean process(Bitmap bitmap, Callback callback) {
        if (bitmap == null || callback == null || closed || !busy.compareAndSet(false, true)) {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            return false;
        }
        try {
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            recognizer.process(image)
                    .addOnSuccessListener(text -> {
                        List<Booking> found = extractor.extract(text);
                        lastDetectedCardCount = extractor.getLastDetectedCardCount();
                        deliver(callback, found);
                    })
                    .addOnFailureListener(error -> {
                        Log.e("RiderWise", "ML Kit text recognition failed", error);
                        lastDetectedCardCount = 0;
                        deliver(callback, Collections.emptyList());
                    })
                    .addOnCompleteListener(task -> {
                        if (!bitmap.isRecycled()) bitmap.recycle();
                        busy.set(false);
                    });
            return true;
        } catch (RuntimeException error) {
            Log.e("RiderWise", "Unable to start OCR task", error);
            if (!bitmap.isRecycled()) bitmap.recycle();
            busy.set(false);
            return false;
        }
    }

    private static void deliver(Callback callback, List<Booking> bookings) {
        try { callback.onResult(bookings); }
        catch (RuntimeException error) { Log.e("RiderWise", "OCR result callback failed", error); }
    }

    public boolean isBusy() { return busy.get(); }
    public void close() {
        closed = true;
        recognizer.close();
    }
}
