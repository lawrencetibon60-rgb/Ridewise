package com.riderwise.ai;

import java.text.Normalizer;
import java.util.Locale;
import java.util.UUID;
import java.nio.charset.StandardCharsets;

public class Booking {
    public String id, pickup, dropoff, fingerprint, status;
    public double baseFare, additionalFare, totalFare, pickupDistanceKm;
    public float confidence;
    public long firstDetectedAt, lastDetectedAt;
    public boolean reference;

    public Booking(String pickup, String dropoff, double fare, double pickupDistanceKm,
                   float confidence, long detectedAt) {
        this(pickup, dropoff, fare, 0d, pickupDistanceKm, confidence, detectedAt, detectedAt);
    }
    public Booking(String pickup, String dropoff, double baseFare, double additionalFare,
                   double pickupDistanceKm, float confidence, long firstDetectedAt, long lastDetectedAt) {
        this.pickup=pickup; this.dropoff=dropoff; this.baseFare=baseFare;
        this.additionalFare=additionalFare; this.totalFare=baseFare+additionalFare; this.fare=this.totalFare;
        this.pickupDistanceKm=pickupDistanceKm; this.confidence=confidence;
        this.firstDetectedAt=firstDetectedAt; this.lastDetectedAt=lastDetectedAt;
        this.detectedAt=lastDetectedAt; this.status="DETECTED";
        this.fingerprint=fingerprint(pickup,dropoff,baseFare,additionalFare);
        this.id=UUID.nameUUIDFromBytes(fingerprint.getBytes(StandardCharsets.UTF_8)).toString();
    }
    @Deprecated public double fare;
    @Deprecated public long detectedAt;
    public static String fingerprint(String p,String d,double base,double extra) {
        return norm(p)+"|"+norm(d)+"|"+String.format(Locale.US,"%.2f|%.2f",base,extra);
    }
    private static String norm(String s) {
        if(s==null)return "";
        return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}+","")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim().replaceAll("\\s+"," ");
    }
}
