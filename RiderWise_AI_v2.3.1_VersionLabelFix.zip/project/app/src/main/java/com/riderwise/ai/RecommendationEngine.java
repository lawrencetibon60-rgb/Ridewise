package com.riderwise.ai;

import java.util.*;

/** Bounded exhaustive search for valid pickup-before-dropoff sequences (2 to 7 total bookings). */
public class RecommendationEngine {
    private static final int MAX_CANDIDATES = 10;
    private static final int MAX_COMBINATION_NODES = 6000;
    private static final int MAX_RESULTS = 30;
    public static class Recommendation {
        public final List<Booking> bookings;
        public final double totalFare, score, detourKm;
        public final String compatibility, sequence;
        Recommendation(List<Booking> bookings,double fare,double score,String label,String sequence,double detour) {
            this.bookings=Collections.unmodifiableList(new ArrayList<>(bookings));
            this.totalFare=fare; this.score=score; this.compatibility=label; this.sequence=sequence; this.detourKm=detour;
        }
    }
    private static final class Search {
        double bestDistance=Double.POSITIVE_INFINITY;
        String bestSequence="";
        int nodes;
    }
    private final RouteCompatibilityEngine matcher=new RouteCompatibilityEngine();

    public List<Recommendation> recommend(List<Booking> all, Booking reference) {
        if (reference==null||!BookingValidator.isValid(reference)||all==null) return Collections.emptyList();
        List<Booking> candidates=new ArrayList<>(); Set<String> seen=new HashSet<>();
        for (Booking b:all) {
            if (b==null||!BookingValidator.isValid(b)||b.fingerprint.equals(reference.fingerprint)) continue;
            if (seen.add(b.fingerprint)) candidates.add(b);
        }
        candidates.sort((a,b)->{
            int c=Float.compare(b.confidence,a.confidence);
            return c!=0?c:Long.compare(b.lastDetectedAt,a.lastDetectedAt);
        });
        if (candidates.size()>MAX_CANDIDATES) candidates=new ArrayList<>(candidates.subList(0,MAX_CANDIDATES));

        List<Recommendation> out=new ArrayList<>(); Set<String> combinationKeys=new HashSet<>();
        enumerate(candidates,0,new ArrayList<>(),reference,out,combinationKeys);
        out.sort((a,b)->Double.compare(b.score,a.score));
        return new ArrayList<>(out.subList(0,Math.min(MAX_RESULTS,out.size())));
    }

    private void enumerate(List<Booking> source,int index,List<Booking> chosen,Booking reference,
                           List<Recommendation> out,Set<String> combinationKeys) {
        if (!chosen.isEmpty()) evaluate(chosen,reference,out,combinationKeys);
        if (chosen.size()>=6) return; // reference + at most six candidates = seven bookings
        for (int i=index;i<source.size();i++) {
            chosen.add(source.get(i));
            enumerate(source,i+1,chosen,reference,out,combinationKeys);
            chosen.remove(chosen.size()-1);
        }
    }

    private void evaluate(List<Booking> chosen,Booking reference,List<Recommendation> out,Set<String> keys) {
        List<String> ids=new ArrayList<>();
        for (Booking b:chosen) ids.add(b.fingerprint);
        Collections.sort(ids);
        String key=String.join("||",ids);
        if (!keys.add(key)) return;

        GeographicDataset.Point start=GeographicDataset.get(reference.dropoff);
        if (start==null) return;
        for (Booking b:chosen) if (GeographicDataset.get(b.pickup)==null||GeographicDataset.get(b.dropoff)==null) return;

        Search search=new Search();
        dfs(chosen,new boolean[chosen.size()],new boolean[chosen.size()],start,0d,new ArrayList<>(),search);
        if (search.bestSequence.isEmpty()||!Double.isFinite(search.bestDistance)) return;

        double fare=reference.totalFare, base=reference.baseFare, extra=reference.additionalFare;
        double confidence=reference.confidence, baseline=0d, compatibilityScore=0d, worstDeviation=0d;
        String label="SAME ROUTE";
        for (Booking b:chosen) {
            fare+=b.totalFare; base+=b.baseFare; extra+=b.additionalFare; confidence+=b.confidence;
            baseline+=GeoMatcher.distanceKm(GeographicDataset.get(b.pickup),GeographicDataset.get(b.dropoff));
            RouteCompatibilityEngine.Result r=matcher.evaluate(reference,b);
            compatibilityScore+=r.score;
            if (Double.isFinite(r.deviationKm)) worstDeviation=Math.max(worstDeviation,r.deviationKm);
            if (!r.feasible) label=r.label;
            else if ("SAME ROUTE".equals(label)&&!"SAME ROUTE".equals(r.label)) label=r.label;
        }
        double detour=Math.max(0d,search.bestDistance-baseline);
        double avgConfidence=confidence/(chosen.size()+1d);
        double avgCompatibility=compatibilityScore/chosen.size();
        double detourFactor=1d/(1d+detour/15d);
        double fareFactor=Math.min(1d,fare/1500d);
        double score=avgCompatibility*0.38d+avgConfidence*0.27d+detourFactor*0.25d+fareFactor*0.10d;
        out.add(new Recommendation(chosen,fare,score,label,search.bestSequence,detour));
    }

    private void dfs(List<Booking> bookings,boolean[] picked,boolean[] delivered,GeographicDataset.Point at,
                     double distance,List<String> sequence,Search best) {
        if (++best.nodes>MAX_COMBINATION_NODES||distance>=best.bestDistance) return;
        boolean complete=true;
        for (boolean value:delivered) if (!value) { complete=false; break; }
        if (complete) {
            best.bestDistance=distance;
            best.bestSequence=String.join(" → ",sequence);
            return;
        }
        for (int i=0;i<bookings.size();i++) {
            GeographicDataset.Point pickup=GeographicDataset.get(bookings.get(i).pickup);
            GeographicDataset.Point drop=GeographicDataset.get(bookings.get(i).dropoff);
            if (!picked[i]) {
                double leg=GeoMatcher.distanceKm(at,pickup);
                if (Double.isFinite(leg)&&leg<=60d) {
                    picked[i]=true; sequence.add("PICKUP "+bookings.get(i).pickup);
                    dfs(bookings,picked,delivered,pickup,distance+leg,sequence,best);
                    sequence.remove(sequence.size()-1); picked[i]=false;
                }
            } else if (!delivered[i]) {
                double leg=GeoMatcher.distanceKm(at,drop);
                if (Double.isFinite(leg)&&leg<=80d) {
                    delivered[i]=true; sequence.add("DROP "+bookings.get(i).dropoff);
                    dfs(bookings,picked,delivered,drop,distance+leg,sequence,best);
                    sequence.remove(sequence.size()-1); delivered[i]=false;
                }
            }
        }
    }
}
