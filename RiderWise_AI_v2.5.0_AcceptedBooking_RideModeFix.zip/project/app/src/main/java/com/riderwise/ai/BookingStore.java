package com.riderwise.ai;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** Transactional local booking store. No customer identity fields are collected. */
public class BookingStore extends SQLiteOpenHelper {
    private static final String DB_NAME = "riderwise.db";
    private static final int DB_VERSION = 3;
    private static final String TABLE = "bookings";

    public BookingStore(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) { createSchema(db); }

    private static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS bookings(" +
                "id TEXT PRIMARY KEY,pickup TEXT NOT NULL,dropoff TEXT NOT NULL," +
                "base_fare REAL NOT NULL,additional_fare REAL NOT NULL,total_fare REAL NOT NULL," +
                "pickup_km REAL,confidence REAL NOT NULL,first_seen INTEGER NOT NULL,last_seen INTEGER NOT NULL," +
                "fingerprint TEXT NOT NULL UNIQUE,status TEXT NOT NULL,is_reference INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX IF NOT EXISTS booking_last_seen ON bookings(last_seen)");
        db.execSQL("CREATE INDEX IF NOT EXISTS booking_reference ON bookings(is_reference)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.beginTransaction();
        try {
            if (oldVersion < 2) migrateLegacyV1(db);
            createSchema(db);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    /** v1 stored one combined fare and a single detection timestamp. */
    private static void migrateLegacyV1(SQLiteDatabase db) {
        Cursor exists = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='bookings'", null);
        boolean hasTable;
        try { hasTable = exists.moveToFirst(); } finally { exists.close(); }
        if (!hasTable) return;
        db.execSQL("DROP INDEX IF EXISTS booking_last_seen");
        db.execSQL("ALTER TABLE bookings RENAME TO bookings_v1_legacy");
        createSchema(db);
        db.execSQL("INSERT OR IGNORE INTO bookings(id,pickup,dropoff,base_fare,additional_fare,total_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,status,is_reference) " +
                "SELECT id,pickup,dropoff,fare,0,fare,pickup_km,confidence,detected_at,detected_at,fingerprint,status,is_reference FROM bookings_v1_legacy");
        db.execSQL("DROP TABLE bookings_v1_legacy");
    }

    public synchronized void upsert(Booking booking) {
        if (!BookingValidator.isValid(booking)) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor old = db.rawQuery("SELECT is_reference,first_seen,status FROM bookings WHERE fingerprint=?",
                    new String[]{booking.fingerprint})) {
                if (old.moveToFirst()) {
                    booking.reference = old.getInt(0) == 1;
                    booking.firstDetectedAt = Math.min(booking.firstDetectedAt, old.getLong(1));
                    if (booking.reference || "ACCEPTED".equals(old.getString(2))) booking.status = "ACCEPTED";
                }
            }
            ContentValues values = toValues(booking);
            db.insertWithOnConflict(TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private static ContentValues toValues(Booking b) {
        ContentValues v = new ContentValues();
        v.put("id", b.id); v.put("pickup", b.pickup); v.put("dropoff", b.dropoff);
        v.put("base_fare", b.baseFare); v.put("additional_fare", b.additionalFare); v.put("total_fare", b.totalFare);
        if (Double.isFinite(b.pickupDistanceKm)) v.put("pickup_km", b.pickupDistanceKm); else v.putNull("pickup_km");
        v.put("confidence", b.confidence); v.put("first_seen", b.firstDetectedAt); v.put("last_seen", b.lastDetectedAt);
        v.put("fingerprint", b.fingerprint); v.put("status", b.status == null ? "DETECTED" : b.status);
        v.put("is_reference", b.reference ? 1 : 0);
        return v;
    }

    public synchronized List<Booking> getRecent() {
        List<Booking> out = new ArrayList<>();
        long cutoff = System.currentTimeMillis() - 6L * 60L * 60L * 1000L;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,pickup,dropoff,base_fare,additional_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,is_reference,status " +
                        "FROM bookings WHERE last_seen>? AND status!='REJECTED' ORDER BY last_seen DESC LIMIT 150",
                new String[]{String.valueOf(cutoff)})) {
            while (c.moveToNext()) {
                double pickupKm = c.isNull(5) ? Double.NaN : c.getDouble(5);
                Booking b = new Booking(c.getString(1), c.getString(2), c.getDouble(3), c.getDouble(4),
                        pickupKm, c.getFloat(6), c.getLong(7), c.getLong(8));
                b.id = c.getString(0); b.fingerprint = c.getString(9);
                b.reference = c.getInt(10) == 1; b.status = c.getString(11);
                out.add(b);
            }
        }
        return out;
    }

    public synchronized Booking getReference() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,pickup,dropoff,base_fare,additional_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,status " +
                        "FROM bookings WHERE is_reference=1 LIMIT 1", null)) {
            if (!c.moveToFirst()) return null;
            double pickupKm = c.isNull(5) ? Double.NaN : c.getDouble(5);
            Booking b = new Booking(c.getString(1), c.getString(2), c.getDouble(3), c.getDouble(4),
                    pickupKm, c.getFloat(6), c.getLong(7), c.getLong(8));
            b.id = c.getString(0); b.fingerprint = c.getString(9); b.reference = true; b.status = c.getString(10);
            return b;
        }
    }

    /** The rider explicitly selects the booking they have accepted in the delivery app. */
    public synchronized boolean setAcceptedReference(String bookingId) {
        if (bookingId == null || bookingId.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor c = db.rawQuery("SELECT id FROM bookings WHERE id=? AND status!='REJECTED'", new String[]{bookingId})) {
                if (!c.moveToFirst()) return false;
            }
            ContentValues clear = new ContentValues(); clear.put("is_reference", 0);
            db.update(TABLE, clear, null, null);
            ContentValues selected = new ContentValues();
            selected.put("is_reference", 1); selected.put("status", "ACCEPTED");
            db.update(TABLE, selected, "id=?", new String[]{bookingId});
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }

    public synchronized void expireOlderThan(long cutoff) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ContentValues stale = new ContentValues(); stale.put("status", "STALE");
            db.update(TABLE, stale, "last_seen<? AND is_reference=0", new String[]{String.valueOf(cutoff)});
            db.delete(TABLE, "last_seen<? AND is_reference=0", new String[]{String.valueOf(cutoff - 24L*60L*60L*1000L)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
}
