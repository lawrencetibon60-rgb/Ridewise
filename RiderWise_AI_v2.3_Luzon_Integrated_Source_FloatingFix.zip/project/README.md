# RiderWise AI v2.2 — Android Java project

An in-place upgrade of the supplied RiderWise AI v2.1 source. The application ID and Java namespace remain `com.riderwise.ai`. The app is read-only: it does not accept or confirm bookings.

## Project structure

- `app/src/main/java/com/riderwise/ai/` — Android services, OCR, booking model/storage, geographic matcher, recommendation and profitability logic.
- `app/src/test/` — local JVM unit-test source.
- `.github/workflows/android-build.yml` — cloud build, tests and APK artifact workflow.
- `gradle/wrapper/gradle-wrapper.properties` — pinned Gradle 8.9 distribution and SHA-256.

## Build configuration

- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Compile / target SDK 35
- Minimum SDK 23
- Google ML Kit Text Recognition 16.0.1
- AndroidX AppCompat 1.7.0 and Material 1.12.0

## GitHub Actions build (no PC required)

The supplied v2.1 archive did not contain `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. The workflow therefore provisions official Gradle 8.9 on the GitHub runner and runs Gradle's `wrapper` task. It verifies that the generated Wrapper JAR matches Gradle's published SHA-256 checksum, checks both scripts, runs `./gradlew --version`, then runs:

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug
```

After generating the wrapper, the workflow uploads `RiderWise-AI-v2.2-wrapper-complete-source` as a ZIP artifact containing the real wrapper JAR and both scripts. It also uploads the debug APK as `RiderWise-AI-v2.2-debug.apk` after a successful build. Test reports are uploaded even if tests fail; build logs are uploaded on failure. No repository secrets are required for a normal debug build.

To use it:
1. Upload the contents of this project folder to a GitHub repository's `main` or `development` branch.
2. Open **Actions** and select **RiderWise AI Android Build**.
3. Wait for the workflow to finish.
4. Download `RiderWise-AI-v2.2-debug.apk` if the build succeeds. Download `RiderWise-AI-v2.2-wrapper-complete-source` to get the wrapper-complete source archive.

## v2.3.0 improvements

- Live booking count is based on visible `Pick Up Now` card headers in the current OCR frame, not the six-hour SQLite history. The panel separately reports cards visible, bookings successfully parsed in this scan, and saved recent records.
- OCR card segmentation now starts at each booking header and ignores app navigation/status text above the first card. This prevents unrelated screen text from being treated as part of a booking.
- Identical-looking cards are no longer collapsed inside a single OCR frame before the live count is reported.
- Floating dashboard refreshed with a compact navy/blue live-status header, clearer analysis surface, draggable panel, responsive expanded width, and Pause/Resume/Stop controls.

**Important limitation:** OCR can count a visible card header even when part of that card is covered or clipped, but it cannot reliably extract missing route/fare fields that are not visible. The panel therefore distinguishes visible card count from successfully parsed booking count.

## Implemented in this source revision

- Booking model retains base fare, additional fare and total fare separately; fingerprint IDs use deterministic UUIDs.
- Booking validation checks fare arithmetic, route fields, confidence and distance validity.
- OCR extractor groups lines by vertical gaps and booking headers, supports explicit pickup/drop-off labels, detects currency-prefixed fare pairs, and rejects incomplete/duplicate cards.
- ML Kit OCR is single-flight; accepted bitmaps are released after task completion, and synchronous task-start failures release state safely.
- SQLite schema version 3 stores fare components, confidence, timestamps, fingerprint, status and reference flag. Upserts and reference selection use transactions. Legacy v1 combined-fare migration is retained.
- First persisted valid booking becomes the reference and is not replaced by subsequent records.
- Recommendation search considers combinations of up to six additional bookings (seven including the reference), enforces pickup-before-drop-off, deduplicates combinations and applies a node budget.
- Route compatibility includes same route, along the way, near the route, possible compatibility, reverse direction, excessive backtracking and incompatible classifications.
- Profitability calculations return unavailable values when distance, duration or fuel inputs are missing.
- MediaProjection remains the live capture source at a five-second target interval. The service checks screen dimensions on successive ticks and recreates its virtual display after size changes; revoked permission stops capture and requires a new explicit user authorization.
- Ride Mode remains manually controlled and persisted in SharedPreferences. No movement sensor changes it automatically.
- Android 13+ notification permission is requested by the activity.

## Geographic data limitations

The dataset is **not yet the full verified Luzon dataset**. It preserves the legacy v2.1 coordinate seeds, explicitly labels their coordinate provenance as undocumented / unverified, and adds named locations in Region IV-B and other Luzon regions without coordinates. These unresolved locations intentionally return no geographic point. Do not treat straight-line distances as road distances or use unresolved entries for route scoring. A complete authoritative PSGC/location dataset with verified coordinate provenance still needs to be imported before full Luzon coverage can be claimed.

## Testing and verification status

- **Implemented:** source changes described above; this does not mean every master requirement is complete.
- **Java core compile:** verified with `javac --release 17` for the pure-Java booking, geographic, route, recommendation and profitability classes.
- **Android Gradle compile:** not run in this environment (Android SDK and Gradle distribution are not installed here).
- **Automated JUnit tests:** source updated but not executed here; GitHub Actions must run them.
- **GitHub build:** not yet run; no repository was supplied/connected for pushing this project.
- **APK:** not generated in this environment.
- **Physical device:** not tested on OPPO Reno 5 / ColorOS.

## Permissions and safety

- MediaProjection consent: Android's official system prompt; capture stops when authorization is revoked.
- Overlay: `SYSTEM_ALERT_WINDOW`, granted manually in Android settings.
- Foreground service: notification and MediaProjection foreground-service declarations are included.
- Notifications: Android 13+ runtime permission is requested.
- Use the dashboard only while safely parked. Ride Mode is a display preference, not a substitute for safe riding practices.

## Remaining work before release acceptance

1. Obtain/import a complete official geographic administrative dataset and independently verified coordinates with source/version metadata.
2. Validate OCR card grouping and fare extraction against representative Lalamove screen recordings, including overlapping and partially visible cards.
3. Add instrumentation tests for MediaProjection permission, revocation, screen rotation, overlay denial, database migration and Ride Mode persistence.
4. Complete UI inspection controls and detailed profitability display in the floating panel.
5. Run the GitHub Actions build and resolve any Android compilation/test failures.
6. Physically test capture/background behavior on OPPO Reno 5 / ColorOS.

No successful Android build, APK, or device test is claimed until the relevant process has actually completed.

## Luzon PSGC 3Q 2026 integration

The app now bundles `app/src/main/assets/luzon_psgc_3q_2026.json.gz`, derived from the PSA **PSGC 3Q 2026 Publication Datafile** supplied for this project. The bundled scope is NCR, CAR, Regions I, II, III, IV-A, MIMAROPA, and V.

Included administrative records (21,330 total):

- 8 regions
- 38 provinces
- 77 cities
- 694 municipalities
- 14 sub-municipalities
- 20,499 barangays

`PsgcDataset` loads the compressed asset, indexes official PSGC identifiers, names and old names, supports parent-aware disambiguation, and provides administrative search and hierarchy paths. `BookingExtractor` canonicalizes unambiguous OCR place names against the PSGC index. `GeographicDataset` exposes the administrative lookup methods alongside the legacy coordinate lookup.

**Important geographic limitation:** the PSA publication datafile contains administrative identifiers and hierarchy, not latitude/longitude or road geometry. Therefore PSGC records do not receive fabricated coordinates. Existing legacy coordinate seeds remain explicitly marked approximate/unverified and must not be treated as verified road navigation data. Route distance and detour calculations remain straight-line estimates only where a legacy coordinate is available; otherwise the app should leave geographic distance unavailable.

## Floating assistant changes in this update

The floating panel has a draggable title area, expand/collapse control, OCR summary, Pause/Resume, Stop OCR, and Hide controls. Pause/resume/stop are forwarded to the screen-capture service. Screen rotation now resizes the existing MediaProjection virtual display and replaces its ImageReader surface rather than creating a second virtual display from the same projection token.

The overlay and MediaProjection flow still require verification on physical Android devices, particularly ColorOS background restrictions and Android-version-specific permission behavior. Use only while safely parked.

## Dataset verification

Run `python tools/verify_psgc.py` from the project root. It validates the embedded asset's PSA metadata, expected record counts by administrative level, unique PSGC codes, and parent-code integrity. The GitHub Actions workflow runs this validation before the Android build.

## Build status for this handoff

Source integration and the standalone PSGC asset validation are complete. This handoff does **not** claim a successful Android Gradle build or a device-tested APK. The archive still relies on the GitHub Actions workflow to generate the official Gradle wrapper from Gradle 8.9 and run `clean testDebugUnitTest assembleDebug`; the generated wrapper JAR and APK must be retrieved from a successful workflow run. No physical OPPO Reno 5/ColorOS test has been performed here.
