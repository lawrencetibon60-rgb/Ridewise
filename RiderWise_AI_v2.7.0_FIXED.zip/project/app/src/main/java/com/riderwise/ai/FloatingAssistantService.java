package com.riderwise.ai;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact, draggable RiderWise dashboard with a high-contrast live analysis view. */
public class FloatingAssistantService extends Service {
    private static volatile FloatingAssistantService activeInstance;
    public static final String PREFS="riderwise_prefs", KEY_VISIBLE="dashboard_visible", KEY_RIDE="ride_mode";
    private WindowManager wm;
    private View panel;
    private TextView content,title,status,modeLabel;
    private LinearLayout body,controls;
    private WindowManager.LayoutParams params;
    private boolean collapsed=true, paused=false;
    private Button toggleButton;
    private int dp(float value){ return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int color,int stroke,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    @Override public void onCreate(){
        super.onCreate();
        if(!Settings.canDrawOverlays(this) || !getSharedPreferences(PREFS,0).getBoolean(KEY_VISIBLE,true)){stopSelf();return;}
        activeInstance = this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); buildPanel();
    }

    /** Hide the floating panel while a screenshot is captured so it cannot cover booking cards. */
    public static void setTemporarilyHiddenForCapture(boolean hidden) {
        FloatingAssistantService service = activeInstance;
        if (service != null && service.panel != null) {
            service.panel.setVisibility(hidden ? View.GONE : View.VISIBLE);
        }
    }
    private boolean rideMode(){return getSharedPreferences(PREFS,0).getBoolean(KEY_RIDE,false);}
    private Button action(String label, View.OnClickListener listener){
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false);
        b.setTextColor(0xFFEAF2FF); b.setPadding(dp(8),0,dp(8),0); b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42));
        b.setBackground(shape(0xFF172844,0xFF42618C,14)); b.setOnClickListener(listener); return b;
    }
    private void buildPanel(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(10),dp(12),dp(10)); box.setBackground(shape(0xF20A1428,0xFF4A91FF,22));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        title=text("◉  RiderWise AI",18,0xFFF4F7FF,true);
        modeLabel=text("RIDE MODE: OFF",9,0xFF8FB8FF,true);
        brand.addView(title); brand.addView(modeLabel);
        header.addView(brand,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));
        status=text("● LIVE",10,0xFF6EF0A0,true);
        status.setPadding(dp(10),dp(7),dp(10),dp(7)); status.setBackground(shape(0xFF123B34,0xFF237D65,20));
        header.addView(status);
        toggleButton=action("Show",v->toggleExpanded());
        header.addView(toggleButton);
        box.addView(header);
        View rule=new View(this); rule.setBackgroundColor(0xFF263B5B);
        LinearLayout.LayoutParams ruleLp=new LinearLayout.LayoutParams(-1,dp(1)); ruleLp.topMargin=dp(10); ruleLp.bottomMargin=dp(9);
        box.addView(rule,ruleLp);

        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(false);
        LinearLayout detailCard=new LinearLayout(this); detailCard.setOrientation(LinearLayout.VERTICAL);
        detailCard.setPadding(dp(12),dp(11),dp(12),dp(11)); detailCard.setBackground(shape(0xFF111F38,0xFF2C4770,16));
        TextView heading=text("LIVE ANALYSIS",10,0xFF8FB8FF,true);
        heading.setPadding(0,0,0,dp(7)); detailCard.addView(heading);
        content=text("Waiting for screen reading…\nKeep the app visible and use monitoring only while safely stopped.",13,0xFFE7EEFC,false);
        content.setLineSpacing(dp(3),1f); detailCard.addView(content);
        body.addView(detailCard);
        controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0,dp(9),0,0);
        controls.addView(action("Ⅱ  Pause",v->togglePause()),new LinearLayout.LayoutParams(0,dp(44),1f));
        controls.addView(action("■  Stop",v->stopMonitoring()),new LinearLayout.LayoutParams(0,dp(44),1f));
        controls.addView(action("Hide",v->{getSharedPreferences(PREFS,0).edit().putBoolean(KEY_VISIBLE,false).apply();stopSelf();}),new LinearLayout.LayoutParams(0,dp(44),1f));
        body.addView(controls); scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(300)));
        box.addView(scroll); panel=box;
        body.setVisibility(collapsed?View.GONE:View.VISIBLE);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int screenWidth=getResources().getDisplayMetrics().widthPixels;
        int width=Math.min(dp(360),Math.max(dp(250),screenWidth-dp(24)));
        params=new WindowManager.LayoutParams(collapsed?dp(220):width,WindowManager.LayoutParams.WRAP_CONTENT,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.END; params.x=dp(12); params.y=dp(170); wm.addView(panel,params); applyRideMode();
        header.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;
            @Override public boolean onTouch(View v, MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)(sx-e.getRawX());params.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}
                return e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL;
            }});
    }
    private void applyRideMode(){
        if(params==null||wm==null||panel==null)return;
        boolean on=rideMode();
        params.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | (on?WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE:0);
        if(on && !collapsed){collapsed=true; if(body!=null)body.setVisibility(View.GONE); if(toggleButton!=null)toggleButton.setText("Show"); params.width=dp(220);}
        if(modeLabel!=null){modeLabel.setText(on?"RIDE MODE: ON • NON-INTERACTIVE":"RIDE MODE: OFF • INTERACTIVE");modeLabel.setTextColor(on?0xFF6EF0A0:0xFF8FB8FF);}
        try{wm.updateViewLayout(panel,params);}catch(Exception e){android.util.Log.w("RiderWise","Ride mode layout update failed",e);}
    }
    private void toggleExpanded(){
        collapsed=!collapsed; body.setVisibility(collapsed?View.GONE:View.VISIBLE);
        toggleButton.setText(collapsed?"Show":"Minimize");
        if(params!=null&&wm!=null&&panel!=null){int screenWidth=getResources().getDisplayMetrics().widthPixels;
            params.width=collapsed?dp(220):Math.min(dp(360),Math.max(dp(250),screenWidth-dp(24)));
            try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}}
    }
    private void togglePause(){
        paused=!paused; Intent i=new Intent(this,ScreenCaptureService.class);i.setAction(paused?"PAUSE":"RESUME");startService(i);
        status.setText(paused?"Ⅱ PAUSED":"● LIVE"); status.setTextColor(paused?0xFFFFD27A:0xFF6EF0A0);
        if(paused)content.setText("MONITORING PAUSED\nTap Resume to continue.");
        if(controls!=null&&controls.getChildCount()>0)((Button)controls.getChildAt(0)).setText(paused?"▶  Resume":"Ⅱ  Pause");
    }
    private void stopMonitoring(){
        Intent i=new Intent(this,ScreenCaptureService.class);i.setAction("STOP");startService(i);
        content.setText("Monitoring stopped. Start screen reading again from the main app.");
        status.setText("■ STOPPED");status.setTextColor(0xFFFFB0A6);
    }
    public static void update(Context c,String value){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("UPDATE");i.putExtra("text",value);c.startService(i);
    }
    public static void refreshMode(Context c){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("MODE");c.startService(i);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&"UPDATE".equals(i.getAction())&&content!=null){
            content.setText(i.getStringExtra("text"));
            if(status!=null&&!paused){status.setText("● LIVE");status.setTextColor(0xFF6EF0A0);}
        }
        if(i!=null&&"MODE".equals(i.getAction()))applyRideMode();
        return START_STICKY;
    }
    @Override public void onDestroy(){
        if (activeInstance == this) activeInstance = null;
        if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
