# RiderWise AI v2.4.0

Android screen-reading assistant for Lalamove booking visibility and route analysis.

## v2.4.0 changes
- Briefly hides the RiderWise floating overlay while a screen frame is captured, reducing obstruction of booking cards.
- Detects wide orange booking-header bands visually, independently of ML Kit OCR text.
- Uses detected header positions to segment OCR lines into separate booking cards.
- Reports visible booking cards separately from successfully parsed bookings and saved recent records.
- Adds unit tests for orange header-band detection and booking-header text recognition.

The visible-card count is a visual estimate based on the Lalamove-style orange header bars. OCR extraction can still fail for individual cards, so compare **Visible booking cards** with **Parsed this scan** during device testing.

Use only while safely parked. RiderWise is read-only and does not accept or reject bookings.


## v2.5.0 updates
- Ride Mode now changes overlay touchability: ON is non-interactive; OFF is interactive.
- Rider must explicitly select the booking accepted in Lalamove from the RiderWise app as the accepted reference.
- Recommendations use only that explicit reference; the app does not claim to detect the accept action in Lalamove.
