package com.riderwise.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.Closeable
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Local-first language-model adapter. All native engine work is serialized on one worker
 * thread. It can rank only deterministic, pre-validated recommendation options; it never edits OCR fields or facts.
 */
class LiteRtLocalAnalyzer private constructor(context: Context) : OfflineAiCoordinator.LocalAnalyzer, Closeable {
    companion object {
        @Volatile private var shared: LiteRtLocalAnalyzer? = null
        @JvmStatic fun get(context: Context): LiteRtLocalAnalyzer = shared ?: synchronized(this) {
            shared ?: LiteRtLocalAnalyzer(context.applicationContext).also { shared = it }
        }
    }
    private val appContext = context.applicationContext
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var engine: Engine? = null
    @Volatile private var closed = false

    interface RecommendationCallback {
        fun onRanked(order: MutableList<Int>)
        fun onUnavailable(reason: String)
    }

    interface InitCallback {
        fun onReady()
        fun onError(message: String)
    }

    fun initialize(callback: InitCallback) {
        worker.execute {
            try {
                if (closed) throw IllegalStateException("Local AI engine is closed")
                if (engine != null) { callback.onReady(); return@execute }
                val model = AiModelManager.modelFile(appContext)
                if (!model.isFile || model.length() < AiModelManager.MIN_VALID_MODEL_BYTES) {
                    throw IllegalStateException("Download the compatible Gemma model first.")
                }
                engine?.close()
                val created = Engine(EngineConfig(
                    modelPath = model.absolutePath,
                    backend = Backend.CPU(),
                    cacheDir = appContext.cacheDir.absolutePath
                ))
                created.initialize()
                engine = created
                callback.onReady()
            } catch (t: Throwable) {
                callback.onError(t.message ?: "Local model initialization failed")
            }
        }
    }

    override fun isReady(): Boolean = engine != null && !closed

    override fun analyze(reference: Booking, candidates: MutableList<Booking>, callback: OfflineAiCoordinator.Callback) {
        ask(buildAnalysisPrompt(reference, candidates), callback)
    }

    /** AI reorders only combinations already accepted by deterministic route/location/vehicle checks. */
    fun rankRecommendations(reference: Booking, options: List<RecommendationEngine.Recommendation>, callback: RecommendationCallback) {
        if (options.isEmpty()) { callback.onUnavailable("No validated recommendation options to rank."); return }
        val bounded = options.take(8)
        val prompt = buildString {
            append("You are the offline RiderWise booking decision assistant. Rank ONLY the supplied candidate IDs.\n")
            append("Hard rules: do not invent or recalculate fare, distance, ETA, coordinates, or route facts. ")
            append("All options already passed deterministic validation. Do not add or remove options. ")
            append("Prefer route compatibility, low detour, OCR confidence, driver preferences, suitable vehicle and booking type. ")
            append("Treat preferences as advisory. Return ONLY IDs in best-to-worst order, one per line, format C1.\n")
            append("Accepted reference: ").append(reference.pickup).append(" -> ").append(reference.dropoff)
                .append("; fare PHP ").append(reference.totalFare).append("; vehicle ").append(reference.vehicleType ?: "unknown").append("\n")
            val preferences = appContext.getSharedPreferences(FloatingAssistantService.PREFS, Context.MODE_PRIVATE)
                .getString("driver_ai_preferences", "")?.trim().orEmpty()
            if (preferences.isNotEmpty()) append("Driver preferences (advisory): ").append(preferences.take(400)).append("\n")
            bounded.forEachIndexed { index, option ->
                append("C").append(index + 1).append(" | deterministic score ").append(String.format(java.util.Locale.US, "%.3f", option.score))
                    .append(" | compatibility ").append(option.compatibility).append(" | detour straight-line km ")
                    .append(String.format(java.util.Locale.US, "%.2f", option.detourKm)).append(" | total fare PHP ")
                    .append(String.format(java.util.Locale.US, "%.2f", option.totalFare)).append(" | bookings: ")
                option.bookings.forEach { b -> append(b.pickup).append(" -> ").append(b.dropoff)
                    .append(" [vehicle=").append(b.vehicleType ?: "unknown").append(", type=").append(b.bookingType ?: "unknown")
                    .append(", OCR=").append((b.confidence * 100).toInt()).append("%]; ") }
                append("\n")
            }
        }
        worker.execute {
            try {
                val active = engine ?: throw IllegalStateException("Local model is not initialized")
                val config = ConversationConfig(
                    systemInstruction = Contents.of("Return only candidate IDs. Never fabricate facts. The deterministic engine is authoritative; you may only rank the provided validated options."),
                    samplerConfig = SamplerConfig(topK = 10, topP = 0.8, temperature = 0.05),
                    maxOutputToken = 96
                )
                active.createConversation(config).use { conversation ->
                    val answer = conversation.sendMessage(prompt).text
                    val found = Regex("(?<![A-Za-z0-9])C([1-8])(?![0-9])").findAll(answer).map { it.groupValues[1].toInt() - 1 }
                        .filter { it in bounded.indices }.distinct().toMutableList()
                    if (found.isEmpty()) callback.onUnavailable("Offline AI returned no valid candidate ranking.")
                    else callback.onRanked(found)
                }
            } catch (t: Throwable) {
                callback.onUnavailable("Offline AI ranking unavailable: ${t.message ?: "inference failed"}")
            }
        }
    }

    fun answerQuestion(question: String, reference: Booking?, candidates: List<Booking>, callback: OfflineAiCoordinator.Callback) {
        val prompt = buildString {
            append("Answer the driver's question using only the booking context below. ")
            append("Do not invent addresses, distances, ETAs, fares, or compatibility scores. ")
            append("If information is missing, say so.\n")
            append(bookingContext(reference, candidates))
            append("\nDriver question: ").append(question.take(700))
        }
        ask(prompt, callback)
    }

    private fun ask(prompt: String, callback: OfflineAiCoordinator.Callback) {
        worker.execute {
            try {
                val active = engine ?: throw IllegalStateException("Local model is not initialized")
                val config = ConversationConfig(
                    systemInstruction = Contents.of(
                        "You are RiderWise AI, a cautious assistant for delivery booking analysis. " +
                        "Never replace OCR, validators, fare math, or route scoring. Clearly distinguish " +
                        "verified facts from estimates and inferred locations. Keep answers concise."
                    ),
                    samplerConfig = SamplerConfig(topK = 20, topP = 0.85, temperature = 0.2),
                    maxOutputToken = 384
                )
                active.createConversation(config).use { conversation ->
                    val response = conversation.sendMessage(prompt)
                    val answer: String = response.text.toString()
                    callback.onResult(
                        if (answer.isBlank()) {
                            "The local model returned an empty answer."
                        } else {
                            answer
                        }
                    )
                }
            } catch (t: Throwable) {
                callback.onUnavailable("Local AI unavailable: ${t.message ?: "inference failed"}. Deterministic booking results remain active.")
            }
        }
    }

    private fun buildAnalysisPrompt(reference: Booking?, candidates: List<Booking>): String = buildString {
        append("Analyze the parsed booking matches and explain compatibility. Do not invent facts or alter deterministic scores.\n")
        append(bookingContext(reference, candidates))
        append("\nFor each candidate, explain matching pickup/destination context, missing information, and warnings. ")
        append("State that route estimates are straight-line only when the context says so.")
    }

    private fun bookingContext(reference: Booking?, candidates: List<Booking>): String = buildString {
        val preferences = appContext.getSharedPreferences(FloatingAssistantService.PREFS, Context.MODE_PRIVATE)
            .getString("driver_ai_preferences", "")?.trim().orEmpty()
        if (preferences.isNotEmpty()) append("Driver preferences (advisory only): ").append(preferences.take(500)).append("\n")
        if (reference != null) append("Reference: ").append(reference.pickup).append(" -> ").append(reference.dropoff)
            .append("; fare PHP ").append(reference.totalFare).append("; vehicle ").append(reference.vehicleType ?: "unknown").append("\n")
        else append("Reference: not set\n")
        candidates.take(8).forEachIndexed { index, b ->
            append("Candidate ").append(index + 1).append(": ").append(b.pickup).append(" -> ").append(b.dropoff)
                .append("; fare PHP ").append(b.totalFare).append("; vehicle ").append(b.vehicleType ?: "unknown")
                .append("; booking type ").append(b.bookingType ?: "unknown")
                .append("; OCR confidence ").append((b.confidence * 100).toInt()).append("%\n")
        }
    }

    override fun close() {
        closed = true
        worker.execute {
            try { engine?.close() } catch (_: Throwable) { }
            engine = null
            worker.shutdown()
        }
    }
}
