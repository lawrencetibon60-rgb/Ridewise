package com.riderwise.ai;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_DATA = "resultData";
    private static final int NOTIFICATION_ID = 210;
    private Handler handler;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private OcrProcessor ocr;
    private BookingStore store;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private long lastFrameHash = Long.MIN_VALUE;
    private int captureWidth, captureHeight, captureDensity;
    private long lastFrameAt;
    private volatile boolean projectionRevoked;
    private volatile boolean paused;
    private final Runnable scan = new Runnable() {
        @Override public void run() {
            if (!paused) captureAndProcess();
            if (handler != null && !paused) handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        PsgcDataset.initialize(getApplicationContext());
        ocr = new OcrProcessor();
        store = new BookingStore(this);
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "PAUSE".equals(intent.getAction())) { paused=true; if(handler!=null)handler.removeCallbacks(scan); FloatingAssistantService.update(this,"MONITORING PAUSED\nTap Resume in the floating panel."); return START_NOT_STICKY; }
        if (intent != null && "RESUME".equals(intent.getAction())) { if(projection==null||projectionRevoked){FloatingAssistantService.update(this,"Capture permission expired. Re-authorize in RiderWise.");return START_NOT_STICKY;} paused=false; if(handler!=null){handler.removeCallbacks(scan);handler.post(scan);} FloatingAssistantService.update(this,"Monitoring resumed"); return START_NOT_STICKY; }
        if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (intent == null || !intent.hasExtra(EXTRA_DATA)) { stopSelf(); return START_NOT_STICKY; }
        // A new explicit user authorization is required for every new projection session.
        if (projection != null) stopCapture();
        projectionRevoked = false;
        paused = false;
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIFICATION_ID, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION_ID, notification());
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) data = intent.getParcelableExtra(EXTRA_DATA, Intent.class);
        else data = (Intent) intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) { stopSelf(); return START_NOT_STICKY; }
        MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try { projection = mpm.getMediaProjection(resultCode, data); }
        catch (SecurityException revoked) {
            android.util.Log.e("RiderWise", "MediaProjection authorization rejected; request permission again", revoked);
            stopSelf(); return START_NOT_STICKY;
        }
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    projectionRevoked = true;
                    // Android/ColorOS revoked the token: clean up and wait for a fresh user grant.
                    stopCaptureResources(false);
                    stopSelf();
                }
            }, handler);
            startCapture();
        } catch (RuntimeException captureStartError) {
            android.util.Log.e("RiderWise", "MediaProjection could not start; fresh consent is required", captureStartError);
            stopCapture(); stopSelf(); return START_NOT_STICKY;
        }
        handler.removeCallbacks(scan);
        handler.post(scan);
        if (android.provider.Settings.canDrawOverlays(this))
            startService(new Intent(this, FloatingAssistantService.class));
        return START_NOT_STICKY;
    }

    private void startCapture() {
        if (projection == null || projectionRevoked) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        captureWidth = Math.max(1, dm.widthPixels);
        captureHeight = Math.max(1, dm.heightPixels);
        captureDensity = dm.densityDpi;
        reader = ImageReader.newInstance(captureWidth, captureHeight, android.graphics.PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("RiderWiseCapture", captureWidth, captureHeight, captureDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        if (display == null) throw new IllegalStateException("Unable to create MediaProjection virtual display");
    }

    private void refreshCaptureSizeIfChanged() {
        if (projection == null || projectionRevoked) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        if (dm.widthPixels != captureWidth || dm.heightPixels != captureHeight || dm.densityDpi != captureDensity) {
            // Keep the existing MediaProjection VirtualDisplay. Android 14+ restricts
            // creating multiple virtual displays from one projection token.
            if (reader != null) { reader.close(); reader = null; }
            captureWidth = Math.max(1, dm.widthPixels);
            captureHeight = Math.max(1, dm.heightPixels);
            captureDensity = dm.densityDpi;
            reader = ImageReader.newInstance(captureWidth, captureHeight, android.graphics.PixelFormat.RGBA_8888, 2);
            if (display == null) throw new IllegalStateException("Capture display is unavailable");
            display.resize(captureWidth, captureHeight, captureDensity);
            display.setSurface(reader.getSurface());
            lastFrameHash = Long.MIN_VALUE;
        }
    }

    private void captureAndProcess() {
        if (projection == null || projectionRevoked) return;
        try { refreshCaptureSizeIfChanged(); }
        catch (RuntimeException e) { android.util.Log.e("RiderWise", "Capture surface refresh failed", e); return; }
        if (reader == null || !processing.compareAndSet(false, true)) return;
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) {
                // No fresh frame is available yet. Keep the service alive; next 5s tick retries.
                processing.set(false); return;
            }
            lastFrameAt = System.currentTimeMillis();
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
            int width = image.getWidth(), height = image.getHeight();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            Bitmap bitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
            padded.recycle();
            image.close(); image = null;
            long hash = sampleHash(bitmap);
            if (hash == lastFrameHash) { bitmap.recycle(); processing.set(false); return; }
            lastFrameHash = hash;
            boolean accepted = ocr.process(bitmap, bookings -> {
                try {
                for (Booking b : bookings) store.upsert(b);
                if (!bookings.isEmpty()) store.setReferenceIfAbsent(bookings.get(0));
                List<Booking> all = store.getRecent();
                Booking reference = store.getReference();
                StringBuilder summary = new StringBuilder("LIVE OCR • ")
                        .append(new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date()))
                        .append("\nBookings: ").append(all.size());
                if (reference != null) {
                    summary.append("\nREFERENCE: ").append(reference.pickup).append(" → ").append(reference.dropoff)
                            .append("\nOCR confidence: ").append(String.format(java.util.Locale.US,"%.0f%%",reference.confidence*100f));
                    java.util.List<RecommendationEngine.Recommendation> recs = new RecommendationEngine().recommend(all, reference);
                    int limit = Math.min(3, recs.size());
                    for (int n=0;n<limit;n++) {
                        RecommendationEngine.Recommendation r = recs.get(n);
                        summary.append("\n#").append(n+1).append(" ").append(r.bookings.size())
                            .append(" add • ₱").append(String.format(java.util.Locale.US,"%.2f",r.totalFare))
                            .append(" • ").append(r.compatibility)
                            .append(" • score ").append(String.format(java.util.Locale.US,"%.2f",r.score))
                            .append(" • detour ").append(String.format(java.util.Locale.US,"%.1f km straight-line",r.detourKm));
                    }
                    if (recs.isEmpty()) summary.append("\nNo resolved compatible combination yet.");
                    summary.append("\nProfitability: ESTIMATE UNAVAILABLE (road distance/time not supplied)");
                }
                FloatingAssistantService.update(this, summary.toString());
                } catch (Exception callbackError) {
                    android.util.Log.e("RiderWise", "OCR result handling failed", callbackError);
                } finally { processing.set(false); }
            });
            if (!accepted) processing.set(false);
        } catch (Exception e) {
            if (image != null) image.close();
            processing.set(false);
            android.util.Log.e("RiderWise", "Capture/OCR cycle failed", e);
        }
    }

    private long sampleHash(Bitmap bitmap) {
        long h=1469598103934665603L; int w=bitmap.getWidth(), height=bitmap.getHeight();
        for(int y=0;y<height;y+=Math.max(1,height/24)) for(int x=0;x<w;x+=Math.max(1,w/24))
            h=(h ^ bitmap.getPixel(x,y))*1099511628211L;
        return h;
    }
    private void stopCapture() { stopCaptureResources(true); }

    private void stopCaptureResources(boolean stopProjection) {
        if (handler != null) handler.removeCallbacks(scan);
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (stopProjection && projection != null) {
            MediaProjection old = projection; projection = null;
            try { old.stop(); } catch (RuntimeException ignored) { }
        } else if (!stopProjection) {
            projection = null;
        }
        captureWidth = captureHeight = captureDensity = 0;
        processing.set(false);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("riderwise_capture", "RiderWise monitoring", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "riderwise_capture") : new Notification.Builder(this);
        return b.setContentTitle("RiderWise AI is monitoring")
                .setContentText("OCR target interval: 5 seconds. Use only while safely stopped.")
                .setSmallIcon(android.R.drawable.ic_menu_view).build();
    }
    @Override public void onDestroy() { stopCapture(); if (ocr != null) ocr.close(); if (store != null) store.close(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
