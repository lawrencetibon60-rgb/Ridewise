package com.riderwise.ai;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Converts ML Kit text into independent booking-card candidates. */
public class BookingExtractor {
    private static final Pattern FARE_PAIR = Pattern.compile(
            "(?:₱|PHP)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)\\s*\\+\\s*(?:₱|PHP)?\\s*([0-9,]+(?:\\.[0-9]{1,2})?)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:₱|PHP)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern KM = Pattern.compile("~?\\s*([0-9]+(?:\\.[0-9]+)?)\\s*km", Pattern.CASE_INSENSITIVE);
    private static final Pattern PICKUP = Pattern.compile("^(?:pickup|pick\\s*up|from)\\s*[:：-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern DROPOFF = Pattern.compile("^(?:drop\\s*off|dropoff|destination|to)\\s*[:：-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final int MAX_VERTICAL_GAP_PX = 220;

    public static final class FareComponents {
        public final double baseFare, additionalFare, totalFare;
        FareComponents(double base, double additional) {
            baseFare=base; additionalFare=additional; totalFare=base+additional;
        }
    }

    /** Parses a displayed fare expression without merging its component amounts. */
    public static FareComponents parseFareComponents(String raw) {
        if (raw == null) return null;
        Matcher pair=FARE_PAIR.matcher(raw);
        if (pair.find()) {
            try { return new FareComponents(Double.parseDouble(pair.group(1).replace(",", "")),
                    Double.parseDouble(pair.group(2).replace(",", ""))); }
            catch (NumberFormatException ignored) { return null; }
        }
        Matcher single=MONEY.matcher(raw);
        if (single.find()) {
            try { return new FareComponents(Double.parseDouble(single.group(1).replace(",", "")),0d); }
            catch (NumberFormatException ignored) { return null; }
        }
        return null;
    }

    public List<Booking> extract(Text text) {
        if (text == null) return Collections.emptyList();
        List<Text.Line> lines = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks()) lines.addAll(block.getLines());
        lines.sort(Comparator.comparingInt(BookingExtractor::top));
        List<List<Text.Line>> cards = new ArrayList<>();
        List<Text.Line> current = new ArrayList<>();
        int previousBottom = -1;
        for (Text.Line line : lines) {
            Rect bounds = line.getBoundingBox();
            int top = bounds == null ? previousBottom + 1 : bounds.top;
            int bottom = bounds == null ? top + 1 : bounds.bottom;
            String lineText = line.getText() == null ? "" : line.getText().trim().toLowerCase(Locale.ROOT);
            boolean header = lineText.contains("pick up now") || lineText.contains("pickup now")
                    || lineText.matches(".*booking\\s*#?\\d+.*");
            boolean newCard = !current.isEmpty() && (header || (bounds != null && previousBottom >= 0
                    && top - previousBottom > MAX_VERTICAL_GAP_PX));
            if (newCard) { cards.add(current); current = new ArrayList<>(); }
            current.add(line);
            previousBottom = bottom;
        }
        if (!current.isEmpty()) cards.add(current);

        List<Booking> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (List<Text.Line> card : cards) {
            Booking booking = parseCard(card);
            if (BookingValidator.isValid(booking) && seen.add(booking.fingerprint)) result.add(booking);
        }
        return result;
    }

    private static int top(Text.Line line) {
        Rect r = line.getBoundingBox(); return r == null ? 0 : r.top;
    }

    private Booking parseCard(List<Text.Line> lines) {
        StringBuilder all = new StringBuilder();
        List<Double> amounts = new ArrayList<>();
        String pickup = null, dropoff = null;
        double pickupKm = Double.NaN, baseFare = Double.NaN, additionalFare = 0d;
        float confidenceTotal = 0f; int confidenceCount = 0;
        for (Text.Line line : lines) {
            String raw = line.getText() == null ? "" : line.getText().trim();
            if (raw.isEmpty()) continue;
            all.append(raw).append('\n');
            Float confidence = line.getConfidence();
            confidenceTotal += confidence == null ? 0.55f : confidence;
            confidenceCount++;

            Matcher pm = PICKUP.matcher(raw);
            Matcher dm = DROPOFF.matcher(raw);
            if (pm.matches()) pickup = cleanPlace(pm.group(1));
            else if (dm.matches()) dropoff = cleanPlace(dm.group(1));

            Matcher money = MONEY.matcher(raw);
            while (money.find()) {
                try { amounts.add(Double.parseDouble(money.group(1).replace(",", ""))); }
                catch (NumberFormatException ignored) { }
            }
            Matcher km = KM.matcher(raw);
            if (km.find()) try { pickupKm = Double.parseDouble(km.group(1)); }
            catch (NumberFormatException ignored) { }
        }

        FareComponents fare = parseFareComponents(all.toString());
        if (fare != null) { baseFare=fare.baseFare; additionalFare=fare.additionalFare; }
        else if (!amounts.isEmpty()) {
            // A single displayed fare is retained as base fare; extra fare is not guessed.
            baseFare = amounts.get(0);
        }

        // Fallback for card layouts that show route names without explicit Pickup/Drop-off labels.
        if (pickup == null || dropoff == null) {
            List<String> placeLines = new ArrayList<>();
            for (Text.Line line : lines) {
                String value = cleanPlace(line.getText());
                if (value == null || isUiOrFareText(value)) continue;
                if (!value.matches(".*\\d.*") && value.length() >= 3) placeLines.add(value);
            }
            if (pickup == null && !placeLines.isEmpty()) pickup = placeLines.get(0);
            if (dropoff == null && placeLines.size() > 1) dropoff = placeLines.get(1);
        }
        if (pickup == null || dropoff == null || !Double.isFinite(baseFare)) return null;
        long now = System.currentTimeMillis();
        float average = confidenceCount == 0 ? 0f : Math.min(1f, confidenceTotal / confidenceCount);
        pickup = PsgcDataset.canonicalize(pickup);
        dropoff = PsgcDataset.canonicalize(dropoff);
        return new Booking(pickup, dropoff, baseFare, additionalFare, pickupKm, average, now, now);
    }

    private static String cleanPlace(String s) {
        if (s == null) return null;
        String value = s.replaceAll("^[\\s:：-]+|[\\s]+$", "")
                .replaceAll("\\s+", " ").trim();
        return value.length() < 2 ? null : value;
    }

    private static boolean isUiOrFareText(String s) {
        String x = s.toLowerCase(Locale.ROOT);
        return x.contains("pick up now") || x.contains("pickup now") || x.contains("drop off")
                || x.contains("php") || x.contains("km") || x.contains("lalamove")
                || x.contains("motorcycle") || x.contains("priority") || x.contains("delivery")
                || x.matches(".*[₱+].*");
    }
}
