package com.riderwise.ai;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class FloatingAssistantService extends Service {
    public static final String PREFS="riderwise_prefs", KEY_VISIBLE="dashboard_visible", KEY_RIDE="ride_mode";
    private WindowManager wm;
    private View panel;
    private TextView content,title;
    private LinearLayout body,controls;
    private WindowManager.LayoutParams params;
    private boolean collapsed=false, paused=false;

    @Override public void onCreate(){
        super.onCreate();
        if(!Settings.canDrawOverlays(this) || !getSharedPreferences(PREFS,0).getBoolean(KEY_VISIBLE,true)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); buildPanel();
    }
    private boolean rideMode(){return getSharedPreferences(PREFS,0).getBoolean(KEY_RIDE,false);}
    private Button action(String label, View.OnClickListener listener){
        Button b=new Button(this); b.setText(label); b.setTextSize(10); b.setPadding(2,0,2,0); b.setMinHeight(36); b.setMinimumHeight(36); b.setOnClickListener(listener); return b;
    }
    private void buildPanel(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(12,8,12,8); box.setBackgroundColor(0xEE202124);
        title=new TextView(this); title.setText("RiderWise AI 2.2  •  "+(rideMode()?"RIDE MODE":"PARKED MODE")); title.setTextColor(0xFFFFA36C); title.setTextSize(13); title.setPadding(4,6,4,8);
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL);
        header.addView(title,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));
        header.addView(action("Expand / Collapse",v->{collapsed=!collapsed;body.setVisibility(collapsed?View.GONE:View.VISIBLE);}),new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT));
        ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        content=new TextView(this); content.setText("Waiting for OCR results…\nUse only while safely parked."); content.setTextColor(0xFFFFFFFF); content.setTextSize(12); content.setPadding(4,4,4,8);
        body.addView(content);
        controls=new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(action(paused?"Resume":"Pause",v->togglePause()));
        controls.addView(action("Stop OCR",v->stopMonitoring()));
        controls.addView(action("Hide",v->{getSharedPreferences(PREFS,0).edit().putBoolean(KEY_VISIBLE,false).apply();stopSelf();}));
        body.addView(controls); scroll.addView(body); box.addView(header); box.addView(scroll); panel=box;
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(rideMode()?220:300,WindowManager.LayoutParams.WRAP_CONTENT,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.END; params.x=12; params.y=180; wm.addView(panel,params);
        title.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;
            @Override public boolean onTouch(View v, MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)(sx-e.getRawX());params.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}
                return e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL;
            }});
    }
    private void togglePause(){
        paused=!paused; Intent i=new Intent(this,ScreenCaptureService.class);i.setAction(paused?"PAUSE":"RESUME");
        startService(i);
        if(controls!=null && controls.getChildCount()>0)((Button)controls.getChildAt(0)).setText(paused?"Resume":"Pause");
        if(content!=null && paused)content.setText("MONITORING PAUSED\nTap Resume to continue.");
    }
    private void stopMonitoring(){
        Intent i=new Intent(this,ScreenCaptureService.class);i.setAction("STOP");
        stopService(new Intent(this,ScreenCaptureService.class));
        if(content!=null)content.setText("OCR monitoring stopped.");
    }
    public static void update(Context c,String text){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("UPDATE");i.putExtra("text",text);
        c.startService(i);
    }
    public static void refreshMode(Context c){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("MODE");
        c.startService(i);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&"UPDATE".equals(i.getAction())&&content!=null)content.setText(i.getStringExtra("text"));
        if(i!=null&&"MODE".equals(i.getAction())&&title!=null)title.setText("RiderWise AI 2.2  •  "+(rideMode()?"RIDE MODE":"PARKED MODE"));
        return START_STICKY;
    }
    @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
