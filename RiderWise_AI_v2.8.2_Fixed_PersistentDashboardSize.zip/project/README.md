# RiderWise AI v2.8.2

## UI and floating dashboard improvements
- Adds a persisted Dark Mode / Light Mode switch in the main app.
- Adds bottom-left and bottom-right resize grips to the expanded floating dashboard.
- Drag either grip horizontally to resize the dashboard; dashboard text scales with width.
- Keeps the existing header drag behavior for moving the panel.
- Attempts to restore/start the floating dashboard when screen monitoring starts, subject to overlay permission and Android background-service rules.
- Capture still briefly hides the dashboard so it does not cover booking cards; it should be restored after each capture attempt.

## Developer config
`app/src/main/assets/riderwise_upgrade_config.json` controls scan interval and feature flags. Scan interval is clamped to 1500–10000 ms.

## Validation required
Build and run GitHub Actions before installing. Test Dark/Light toggle, overlay permission, dashboard show/hide, moving header, both resize grips, text scaling, and repeated OCR capture on the target Android device.
