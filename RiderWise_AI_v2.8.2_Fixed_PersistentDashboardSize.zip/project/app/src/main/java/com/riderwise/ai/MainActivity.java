package com.riderwise.ai;
import android.app.*;import android.content.*;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.appcompat.app.AppCompatDelegate;import java.util.*;
public class MainActivity extends AppCompatActivity {
 private TextView status,mode,referenceInfo; private android.content.SharedPreferences prefs; private Spinner bookingSpinner; private java.util.List<Booking> recent = new ArrayList<>();
 @Override protected void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences(FloatingAssistantService.PREFS,0);
  boolean dark=prefs.getBoolean("dark_mode",false);
  AppCompatDelegate.setDefaultNightMode(dark?AppCompatDelegate.MODE_NIGHT_YES:AppCompatDelegate.MODE_NIGHT_NO);
  PsgcDataset.initialize(getApplicationContext());
  final boolean darkMode=prefs.getBoolean("dark_mode",false);
  final int bg=darkMode?0xFF101827:0xFFF7F7F7, fg=darkMode?0xFFEAF0FA:0xFF202124, secondary=darkMode?0xFFB8C5D8:0xFF4A5568;
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,32,24,24);root.setBackgroundColor(bg);
  TextView title=new TextView(this);title.setText("RiderWise AI v2.8.0");title.setTextSize(25);title.setTextColor(fg);
  TextView sub=new TextView(this);sub.setText("Live Lalamove OCR • Accepted-booking route recommendations");sub.setTextSize(14);sub.setTextColor(secondary);
  TextView geo=new TextView(this);geo.setText("Geographic index: "+(PsgcDataset.isLoaded()?PsgcDataset.size()+" PSA records ("+PsgcDataset.VERSION+")":"not loaded — "+PsgcDataset.getLoadError()));geo.setTextColor(secondary);geo.setPadding(0,8,0,8);
  UpgradeConfig upgradeConfig=UpgradeConfig.get(this);
  TextView configStatus=new TextView(this);configStatus.setText("Developer config: v1 • Scan interval: "+upgradeConfig.scanIntervalMs()+" ms • Modular features loaded");configStatus.setTextColor(secondary);configStatus.setTextSize(12);configStatus.setPadding(0,4,0,8);
  status=new TextView(this);status.setText("Status: Monitoring state is controlled by Android service");status.setTextColor(fg);status.setPadding(0,20,0,12);
  mode=new TextView(this);mode.setTextColor(secondary);updateModeLabel();
  Button themeToggle=new Button(this);themeToggle.setText(darkMode?"Switch to Light Mode":"Switch to Dark Mode");
  themeToggle.setOnClickListener(v->{prefs.edit().putBoolean("dark_mode",!prefs.getBoolean("dark_mode",false)).apply();recreate();});
  Button toggle=new Button(this);updateRideButton(toggle);toggle.setOnClickListener(v->{boolean next=!prefs.getBoolean(FloatingAssistantService.KEY_RIDE,false);prefs.edit().putBoolean(FloatingAssistantService.KEY_RIDE,next).apply();updateModeLabel();updateRideButton(toggle);FloatingAssistantService.refreshMode(this);});
  Button overlay=new Button(this);overlay.setText("Show floating dashboard");overlay.setOnClickListener(v->{prefs.edit().putBoolean(FloatingAssistantService.KEY_VISIBLE,true).apply();if(!Settings.canDrawOverlays(this))PermissionManager.requestOverlay(this);else startService(new Intent(this,FloatingAssistantService.class));});
  Button hide=new Button(this);hide.setText("Hide floating dashboard");hide.setOnClickListener(v->{prefs.edit().putBoolean(FloatingAssistantService.KEY_VISIBLE,false).apply();stopService(new Intent(this,FloatingAssistantService.class));});
  TextView refTitle=new TextView(this);refTitle.setText("Accepted booking reference");refTitle.setTextSize(18);refTitle.setTextColor(fg);refTitle.setPadding(0,22,0,4);
  TextView refHelp=new TextView(this);refHelp.setText("The first confirmed Lalamove acceptance is saved automatically as the reference. Later accepted bookings are saved as accepted history but do not replace it. Use the controls below to clear or replace the reference after completing a delivery.");refHelp.setTextSize(12);refHelp.setTextColor(secondary);
  bookingSpinner=new Spinner(this); referenceInfo=new TextView(this);referenceInfo.setTextColor(fg);referenceInfo.setPadding(0,8,0,8);
  Button setReference=new Button(this);setReference.setText("Replace reference with selected booking");setReference.setOnClickListener(v->{int pos=bookingSpinner.getSelectedItemPosition();if(pos>=0&&pos<recent.size()){boolean ok=new BookingStore(this).setAcceptedReference(recent.get(pos).id);referenceInfo.setText(ok?"Accepted reference set: "+recent.get(pos).pickup+" → "+recent.get(pos).dropoff:"Could not set reference. Refresh detected bookings.");}});
  Button clearReference=new Button(this);clearReference.setText("Clear current reference");clearReference.setOnClickListener(v->{new BookingStore(this).clearReference();referenceInfo.setText("Reference cleared. The next detected accepted booking will become the new first reference.");loadBookings();});
  Button refreshBookings=new Button(this);refreshBookings.setText("Refresh detected bookings");refreshBookings.setOnClickListener(v->loadBookings());
  Button start=new Button(this);start.setText("Authorize and start live screen monitoring");start.setOnClickListener(v->startActivityForResult(PermissionManager.captureIntent(this),PermissionManager.REQUEST_CAPTURE));
  Button stop=new Button(this);stop.setText("Stop monitoring");stop.setOnClickListener(v->{stopService(new Intent(this,ScreenCaptureService.class));status.setText("Status: Stopped");});
  TextView note=new TextView(this);note.setText("Safety: RiderWise is read-only and never accepts bookings. Use only while safely parked. Ride Mode ON makes the floating panel non-touchable; switch it OFF from this app while parked to interact with controls.");note.setTextSize(12);note.setTextColor(secondary);note.setPadding(0,22,0,0);
  root.addView(title);root.addView(sub);root.addView(geo);root.addView(configStatus);root.addView(status);root.addView(mode);root.addView(themeToggle);root.addView(toggle);root.addView(overlay);root.addView(hide);root.addView(refTitle);root.addView(refHelp);root.addView(bookingSpinner);root.addView(setReference);root.addView(clearReference);root.addView(refreshBookings);root.addView(referenceInfo);root.addView(start);root.addView(stop);root.addView(note);setContentView(root);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},5101);
  loadBookings();
  if(prefs.getBoolean(FloatingAssistantService.KEY_VISIBLE,false)&&Settings.canDrawOverlays(this)) startService(new Intent(this,FloatingAssistantService.class));
 }
 private void updateRideButton(Button b){b.setText(prefs.getBoolean(FloatingAssistantService.KEY_RIDE,false)?"Turn Ride Mode OFF":"Turn Ride Mode ON");}
 private void loadBookings(){recent=new BookingStore(this).getRecent();ArrayList<String> labels=new ArrayList<>();for(Booking b:recent)labels.add((b.reference?"✓ ACCEPTED • ":"")+b.pickup+" → "+b.dropoff+" • ₱"+String.format(Locale.US,"%.2f",b.totalFare));if(labels.isEmpty())labels.add("No detected bookings yet");ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);bookingSpinner.setAdapter(a);Booking ref=new BookingStore(this).getReference();referenceInfo.setText(ref==null?"No accepted reference selected yet.":"Current reference: "+ref.pickup+" → "+ref.dropoff);}
 @Override protected void onResume(){super.onResume();if(prefs!=null){updateModeLabel();if(prefs.getBoolean(FloatingAssistantService.KEY_VISIBLE,false)&&Settings.canDrawOverlays(this))startService(new Intent(this,FloatingAssistantService.class));if(bookingSpinner!=null)loadBookings();}}
 private void updateModeLabel(){mode.setText(prefs.getBoolean(FloatingAssistantService.KEY_RIDE,false)?"Ride Mode: ON (floating panel non-touchable)":"Ride Mode: OFF (floating panel interactive)");}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PermissionManager.REQUEST_CAPTURE&&c==RESULT_OK&&d!=null){Intent i=new Intent(this,ScreenCaptureService.class);i.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE,c);i.putExtra(ScreenCaptureService.EXTRA_DATA,d);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);status.setText("Status: Live capture authorization granted; service starting");}else status.setText("Status: Capture permission not granted");}
}
