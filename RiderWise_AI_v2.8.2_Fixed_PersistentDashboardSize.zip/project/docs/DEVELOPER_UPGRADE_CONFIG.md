# Developer Upgrade Config

Source: `app/src/main/assets/riderwise_upgrade_config.json`

## Scan
- `interval_ms`: requested scan interval. Runtime clamps this to 1500–10000 ms to avoid excessive capture load.

## Feature flags
- `screen_capture`
- `booking_ocr`
- `visual_booking_count`
- `accepted_booking_detection`
- `accepted_booking_history`
- `first_reference_protection`
- `route_recommendations`
- `floating_dashboard`
- `diagnostics_logging`

Missing feature flags default to enabled for backward compatibility.

## Safety
- `read_only` defaults to true.
- `auto_accept_bookings` and `auto_reject_bookings` default to false and are not implemented as actions.

After editing the JSON, rebuild the APK. Config is local to the APK; no network or remote config is used.
