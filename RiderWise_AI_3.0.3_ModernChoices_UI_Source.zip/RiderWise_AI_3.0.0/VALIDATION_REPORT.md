# RiderWise AI 3.0 — Booking Intelligence validation report

## Changes in this source revision

- Promoted Android version to 3.0.0 and database schema to v6.
- Added a persistent seven-day booking history query (up to 500 records) so bookings encountered while manually scrolling remain available for later comparison.
- Added `seen_count` tracking and changed booking upserts to update existing rows in place instead of `CONFLICT_REPLACE`; this preserves original row identity and first-seen ordering when an old booking resurfaces.
- Changed history ordering to stable `first_seen` order, retaining same-frame top-to-bottom insertion order.
- Changed OCR extraction to assign one timestamp to all cards in the same captured frame. This preserves top-to-bottom insertion order for cards first seen together.
- Added expanded-address line grouping so nearby comma-rich address detail lines attach to their preceding place heading instead of being mistaken for a second route endpoint.
- Added conservative collapsed/expanded reconciliation by pickup, fare, address containment, and booking-code agreement; it merges only when exactly one existing record matches.
- Expanded bare-place OCR acceptance for exact PSGC names and selected Lalamove route names, including ambiguous `San Mateo`; ambiguous text is retained for verification, not silently assigned to a location.
- Added reference-free route-pair recommendations when no accepted reference booking exists. The engine compares only known local coordinates, checks vehicle compatibility when available, and displays suggestions as route similarity rather than guaranteed combined jobs.
- Added dashboard diagnostics for new unique bookings versus previously seen bookings resurfacing.
- Kept the accepted-reference recommendation path unchanged in principle: deterministic validation and route rules remain authoritative, local AI may only rank supplied validated recommendations.
- No automated scrolling, tapping, accepting, or rejecting was added.

## Checks completed in this environment

- Source-level review of booking extraction, SQLite migration, persistent upsert, scroll-history retrieval, and recommendation flow.
- JSON developer configuration parsed and updated to target 3.0.0.
- Added JUnit cases for reference-free similar-route suggestions and refusal to invent routes when coordinates are missing.
- `RecommendationEngine`, `BookingStore`, and `BookingExtractor` passed Java 17 syntax/type compilation against lightweight API-shaped stubs. A standalone logic harness using the real geographic centroid table confirmed the example `San Mateo → Quezon Avenue` / `San Mateo → Batasan` pair is surfaced as `POTENTIALLY COMPATIBLE`. This is not a substitute for the Android build or full JUnit run.
- Added JUnit cases are source artifacts only; they have not yet been executed by Gradle.

## Checks not completed / release blockers

- Full Gradle compilation and unit-test execution are not verified in this environment. The Gradle wrapper previously could not fetch Gradle 8.9 because `services.gradle.org` was unreachable.
- No APK is claimed as built.
- No physical-device test has been performed on the Oppo Reno 5 or the exact Lalamove UI shown in the supplied photos.
- OCR extraction accuracy, orange-header segmentation, card ordering, duplicate resurfacing, expanded-address reconciliation, and reference-free recommendations must be tested against real screen captures.
- Fast scrolling can move multiple cards past the 2.5-second scan cadence. The app does not auto-scroll and cannot infer cards it never captured.
- Same route/fare fingerprints deduplicate reliably. Collapsed/expanded address text is reconciled when there is exactly one safe match. If Lalamove changes the fare or endpoint text materially, or multiple records are equally plausible, a resurfaced booking may still remain separate unless a stable booking code is visible.
- Actual LiteRT-LM model loading/inference, model download integrity, and Oppo Reno 5 memory/thermal performance remain unverified.

## Safety and data limitations

- Booking memory is local and retained for a rolling seven-day query window; it is not a server-side mirror of Lalamove's full 30-booking queue.
- Only cards actually visible in captured frames can be recognized.
- Reference-free recommendations are pairwise route-similarity candidates using the app's available approximate geographic centroids. They are not proof of road-route compatibility or permission to combine bookings.
- Straight-line estimates are not road distance, traffic, or ETA.
- Ambiguous geographic names remain unverified until full address context or driver confirmation is available.
- The app remains read-only and does not interact with Lalamove controls.

## Existing offline AI limitations

- Gemma 4 E2B remains configured for local inference; actual runtime compatibility and device performance are unverified.
- If the local model is missing or fails, deterministic OCR and recommendations continue.
- No Gemini or other online AI API is included. Internet remains necessary only for the user's one-time model download and normal build dependencies.

## Required physical-device acceptance tests

1. Show two full cards plus a partial third card; confirm independent extraction and partial status.
2. Scroll through 30 available bookings slowly; confirm every captured card is retained in local history.
3. Make an old booking resurface at the top; confirm it increments seen count and is not marked as newly discovered.
4. Scroll away and back; confirm the original booking identity and first-seen order remain stable.
5. Expand a collapsed card; confirm the full address is matched to the existing record without accidental duplicate recommendation.
6. With no reference, test San Mateo → Quezon Avenue and San Mateo → Batasan; show a route-similarity suggestion only if the geographic coordinates resolve.
7. With an accepted reference, confirm reference-based compatibility remains active and the reference does not change automatically.
8. Scroll rapidly; document any missed screens and verify that the app does not claim to have scanned unseen bookings.
9. Verify no automatic taps, scrolling, acceptance, or rejection occur.
10. Verify offline OCR/rules fallback when the local LLM is not loaded.


## 3.0.2 persistent queue dashboard integration

- Added a Saved recommendations dashboard action and review dialog.
- Added display of saved recommendation status, score, first/last timestamps, and availability evidence.
- Added local dismiss/archive controls. The archive action is explicitly not an Lalamove acceptance action and does not change the active reference booking.
- Queue entries not refreshed by the latest recommendation pass are marked stale / not re-confirmed, not expired.
- Gradle compilation was attempted with `./gradlew :app:compileDebugJavaWithJavac --offline`; the wrapper still attempted to fetch Gradle 8.9 and failed because `services.gradle.org` could not be resolved. No APK or device test is claimed.
