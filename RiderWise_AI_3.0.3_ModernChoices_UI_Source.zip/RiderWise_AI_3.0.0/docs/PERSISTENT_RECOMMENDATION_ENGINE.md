# RiderWise AI 3.0.1 — Persistent Recommendation Engine

Adds a local SharedPreferences-backed recommendation queue wired into accepted-reference and reference-free recommendation passes.

- Recommendation keys use sorted booking fingerprints, not screen position.
- Refresh updates last-seen time while preserving first-seen time.
- Candidates absent from a later recommendation pass remain saved as NOT_VISIBLE_LAST_SCAN; viewport absence is not expiry.
- Accepted and driver-dismissed entries are not silently resurrected.
- Queue is bounded to 200 entries; scan diagnostics display up to five.
- Off-screen availability is explicitly unverified.

## Limitations
- The queue persists recommendations produced by the existing deterministic engine; it cannot detect cards never captured by OCR.
- Fast scrolling can still cause missed cards.
- Manual dashboard actions to mark a candidate accepted/dismissed and locate it in Lalamove are not yet implemented.
- Fingerprints can collide for distinct offers with identical endpoints/fare and no booking code.
- Full Gradle build and device validation remain required.
