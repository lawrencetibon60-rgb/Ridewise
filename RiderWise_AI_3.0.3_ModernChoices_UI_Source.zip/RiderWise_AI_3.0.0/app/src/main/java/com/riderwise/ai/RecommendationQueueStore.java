package com.riderwise.ai;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
/** Durable recommendation queue. Off-screen does not mean unavailable. */
public final class RecommendationQueueStore {
 public static final String RECOMMENDED="RECOMMENDED", NEEDS_VERIFICATION="NEEDS_ADDRESS_VERIFICATION",
 NOT_VISIBLE="NOT_VISIBLE_LAST_SCAN", STALE="STALE_UNVERIFIED", ACCEPTED="ACCEPTED", DISMISSED="REJECTED_BY_DRIVER";
 private static final String PREFS="riderwise_recommendation_queue", DATA="entries";
 private final SharedPreferences prefs;
 public static final class Entry {
  public final String key,state,description,availability; public final long firstSeen,lastSeen; public final double score;
  Entry(String k,String s,String d,String a,long f,long l,double sc){key=k;state=s;description=d;availability=a;firstSeen=f;lastSeen=l;score=sc;}
 }
 public RecommendationQueueStore(Context c){prefs=c.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
 public synchronized void refresh(List<RecommendationEngine.Recommendation> recs,long now,boolean needsVerification){
  JSONArray old=read(), next=new JSONArray(); Set<String> keys=new HashSet<>();
  try{
   for(int i=0;i<old.length();i++){JSONObject o=old.optJSONObject(i);if(o==null)continue;String k=o.optString("key","");
    if(k.isEmpty()||!keys.add(k))continue;String st=o.optString("state",RECOMMENDED);
    if(!ACCEPTED.equals(st)&&!DISMISSED.equals(st)){o.put("state",STALE);o.put("availability","NOT_RECONFIRMED_IN_LATEST_RECOMMENDATION_PASS");} next.put(o);
   }
   if(recs!=null)for(RecommendationEngine.Recommendation r:recs){if(r==null||r.bookings==null||r.bookings.isEmpty())continue;
    List<String> ids=new ArrayList<>();StringBuilder desc=new StringBuilder();
    for(Booking b:r.bookings){if(b==null)continue;ids.add(b.fingerprint);if(desc.length()>0)desc.append(" + ");desc.append(b.pickup).append(" → ").append(b.dropoff);}
    Collections.sort(ids);String key=android.util.Base64.encodeToString(String.join("||",ids).getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
    JSONObject prior=find(next,key);String priorState=prior==null?"":prior.optString("state","");
    if(ACCEPTED.equals(priorState)||DISMISSED.equals(priorState))continue;
    JSONObject item=new JSONObject();item.put("key",key);item.put("state",needsVerification?NEEDS_VERIFICATION:RECOMMENDED);
    item.put("description",desc.toString());item.put("first_seen",prior==null?now:prior.optLong("first_seen",now));
    item.put("last_seen",now);item.put("score",r.score);item.put("availability","SEEN_AT_LAST_SCAN");replace(next,key,item);
   }
   JSONArray bounded=new JSONArray();for(int i=Math.max(0,next.length()-200);i<next.length();i++)bounded.put(next.get(i));
   prefs.edit().putString(DATA,bounded.toString()).apply();
  }catch(Exception ignored){}
 }
 public synchronized void mark(String key,String state){JSONArray a=read();try{for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&key.equals(o.optString("key",""))){o.put("state",state);if(ACCEPTED.equals(state)||DISMISSED.equals(state))o.put("availability","NO_LONGER_IN_RECOMMENDATION_QUEUE");}}prefs.edit().putString(DATA,a.toString()).apply();}catch(Exception ignored){}}
 public synchronized List<Entry> getEntries(){JSONArray a=read();List<Entry> out=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(new Entry(o.optString("key",""),o.optString("state",STALE),o.optString("description",""),o.optString("availability","UNVERIFIED"),o.optLong("first_seen"),o.optLong("last_seen"),o.optDouble("score",0)));}return out;}
 public synchronized Entry getEntry(String key){for(Entry e:getEntries())if(e.key.equals(key))return e;return null;}
 public synchronized int countActive(){int n=0;for(Entry e:getEntries())if(!ACCEPTED.equals(e.state)&&!DISMISSED.equals(e.state))n++;return n;}
 public synchronized String summary(){StringBuilder b=new StringBuilder();int n=0;for(Entry e:getEntries()){if(ACCEPTED.equals(e.state)||DISMISSED.equals(e.state)||n++>=5)continue;b.append("\\nSAVED ").append(e.state).append(": ").append(e.description).append(" • score ").append(Math.round(e.score*100)).append("/100 • last recommended ").append(new java.text.SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date(e.lastSeen))).append(" • ").append(e.availability).append(" (not a live availability guarantee)");}return b.toString();}
 private JSONArray read(){try{return new JSONArray(prefs.getString(DATA,"[]"));}catch(Exception e){return new JSONArray();}}
 private static JSONObject find(JSONArray a,String k){for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&k.equals(o.optString("key","")))return o;}return null;}
 private static void replace(JSONArray a,String k,JSONObject v) throws org.json.JSONException {for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&k.equals(o.optString("key",""))){a.put(i,v);return;}}a.put(v);}
}
