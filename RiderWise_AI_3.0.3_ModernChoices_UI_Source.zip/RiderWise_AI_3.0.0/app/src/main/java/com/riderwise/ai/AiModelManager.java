package com.riderwise.ai;

import android.content.Context;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads the on-device LLM into private app storage; never bundles weights in the APK. */
public final class AiModelManager {
    public static final String RECOMMENDED_MODEL = "Gemma 4 E2B IT (LiteRT-LM mobile artifact)";
    public static final String MODEL_FILE_NAME = "gemma-4-E2B-it.litertlm";
    public static final String MODEL_REPOSITORY = "litert-community/gemma-4-E2B-it-litert-lm";
    public static final String MODEL_URL = "https://huggingface.co/" + MODEL_REPOSITORY
            + "/resolve/main/" + MODEL_FILE_NAME + "?download=true";
    public static final long MIN_VALID_MODEL_BYTES = 100L * 1024L * 1024L;
    private static final ExecutorService DOWNLOADS = Executors.newSingleThreadExecutor();
    private AiModelManager() { }

    public interface DownloadCallback {
        void onProgress(long downloadedBytes, long totalBytes);
        void onComplete(File modelFile);
        void onError(String message);
    }

    public static File modelFile(Context context) {
        File directory=new File(context.getFilesDir(),"models");
        if(!directory.exists()) directory.mkdirs();
        return new File(directory,MODEL_FILE_NAME);
    }
    public static boolean modelFilePresent(Context context) {
        File file=modelFile(context);
        return file.isFile() && file.length() >= MIN_VALID_MODEL_BYTES;
    }

    /** User-initiated download. The model is approximately 2.6 GB; use Wi-Fi and ample storage. */
    public static void downloadModel(Context context, DownloadCallback callback) {
        Context app=context.getApplicationContext();
        DOWNLOADS.execute(() -> {
            File target=modelFile(app);
            File partial=new File(target.getParentFile(),target.getName()+".part");
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL(MODEL_URL).openConnection();
                connection.setConnectTimeout(30000); connection.setReadTimeout(60000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent","RiderWiseAI/3.0.0");
                connection.connect();
                int status=connection.getResponseCode();
                if(status<200||status>=300) throw new java.io.IOException("Model host returned HTTP "+status);
                long total=connection.getContentLengthLong();
                try(BufferedInputStream in=new BufferedInputStream(connection.getInputStream());
                    BufferedOutputStream out=new BufferedOutputStream(new FileOutputStream(partial,false))) {
                    byte[] buffer=new byte[1024*1024]; int count; long downloaded=0; long lastReport=0;
                    while((count=in.read(buffer))!=-1) {
                        out.write(buffer,0,count); downloaded+=count;
                        if(callback!=null && (downloaded-lastReport>=4L*1024L*1024L || (total>0&&downloaded==total))) {
                            callback.onProgress(downloaded,total); lastReport=downloaded;
                        }
                    }
                }
                if(partial.length()<MIN_VALID_MODEL_BYTES) throw new java.io.IOException("Downloaded model is too small; file may be incomplete.");
                if(target.exists()&&!target.delete()) throw new java.io.IOException("Cannot replace previous model file.");
                if(!partial.renameTo(target)) throw new java.io.IOException("Cannot finalize downloaded model file.");
                if(callback!=null) callback.onComplete(target);
            } catch(Exception e) {
                // Preserve no partial artifact that could be mistaken for an installed model.
                // The partial is intentionally kept for diagnosis only and is not loadable.
                if(callback!=null) callback.onError(e.getMessage()==null?"Model download failed":e.getMessage());
            } finally { if(connection!=null) connection.disconnect(); }
        });
    }

    public static String statusSummary(Context context) {
        File f=modelFile(context);
        if(!modelFilePresent(context)) return "Local LLM: Not installed. Download " + RECOMMENDED_MODEL
                + " separately (about 2.6 GB). Offline OCR and deterministic rules continue working.";
        return "Local LLM model downloaded ("+(f.length()/(1024L*1024L))+" MB). Load it to start offline AI inference.";
    }
}
