package com.riderwise.ai;

import android.content.Context;
import android.util.Log;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Loads developer feature flags from app/src/main/assets/riderwise_upgrade_config.json.
 * Invalid or missing settings fall back to safe defaults.
 */
public final class UpgradeConfig {
    private static final String TAG = "RiderWiseConfig";
    private static volatile UpgradeConfig instance;
    private final JSONObject root;
    private UpgradeConfig(JSONObject root) { this.root = root; }

    public static UpgradeConfig get(Context context) {
        UpgradeConfig local = instance;
        if (local == null) {
            synchronized (UpgradeConfig.class) {
                local = instance;
                if (local == null) instance = local = load(context.getApplicationContext());
            }
        }
        return local;
    }

    private static UpgradeConfig load(Context context) {
        try (InputStream in = context.getAssets().open("riderwise_upgrade_config.json");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            JSONObject parsed = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            Log.i(TAG, "Developer config loaded");
            return new UpgradeConfig(parsed);
        } catch (Exception error) {
            Log.e(TAG, "Config unavailable; using safe defaults", error);
            return new UpgradeConfig(new JSONObject());
        }
    }

    public long scanIntervalMs() {
        long value = root.optJSONObject("scan") == null ? 2500L
                : root.optJSONObject("scan").optLong("interval_ms", 2500L);
        return Math.max(2500L, Math.min(10000L, value));
    }

    public boolean enabled(String feature) {
        JSONObject features = root.optJSONObject("features");
        if (features == null) return true;
        return features.optBoolean(feature, true);
    }

    public boolean readOnly() {
        JSONObject safety = root.optJSONObject("safety");
        return safety == null || safety.optBoolean("read_only", true);
    }

    public boolean autoAcceptAllowed() {
        JSONObject safety = root.optJSONObject("safety");
        return safety != null && safety.optBoolean("auto_accept_bookings", false);
    }

    public boolean autoRejectAllowed() {
        JSONObject safety = root.optJSONObject("safety");
        return safety != null && safety.optBoolean("auto_reject_bookings", false);
    }

    /** Intended for tests or a future developer reload action. */
    static synchronized void resetForTests() { instance = null; }
}
