package com.riderwise.ai;
import java.util.*;
public final class GeographicDataset {
 public static final String VERSION="2.2-luzon-psgc-3q-2026";
 public static final class Place {
  public final String name,province,region,type,administrativeClassification,coordinateStatus,coordinateSource,verificationStatus; public final double lat,lon; public final float confidence; public final Set<String> aliases;
  Place(String n,String p,String r,String t,double a,double o,String status,String source,String verification,float c,String... al){
   name=n;province=p;region=r;type=t;administrativeClassification=t;lat=a;lon=o;coordinateStatus=status;coordinateSource=source;verificationStatus=verification;confidence=c;
   aliases=new HashSet<>();aliases.add(BookingValidator.normalize(n));for(String x:al)aliases.add(BookingValidator.normalize(x));
  }
  public boolean hasCoordinates(){return Double.isFinite(lat)&&Double.isFinite(lon);}
 }
 private static final Map<String,List<Place>> INDEX=new HashMap<>();
 private GeographicDataset(){}
 public static void initialize(android.content.Context context){PsgcDataset.initialize(context.getApplicationContext());}
 public static PsgcDataset.Record resolveAdministrative(String name){return PsgcDataset.resolve(name);}
 public static PsgcDataset.Record resolveAdministrative(String name,String parent){return PsgcDataset.resolve(name,parent);}
 public static java.util.List<PsgcDataset.Record> searchAdministrative(String query,int limit){return PsgcDataset.search(query,limit);}
 public static PsgcDataset.Record getAdministrativeByPsgc(String code){return PsgcDataset.byPsgc(code);}

 static{
  // Approximate city/area centroids. Only populated entries have coordinates; unresolved places are not assigned invented points.
  add("Quezon City","NCR","NCR","city",14.6760,121.0437,0.85f,"QC");
  add("Manila","NCR","NCR","city",14.5995,120.9842,0.9f);
  add("Caloocan","NCR","NCR","city",14.6488,120.9672,0.75f);
  add("Makati","NCR","NCR","city",14.5547,121.0244,0.9f);
  add("Taguig","NCR","NCR","city",14.5176,121.0509,0.85f);
  add("Pasig","NCR","NCR","city",14.5764,121.0851,0.85f);
  add("Marikina","NCR","NCR","city",14.6507,121.1029,0.85f);
  add("Mandaluyong","NCR","NCR","city",14.5794,121.0359,0.85f);
  add("San Juan","NCR","NCR","city",14.6019,121.0355,0.8f);
  add("Parañaque","NCR","NCR","city",14.4793,121.0198,0.8f,"Paranaque","Paranaque City","Parañaque City");
  add("Las Piñas","NCR","NCR","city",14.4453,120.9828,0.8f,"Las Pinas");
  add("Muntinlupa","NCR","NCR","city",14.4081,121.0415,0.8f);
  add("Pasay","NCR","NCR","city",14.5378,121.0014,0.8f);
  add("Valenzuela","NCR","NCR","city",14.7011,120.9830,0.8f);
  add("Malabon","NCR","NCR","city",14.6681,120.9653,0.8f);
  add("Navotas","NCR","NCR","city",14.6730,120.9350,0.8f);
  add("Pateros","NCR","NCR","municipality",14.5447,121.0680,0.75f);
  add("San Mateo","Rizal","IV-A","municipality",14.6982,121.1236,0.8f);
  add("Antipolo","Rizal","IV-A","city",14.6255,121.1245,0.8f);
  add("Cainta","Rizal","IV-A","municipality",14.5786,121.1222,0.8f);
  add("Batasan","Quezon City","NCR","area",14.6917,121.0950,0.75f);
  add("Commonwealth","Quezon City","NCR","area",14.6910,121.0830,0.75f);
  add("Holy Spirit","Quezon City","NCR","area",14.6870,121.0770,0.75f);
  add("Diliman","Quezon City","NCR","area",14.6536,121.0685,0.8f);
  add("Quezon Avenue","Quezon City","NCR","area",14.6426,121.0380,0.8f);
  add("Fairview","Quezon City","NCR","area",14.7350,121.0580,0.8f);
  add("Alabang","Muntinlupa","NCR","area",14.4190,121.0437,0.8f);
  add("BGC","Taguig","NCR","area",14.5500,121.0500,0.7f,"Bonifacio Global City");
  add("Sta. Rosa","Laguna","IV-A","city",14.3122,121.1114,0.75f,"Santa Rosa");
  add("Angeles","Pampanga","III","city",15.1450,120.5887,0.8f);
  add("San Fernando","Pampanga","III","city",15.0343,120.6844,0.8f);
  add("Malolos","Bulacan","III","city",14.8433,120.8114,0.8f);
  add("Cabanatuan","Nueva Ecija","III","city",15.4860,120.9730,0.8f);
  add("Tarlac City","Tarlac","III","city",15.4755,120.5963,0.8f);
  add("Olongapo","Zambales","III","city",14.8292,120.2828,0.8f);
  add("Baguio","Benguet","CAR","city",16.4023,120.5960,0.85f);
  add("Dagupan","Pangasinan","I","city",16.0430,120.3330,0.8f);
  add("Laoag","Ilocos Norte","I","city",18.1978,120.5957,0.8f);
  add("Vigan","Ilocos Sur","I","city",17.5747,120.3869,0.8f);
  add("Tuguegarao","Cagayan","II","city",17.6132,121.7270,0.8f);
  add("Ilagan","Isabela","II","city",17.1480,121.8890,0.75f);
  add("Lucena","Quezon","IV-A","city",13.9411,121.6230,0.8f);
  add("Batangas City","Batangas","IV-A","city",13.7565,121.0583,0.8f);
  add("Calamba","Laguna","IV-A","city",14.2117,121.1653,0.8f);
  add("Naga","Camarines Sur","V","city",13.6218,123.1948,0.8f);
  add("Legazpi","Albay","V","city",13.1391,123.7438,0.8f);
  // Named places included for coverage; coordinates remain unresolved until verified from an authoritative source.
  addUnresolved("Puerto Princesa","Palawan","IV-B","city");
  addUnresolved("Calapan","Oriental Mindoro","IV-B","city");
  addUnresolved("Boac","Marinduque","IV-B","municipality");
  addUnresolved("Romblon","Romblon","IV-B","municipality");
  addUnresolved("San Jose","Occidental Mindoro","IV-B","municipality");
  addUnresolved("Tabuk","Kalinga","CAR","city");
  addUnresolved("Bontoc","Mountain Province","CAR","municipality");
  addUnresolved("La Trinidad","Benguet","CAR","municipality");
  addUnresolved("San Carlos","Pangasinan","I","city");
  addUnresolved("Urdaneta","Pangasinan","I","city");
  addUnresolved("Aparri","Cagayan","II","municipality");
  addUnresolved("Santiago","Isabela","II","city");
  addUnresolved("Baliwag","Bulacan","III","city");
  addUnresolved("Meycauayan","Bulacan","III","city");
  addUnresolved("San Jose City","Nueva Ecija","III","city");
  addUnresolved("Trece Martires","Cavite","IV-A","city");
  addUnresolved("Dasmarinas","Cavite","IV-A","city","Dasmariñas");
  addUnresolved("Lipa","Batangas","IV-A","city");
  addUnresolved("Tanauan","Batangas","IV-A","city");
  addUnresolved("San Pablo","Laguna","IV-A","city");
  addUnresolved("Tayabas","Quezon","IV-A","city");
  addUnresolved("Sorsogon City","Sorsogon","V","city");
  addUnresolved("Masbate City","Masbate","V","city");
  addUnresolved("Virac","Catanduanes","V","municipality");
 }
 private static void add(String n,String p,String r,String t,double lat,double lon,float c,String...aliases){
  Place x=new Place(n,p,r,t,lat,lon,"APPROXIMATE_CENTROID",
    "Legacy v2.1 embedded dataset; original coordinate provenance not supplied",
    "UNVERIFIED",c,aliases);
  index(x);
 }
 private static void addUnresolved(String n,String p,String r,String t,String...aliases){
  Place x=new Place(n,p,r,t,Double.NaN,Double.NaN,"UNRESOLVED",
    "No coordinate source supplied; intentionally not geocoded","UNVERIFIED",0f,aliases);
  index(x);
 }
 private static void index(Place x){
  for(String key:x.aliases)INDEX.computeIfAbsent(key,k->new ArrayList<>()).add(x);
 }
 public static final class LocationMatch {
  /** Exact PSGC record identified from OCR text, e.g. Barangay Tatalon. */
  public final PsgcDataset.Record matchedRecord;
  /** Parent city/municipality used for coarse geographic comparison. */
  public final PsgcDataset.Record localityRecord;
  /** Existing coordinate entry for the locality; it may be an unverified city centroid. */
  public final Place coordinatePlace;
  public final boolean usesParentLocality;
  public final boolean inferredFromContext;
  LocationMatch(PsgcDataset.Record matched,PsgcDataset.Record locality,Place point,boolean parent) {
   this(matched,locality,point,parent,false);
  }
  LocationMatch(PsgcDataset.Record matched,PsgcDataset.Record locality,Place point,boolean parent,boolean inferred) {
   matchedRecord=matched; localityRecord=locality; coordinatePlace=point; usesParentLocality=parent;
   inferredFromContext=inferred;
  }
  public boolean hasApproximateLocalityCoordinates() {
   return coordinatePlace!=null && coordinatePlace.hasCoordinates()
     && "APPROXIMATE_CENTROID".equals(coordinatePlace.coordinateStatus);
  }
 }
 public static LocationMatch resolveLocation(String raw){
  return resolveLocation(raw, null);
 }
 public static LocationMatch resolveLocation(String raw, String referenceLocalityHint){
  PsgcDataset.LocationResolution admin=PsgcDataset.resolveLocation(raw, referenceLocalityHint);
  if(admin!=null){
   Place coordinate=findPlace(admin.localityRecord.name);
   return new LocationMatch(admin.matchedRecord,admin.localityRecord,coordinate,admin.resolvedFromBarangay,admin.inferredFromContext);
  }
  Place direct=findPlace(raw);
  return direct==null?null:new LocationMatch(null,null,direct,false);
 }
 private static Place findPlace(String name){
  if(name==null)return null;
  List<Place> p=INDEX.get(BookingValidator.normalize(name));
  if(p==null&&name.startsWith("City of "))p=INDEX.get(BookingValidator.normalize(name.substring(8)));
  if(p==null&&name.startsWith("Municipality of "))p=INDEX.get(BookingValidator.normalize(name.substring(16)));
  return p!=null&&p.size()==1?p.get(0):null;
 }
 public static Place resolve(String raw){
  LocationMatch match=resolveLocation(raw);
  return match==null?null:match.coordinatePlace;
 }
 public static Place resolve(String raw,String province){List<Place> p=INDEX.get(BookingValidator.normalize(raw));if(p==null)return null;for(Place x:p)if(province!=null&&x.province.equalsIgnoreCase(province))return x;return p.size()==1?p.get(0):null;}
 public static Point get(String name){Place p=resolve(name);return p==null||!p.hasCoordinates()?null:new Point(p.lat,p.lon);}
 public static Set<String> names(){return Collections.unmodifiableSet(INDEX.keySet());}
 public static final class Point{public final double lat,lon;Point(double a,double o){lat=a;lon=o;}}
}
