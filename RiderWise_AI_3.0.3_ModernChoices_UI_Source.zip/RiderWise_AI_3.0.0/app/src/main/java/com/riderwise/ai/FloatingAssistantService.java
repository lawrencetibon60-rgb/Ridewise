package com.riderwise.ai;

import android.app.Service;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact, draggable RiderWise dashboard with a high-contrast live analysis view. */
public class FloatingAssistantService extends Service {
    private static volatile FloatingAssistantService activeInstance;
    public static final String PREFS="riderwise_prefs", KEY_VISIBLE="dashboard_visible", KEY_RIDE="ride_mode";
    private WindowManager wm;
    private View panel;
    private TextView content,title,status,modeLabel;
    private LinearLayout body,controls;
    private ScrollView dashboardScroll;
    private WindowManager.LayoutParams params;
    private boolean collapsed=true, paused=false;
    private Button toggleButton, savedButton;
    private RecommendationQueueStore recommendationQueue;
    private View resizeLeft, resizeRight;
    private LinearLayout resizeRow;
    private int minPanelWidth, maxPanelWidth;
    private static final String KEY_DASHBOARD_WIDTH_DP = "dashboard_width_dp";
    private static final String KEY_DASHBOARD_HEIGHT_DP = "dashboard_height_dp";
    private int minPanelHeight, maxPanelHeight;
    private int dp(float value){ return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int color,int stroke,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    @Override public void onCreate(){
        super.onCreate();
        if(!Settings.canDrawOverlays(this) || !getSharedPreferences(PREFS,0).getBoolean(KEY_VISIBLE,true)){stopSelf();return;}
        activeInstance = this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); recommendationQueue=new RecommendationQueueStore(this); buildPanel();
    }

    /** Hide the floating panel while a screenshot is captured so it cannot cover booking cards. */
    public static void setTemporarilyHiddenForCapture(boolean hidden) {
        FloatingAssistantService service = activeInstance;
        if (service != null && service.panel != null) {
            service.panel.setVisibility(hidden ? View.GONE : View.VISIBLE);
        }
    }
    private boolean rideMode(){return getSharedPreferences(PREFS,0).getBoolean(KEY_RIDE,false);}
    private Button action(String label, View.OnClickListener listener){
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setAllCaps(false);
        b.setTextColor(0xFFEAF2FF); b.setPadding(dp(8),0,dp(8),0); b.setMinHeight(dp(42)); b.setMinimumHeight(dp(42));
        b.setBackground(shape(0xFF172844,0xFF42618C,14)); b.setOnClickListener(listener); return b;
    }
    private void buildPanel(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12),dp(10),dp(12),dp(10)); box.setBackground(shape(0xF20A1428,0xFF4A91FF,22));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        title=text("◉  RiderWise AI",18,0xFFF4F7FF,true);
        modeLabel=text("RIDE MODE: OFF",9,0xFF8FB8FF,true);
        brand.addView(title); brand.addView(modeLabel);
        header.addView(brand,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));
        status=text("● LIVE",10,0xFF6EF0A0,true);
        status.setPadding(dp(10),dp(7),dp(10),dp(7)); status.setBackground(shape(0xFF123B34,0xFF237D65,20));
        header.addView(status);
        toggleButton=action("Show",v->toggleExpanded());
        header.addView(toggleButton);
        box.addView(header);
        View rule=new View(this); rule.setBackgroundColor(0xFF263B5B);
        LinearLayout.LayoutParams ruleLp=new LinearLayout.LayoutParams(-1,dp(1)); ruleLp.topMargin=dp(10); ruleLp.bottomMargin=dp(9);
        box.addView(rule,ruleLp);

        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); dashboardScroll=scroll; scroll.setFillViewport(false);
        LinearLayout detailCard=new LinearLayout(this); detailCard.setOrientation(LinearLayout.VERTICAL);
        detailCard.setPadding(dp(12),dp(11),dp(12),dp(11)); detailCard.setBackground(shape(0xFF111F38,0xFF2C4770,16));
        TextView heading=text("LIVE ANALYSIS",10,0xFF8FB8FF,true);
        heading.setPadding(0,0,0,dp(7)); detailCard.addView(heading);
        content=text("Waiting for screen reading…\nKeep the app visible and use monitoring only while safely stopped.",13,0xFFE7EEFC,false);
        content.setLineSpacing(dp(3),1f); detailCard.addView(content);
        body.addView(detailCard);
        controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0,dp(9),0,0);
        controls.addView(action("Ⅱ  Pause",v->togglePause()),new LinearLayout.LayoutParams(0,dp(44),1f));
        savedButton=action("Saved ("+recommendationQueue.countActive()+")",v->showSavedRecommendations());
        controls.addView(savedButton,new LinearLayout.LayoutParams(0,dp(44),1f));
        controls.addView(action("■  Stop",v->stopMonitoring()),new LinearLayout.LayoutParams(0,dp(44),1f));
        controls.addView(action("Hide",v->{getSharedPreferences(PREFS,0).edit().putBoolean(KEY_VISIBLE,false).apply();stopSelf();}),new LinearLayout.LayoutParams(0,dp(44),1f));
        body.addView(controls); scroll.addView(body);
        int savedHeightDp=getSharedPreferences(PREFS,0).getInt(KEY_DASHBOARD_HEIGHT_DP,300);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(savedHeightDp)));
        box.addView(scroll); panel=box;
        resizeRow = new LinearLayout(this);
        resizeRow.setOrientation(LinearLayout.HORIZONTAL);
        resizeRow.setGravity(Gravity.CENTER_VERTICAL);
        resizeLeft = resizeGrip("◀");
        View spacer = new View(this);
        resizeRow.addView(resizeLeft, new LinearLayout.LayoutParams(dp(42), dp(24)));
        resizeRow.addView(spacer, new LinearLayout.LayoutParams(0, dp(24), 1f));
        resizeRight = resizeGrip("▶");
        resizeRow.addView(resizeRight, new LinearLayout.LayoutParams(dp(42), dp(24)));
        box.addView(resizeRow);
        resizeRow.setVisibility(collapsed?View.GONE:View.VISIBLE);
        body.setVisibility(collapsed?View.GONE:View.VISIBLE);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        int screenWidth=getResources().getDisplayMetrics().widthPixels;
        minPanelWidth=dp(210); maxPanelWidth=Math.max(minPanelWidth,screenWidth-dp(16));
        minPanelHeight=dp(150); maxPanelHeight=Math.max(minPanelHeight,getResources().getDisplayMetrics().heightPixels-dp(120));
        int defaultWidth=Math.min(dp(420),Math.max(dp(250),screenWidth-dp(24)));
        int savedWidthDp=getSharedPreferences(PREFS,0).getInt(KEY_DASHBOARD_WIDTH_DP, Math.round(defaultWidth/getResources().getDisplayMetrics().density));
        int savedWidth=Math.max(minPanelWidth,Math.min(maxPanelWidth,dp(savedWidthDp)));
        params=new WindowManager.LayoutParams(collapsed?dp(220):savedWidth,WindowManager.LayoutParams.WRAP_CONTENT,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.END; params.x=dp(12); params.y=dp(170); wm.addView(panel,params); applyRideMode();
        applyTextScale(params.width/(float)dp(320));
        installResizeGesture(resizeLeft, true);
        installResizeGesture(resizeRight, false);
        header.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;
            @Override public boolean onTouch(View v, MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=params.x;oy=params.y;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=ox+(int)(sx-e.getRawX());params.y=oy+(int)(e.getRawY()-sy);try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}return true;}
                return e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL;
            }});
    }
    private View resizeGrip(String label) {
        TextView grip=text(label,12,0xFFB8D4FF,true);
        grip.setGravity(Gravity.CENTER);
        grip.setBackground(shape(0xFF203A60,0xFF527DB5,10));
        grip.setContentDescription("Drag to resize floating dashboard");
        return grip;
    }
    private void installResizeGesture(View handle, boolean left) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX,downY; int startWidth,startHeight;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (params == null || collapsed || rideMode()) return false;
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY(); startWidth=params.width; startHeight=dashboardScroll==null?dp(300):dashboardScroll.getHeight(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float delta=e.getRawX()-downX;
                    float deltaY=e.getRawY()-downY;
                    int next=startWidth + (int)(left ? -delta : delta);
                    params.width=Math.max(minPanelWidth,Math.min(maxPanelWidth,next));
                    if(startHeight>0 && dashboardScroll!=null){ ViewGroup.LayoutParams scrollLp=dashboardScroll.getLayoutParams(); scrollLp.height=Math.max(minPanelHeight,Math.min(maxPanelHeight,startHeight+(int)deltaY)); dashboardScroll.setLayoutParams(scrollLp); }
                    float scale=Math.max(0.78f,Math.min(1.45f,params.width/(float)dp(320)));
                    applyTextScale(scale);
                    try { wm.updateViewLayout(panel,params); } catch(Exception ignored) {}
                    return true;
                }
                if (e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) {
                    int widthDp=Math.round(params.width/getResources().getDisplayMetrics().density);
                    int heightPx=dashboardScroll==null?dp(300):dashboardScroll.getLayoutParams().height;
                    int heightDp=Math.round(heightPx/getResources().getDisplayMetrics().density);
                    getSharedPreferences(PREFS,0).edit().putInt(KEY_DASHBOARD_WIDTH_DP,widthDp).putInt(KEY_DASHBOARD_HEIGHT_DP,heightDp).apply();
                    return true;
                }
                return false;
            }
        });
    }
    private void applyTextScale(float scale) {
        if (title!=null) title.setTextSize(18f*scale);
        if (modeLabel!=null) modeLabel.setTextSize(9f*scale);
        if (status!=null) status.setTextSize(10f*scale);
        if (content!=null) content.setTextSize(13f*scale);
        if (toggleButton!=null) toggleButton.setTextSize(11f*scale);
    }

    private void showSavedRecommendations(){
        if(recommendationQueue==null) recommendationQueue=new RecommendationQueueStore(this);
        java.util.List<RecommendationQueueStore.Entry> entries=recommendationQueue.getEntries();
        java.util.List<RecommendationQueueStore.Entry> active=new java.util.ArrayList<>();
        for(RecommendationQueueStore.Entry e:entries)
            if(!RecommendationQueueStore.ACCEPTED.equals(e.state)&&!RecommendationQueueStore.DISMISSED.equals(e.state)) active.add(e);
        if(active.isEmpty()){new AlertDialog.Builder(this).setTitle("Saved compatible bookings")
                .setMessage("No saved recommendations yet. Keep scanning while manually scrolling through Lalamove.")
                .setPositiveButton("OK",null).show();return;}
        String[] labels=new String[active.size()];
        for(int i=0;i<active.size();i++){RecommendationQueueStore.Entry e=active.get(i);
            labels[i]=e.description+"\n"+e.state+" • "+Math.round(e.score*100)+"/100 • "+e.availability;}
        new AlertDialog.Builder(this).setTitle("Saved compatible bookings ("+active.size()+")")
                .setItems(labels,(dialog,which)->showSavedBookingActions(active.get(which)))
                .setNegativeButton("Close",null).show();
    }
    private void showSavedBookingActions(RecommendationQueueStore.Entry entry){
        String details=entry.description+"\n\nStatus: "+entry.state+"\nScore: "+Math.round(entry.score*100)+"/100"
                +"\nFirst seen: "+new java.text.SimpleDateFormat("MMM d, HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date(entry.firstSeen))
                +"\nLast seen: "+new java.text.SimpleDateFormat("MMM d, HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date(entry.lastSeen))
                +"\nAvailability: "+entry.availability+"\n\nThis only archives the recommendation in RiderWise. It does not accept the Lalamove booking or set the active reference. Verify and accept manually in Lalamove first.";
        new AlertDialog.Builder(this).setTitle("Saved booking details").setMessage(details)
                .setPositiveButton("Archive as accepted externally",(d,w)->{recommendationQueue.mark(entry.key,RecommendationQueueStore.ACCEPTED);refreshSavedButton();showSavedRecommendations();})
                .setNeutralButton("Dismiss recommendation",(d,w)->{recommendationQueue.mark(entry.key,RecommendationQueueStore.DISMISSED);refreshSavedButton();showSavedRecommendations();})
                .setNegativeButton("Back",(d,w)->showSavedRecommendations()).show();
    }
    private void refreshSavedButton(){if(savedButton!=null)savedButton.setText("Saved ("+recommendationQueue.countActive()+")");}

    private void applyRideMode(){
        if(params==null||wm==null||panel==null)return;
        boolean on=rideMode();
        params.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | (on?WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE:0);
        if(on && !collapsed){collapsed=true; if(body!=null)body.setVisibility(View.GONE); if(resizeRow!=null)resizeRow.setVisibility(View.GONE); if(toggleButton!=null)toggleButton.setText("Show"); params.width=dp(220);}
        if(modeLabel!=null){modeLabel.setText(on?"RIDE MODE: ON • NON-INTERACTIVE":"RIDE MODE: OFF • INTERACTIVE");modeLabel.setTextColor(on?0xFF6EF0A0:0xFF8FB8FF);}
        try{wm.updateViewLayout(panel,params);}catch(Exception e){android.util.Log.w("RiderWise","Ride mode layout update failed",e);}
    }
    private void toggleExpanded(){
        collapsed=!collapsed; body.setVisibility(collapsed?View.GONE:View.VISIBLE);
        if(resizeRow!=null)resizeRow.setVisibility(collapsed?View.GONE:View.VISIBLE);
        toggleButton.setText(collapsed?"Show":"Minimize");
        if(params!=null&&wm!=null&&panel!=null){
            if (collapsed) {
                params.width=dp(220);
            } else {
                int savedWidthDp=getSharedPreferences(PREFS,0).getInt(KEY_DASHBOARD_WIDTH_DP,360);
                params.width=Math.max(minPanelWidth,Math.min(maxPanelWidth,dp(savedWidthDp)));
                applyTextScale(params.width/(float)dp(320));
            }
            try{wm.updateViewLayout(panel,params);}catch(Exception ignored){}}
    }
    private void togglePause(){
        paused=!paused; Intent i=new Intent(this,ScreenCaptureService.class);i.setAction(paused?"PAUSE":"RESUME");startService(i);
        status.setText(paused?"Ⅱ PAUSED":"● LIVE"); status.setTextColor(paused?0xFFFFD27A:0xFF6EF0A0);
        if(paused)content.setText("MONITORING PAUSED\nTap Resume to continue.");
        if(controls!=null&&controls.getChildCount()>0)((Button)controls.getChildAt(0)).setText(paused?"▶  Resume":"Ⅱ  Pause");
    }
    private void stopMonitoring(){
        Intent i=new Intent(this,ScreenCaptureService.class);i.setAction("STOP");startService(i);
        content.setText("Monitoring stopped. Start screen reading again from the main app.");
        status.setText("■ STOPPED");status.setTextColor(0xFFFFB0A6);
    }
    public static void update(Context c,String value){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("UPDATE");i.putExtra("text",value);c.startService(i);
    }
    public static void refreshMode(Context c){
        Intent i=new Intent(c,FloatingAssistantService.class);i.setAction("MODE");c.startService(i);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null&&"UPDATE".equals(i.getAction())&&content!=null){
            content.setText(i.getStringExtra("text"));
            if(recommendationQueue!=null)refreshSavedButton();
            if(status!=null&&!paused){status.setText("● LIVE");status.setTextColor(0xFF6EF0A0);}
        }
        if(i!=null&&"MODE".equals(i.getAction()))applyRideMode();
        return START_STICKY;
    }
    @Override public void onDestroy(){
        if (activeInstance == this) activeInstance = null;
        if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
