package com.riderwise.ai;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** PSA PSGC administrative index. PSGC does not contain latitude/longitude. */
public final class PsgcDataset {
    public static final String VERSION = "PSGC-3Q-2026";
    public static final class Record {
        public final String psgc, name, level, parentPsgc, oldNames, cityClass, incomeClassification, urbanRural, status;
        public final long population2024;
        private Record(JSONObject o) {
            psgc=o.optString("psgc", ""); name=o.optString("name", ""); level=o.optString("level", "");
            parentPsgc=o.isNull("parentPsgc")?null:o.optString("parentPsgc", null);
            oldNames=o.isNull("oldNames")?null:o.optString("oldNames", null);
            cityClass=o.optString("cityClass", ""); incomeClassification=o.optString("incomeClassification", "");
            urbanRural=o.optString("urbanRural", ""); status=o.optString("status", "");
            population2024=o.optLong("population2024", -1L);
        }
        public String displayLevel() {
            switch(level) { case "Reg": return "Region"; case "Prov": return "Province"; case "City": return "City";
                case "Mun": return "Municipality"; case "SubMun": return "Sub-municipality"; case "Bgy": return "Barangay"; default:return level; }
        }
    }
    private static final Map<String,Record> BY_CODE = new LinkedHashMap<>();
    private static final Map<String,List<Record>> BY_NAME = new HashMap<>();
    private static final Map<String,String> PARENT_NAMES = new HashMap<>();
    private static volatile boolean loaded;
    private static volatile String loadError;
    private PsgcDataset() {}

    public static synchronized void initialize(Context context) {
        if (loaded) return;
        try {
            java.io.InputStream raw;
            boolean compressed = true;
            try {
                raw = context.getAssets().open("luzon_psgc_3q_2026.json.gz");
            } catch (java.io.IOException missingGzipAsset) {
                // Some APK packaging/build paths include the validated plain JSON asset instead.
                raw = context.getAssets().open("luzon_psgc_3q_2026.json");
                compressed = false;
            }
            java.io.InputStream decoded = compressed ? new GZIPInputStream(raw) : raw;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(decoded, "UTF-8"))) {
            StringBuilder json = new StringBuilder(); char[] buf = new char[8192]; int n;
            while ((n=reader.read(buf))!=-1) json.append(buf,0,n);
            loadJson(json.toString());
            }
        } catch (Exception e) {
            BY_CODE.clear(); BY_NAME.clear(); PARENT_NAMES.clear();
            loadError=e.getClass().getSimpleName()+": "+e.getMessage();
        }
    }
    /** Shared parser also used by focused JVM tests with a tiny in-memory PSGC fixture. */
    static synchronized void loadJson(String json) throws Exception {
        BY_CODE.clear(); BY_NAME.clear(); PARENT_NAMES.clear();
        JSONObject root = new JSONObject(json); JSONArray records = root.getJSONArray("records");
        for (int i=0;i<records.length();i++) {
            Record r = new Record(records.getJSONObject(i));
            if (r.psgc.isEmpty() || r.name.isEmpty()) continue;
            BY_CODE.put(r.psgc,r);
            addName(r.name,r);
            if (r.name.startsWith("City of ")) addName(r.name.substring(8),r);
            if (r.name.startsWith("Municipality of ")) addName(r.name.substring(16),r);
            if (r.oldNames!=null && !r.oldNames.trim().isEmpty()) addName(r.oldNames,r);
        }
        for (Record r: BY_CODE.values()) {
            Record parent = r.parentPsgc==null?null:BY_CODE.get(r.parentPsgc);
            if(parent!=null) PARENT_NAMES.put(r.psgc,parent.name);
        }
        loadError=null; loaded=true;
    }
    private static void addName(String name, Record r) {
        String key=normalize(name); if(key.isEmpty()) return;
        List<Record> list=BY_NAME.computeIfAbsent(key,k->new ArrayList<>());
        if(!list.contains(r)) list.add(r);
    }
    private static String normalize(String s) {
        return BookingValidator.normalize(s).replaceAll("[^a-z0-9]", "");
    }
    public static boolean isLoaded(){return loaded;}
    public static String getLoadError(){return loadError;}
    public static int size(){return BY_CODE.size();}
    public static Record byPsgc(String code){return BY_CODE.get(code==null?"":code.trim());}
    /** Returns every exact administrative-name match; callers must not assume uniqueness. */
    public static List<Record> findAllByName(String name) {
        List<Record> found=BY_NAME.get(normalize(name));
        return found==null?Collections.emptyList():Collections.unmodifiableList(new ArrayList<>(found));
    }

    public static Record resolve(String name) {
        List<Record> found=BY_NAME.get(normalize(name));
        return found==null||found.size()!=1?null:found.get(0);
    }
    public static String canonicalize(String name) {
        Record r=resolve(name);
        if(r==null)return name;
        if("City".equals(r.level)&&r.name.startsWith("City of "))return r.name.substring(8);
        if("Mun".equals(r.level)&&r.name.startsWith("Municipality of "))return r.name.substring(16);
        return r.name;
    }
    public static Record resolve(String name, String parentName) {
        List<Record> found=BY_NAME.get(normalize(name)); if(found==null)return null;
        if(parentName!=null) for(Record r:found) if(hasAncestorNamed(r,parentName)) return r;
        return found.size()==1?found.get(0):null;
    }

    /** Exact PSGC match plus its containing city/municipality, where unambiguous. */
    public static final class LocationResolution {
        public final Record matchedRecord;
        public final Record localityRecord;
        public final boolean resolvedFromBarangay;
        /** True when duplicate place names were disambiguated using reference-booking context. */
        public final boolean inferredFromContext;
        LocationResolution(Record matched, Record locality, boolean barangay) {
            this(matched, locality, barangay, false);
        }
        LocationResolution(Record matched, Record locality, boolean barangay, boolean inferred) {
            matchedRecord=matched; localityRecord=locality; resolvedFromBarangay=barangay;
            inferredFromContext=inferred;
        }
    }

    /**
     * Resolve a short place or comma-separated address. Barangay-only matches are promoted to
     * their parent city/municipality for coarse route comparison, while retaining the exact
     * barangay record. Ambiguous names such as "San Mateo" without parent context stay unresolved.
     */
    public static LocationResolution resolveLocation(String address) {
        return resolveLocation(address, null);
    }

    /**
     * Resolve a place using an optional locality hint derived from the accepted reference booking.
     * The hint is only used when the raw place name is ambiguous; such a result is explicitly
     * marked inferredFromContext and must be shown with a verification warning.
     */
    public static LocationResolution resolveLocation(String address, String referenceLocalityHint) {
        if(address==null||address.trim().isEmpty()||BY_CODE.isEmpty()) return null;
        String[] parts=address.split("[,|]");
        List<String> tokens=new ArrayList<>();
        for(String part:parts) {
            String token=part.replaceAll("(?i)^\\s*(brgy\\.?|barangay)\\s+", "")
                    .replaceAll("(?i)^\\s*(city of|municipality of)\\s+", "").trim();
            if(!token.isEmpty()) tokens.add(token);
        }
        Record best=null;
        for(int i=0;i<tokens.size();i++) {
            List<Record> found=BY_NAME.get(normalize(tokens.get(i)));
            if(found==null||found.isEmpty()) continue;
            Record candidate=null;
            if(found.size()==1) {
                Record only=found.get(0);
                if(contextConsistent(only,tokens,i)) candidate=only;
            } else {
                int candidateDepth=-1;
                boolean tied=false;
                for(Record possible:found) {
                    boolean contextMatch=false;
                    for(int j=0;j<tokens.size();j++) if(i!=j && hasAncestorNamed(possible,tokens.get(j))) {
                        contextMatch=true; break;
                    }
                    if(contextMatch && contextConsistent(possible,tokens,i)) {
                        int d=depth(possible);
                        if(d>candidateDepth) { candidate=possible; candidateDepth=d; tied=false; }
                        else if(d==candidateDepth) tied=true;
                    }
                }
                if(tied) candidate=null;
            }
            if(candidate!=null && (best==null || depth(candidate)>depth(best))) best=candidate;
        }
        boolean inferredFromContext=false;
        if(best==null && referenceLocalityHint!=null && !referenceLocalityHint.trim().isEmpty()) {
            // Do not guess among duplicate barangay names: accept only one exact ancestor match.
            List<Record> rawMatches=null;
            for(String token:tokens) {
                List<Record> found=BY_NAME.get(normalize(token));
                if(found!=null && found.size()>1) { rawMatches=found; break; }
            }
            if(rawMatches!=null) {
                Record contextual=null;
                for(Record possible:rawMatches) if(hasAncestorNamed(possible, referenceLocalityHint)) {
                    if(contextual!=null) { contextual=null; break; }
                    contextual=possible;
                }
                if(contextual!=null) { best=contextual; inferredFromContext=true; }
            }
        }
        if(best==null) return null;
        Record locality=best;
        boolean barangay="Bgy".equals(best.level);
        if(!isLocality(best)) {
            Record parent=best.parentPsgc==null?null:BY_CODE.get(best.parentPsgc);
            while(parent!=null && !isLocality(parent))
                parent=parent.parentPsgc==null?null:BY_CODE.get(parent.parentPsgc);
            if(parent==null) return null;
            locality=parent;
        }
        return new LocationResolution(best,locality,barangay,inferredFromContext);
    }

    private static boolean isLocality(Record r) {
        return r!=null && ("City".equals(r.level)||"Mun".equals(r.level)||"SubMun".equals(r.level));
    }
    private static int depth(Record r) {
        int n=0; while(r!=null) { n++; r=r.parentPsgc==null?null:BY_CODE.get(r.parentPsgc); } return n;
    }
    private static boolean contextConsistent(Record candidate,List<String> tokens,int candidateIndex) {
        for(int i=0;i<tokens.size();i++) if(i!=candidateIndex) {
            List<Record> contextRecords=BY_NAME.get(normalize(tokens.get(i)));
            if(contextRecords==null||contextRecords.isEmpty()) continue;
            boolean related=false;
            for(Record context:contextRecords) {
                if(isAncestor(candidate,context)||isAncestor(context,candidate)) { related=true; break; }
            }
            if(!related) return false;
        }
        return true;
    }
    private static boolean isAncestor(Record possibleAncestor,Record record) {
        Record parent=record==null||record.parentPsgc==null?null:BY_CODE.get(record.parentPsgc);
        while(parent!=null) {
            if(parent.psgc.equals(possibleAncestor.psgc)) return true;
            parent=parent.parentPsgc==null?null:BY_CODE.get(parent.parentPsgc);
        }
        return false;
    }
    private static boolean hasAncestorNamed(Record r,String name) {
        String wanted=normalize(name);
        if(wanted.equals("qc")) wanted=normalize("Quezon City");
        Record parent=r==null||r.parentPsgc==null?null:BY_CODE.get(r.parentPsgc);
        while(parent!=null) {
            if(wanted.equals(normalize(parent.name))) return true;
            parent=parent.parentPsgc==null?null:BY_CODE.get(parent.parentPsgc);
        }
        return false;
    }

    /** Resolve the city/municipality portion of an address without inventing a barangay coordinate. */
    public static Record resolveFromAddress(String address) {
        LocationResolution result=resolveLocation(address);
        return result==null?null:result.localityRecord;
    }
    public static List<Record> search(String query, int limit) {
        if(query==null||query.trim().length()<2||limit<1)return Collections.emptyList();
        String q=normalize(query); List<Record> out=new ArrayList<>();
        for(Record r:BY_CODE.values()) {
            if(normalize(r.name).contains(q) || (r.oldNames!=null&&normalize(r.oldNames).contains(q))) {
                out.add(r); if(out.size()>=limit)break;
            }
        }
        return out;
    }
    public static String hierarchy(Record r) {
        if(r==null)return ""; List<String> parts=new ArrayList<>(); Record p=r;
        while(p!=null){parts.add(0,p.name);p=p.parentPsgc==null?null:BY_CODE.get(p.parentPsgc);}
        return android.text.TextUtils.join(" / ",parts);
    }
    public static Map<String,Integer> countsByLevel() {
        Map<String,Integer> out=new LinkedHashMap<>();
        for(Record r:BY_CODE.values()) out.put(r.displayLevel(),out.containsKey(r.displayLevel())?out.get(r.displayLevel())+1:1);
        return Collections.unmodifiableMap(out);
    }
}
