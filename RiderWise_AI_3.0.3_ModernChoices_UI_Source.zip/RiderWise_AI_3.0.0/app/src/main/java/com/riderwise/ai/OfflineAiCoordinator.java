package com.riderwise.ai;

import java.util.List;

/** Offline-only AI orchestration. The local model may rank only deterministic, validated options. */
public final class OfflineAiCoordinator {
    public interface Callback { void onResult(String answer); void onUnavailable(String reason); }
    public interface LocalAnalyzer {
        void analyze(Booking reference, List<Booking> candidates, Callback callback);
        boolean isReady();
    }
    private OfflineAiCoordinator() { }
    public static void analyze(LocalAnalyzer local, Booking reference, List<Booking> candidates, Callback callback) {
        if (callback == null) return;
        if (local == null || !local.isReady()) {
            callback.onUnavailable("Offline AI model is not loaded. OCR and deterministic recommendations remain active.");
            return;
        }
        try { local.analyze(reference, candidates, callback); }
        catch (RuntimeException error) { callback.onUnavailable("Offline AI failed; deterministic recommendations remain active."); }
    }
}
