package com.riderwise.ai;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/** Transactional local booking store. No customer identity fields are collected. */
public class BookingStore extends SQLiteOpenHelper {
    private static final String DB_NAME = "riderwise.db";
    private static final int DB_VERSION = 6;
    private static final String TABLE = "bookings";

    public BookingStore(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) { createSchema(db); }

    private static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS bookings(" +
                "id TEXT PRIMARY KEY,pickup TEXT NOT NULL,dropoff TEXT NOT NULL," +
                "base_fare REAL NOT NULL,additional_fare REAL NOT NULL,total_fare REAL NOT NULL," +
                "pickup_km REAL,confidence REAL NOT NULL,first_seen INTEGER NOT NULL,last_seen INTEGER NOT NULL," +
                "fingerprint TEXT NOT NULL UNIQUE,status TEXT NOT NULL,is_reference INTEGER NOT NULL DEFAULT 0," +
                "vehicle_type TEXT NOT NULL DEFAULT '',booking_type TEXT NOT NULL DEFAULT '',booking_code TEXT NOT NULL DEFAULT '',seen_count INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE INDEX IF NOT EXISTS booking_last_seen ON bookings(last_seen)");
        db.execSQL("CREATE INDEX IF NOT EXISTS booking_reference ON bookings(is_reference)");
        db.execSQL("CREATE INDEX IF NOT EXISTS booking_first_seen ON bookings(first_seen)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.beginTransaction();
        try {
            if (oldVersion < 2) migrateLegacyV1(db);
            createSchema(db);
            if (oldVersion < 4) {
                addColumnIfMissing(db, "vehicle_type", "TEXT NOT NULL DEFAULT ''");
                addColumnIfMissing(db, "booking_type", "TEXT NOT NULL DEFAULT ''");
            }
            if (oldVersion < 5) addColumnIfMissing(db, "booking_code", "TEXT NOT NULL DEFAULT ''");
            if (oldVersion < 6) addColumnIfMissing(db, "seen_count", "INTEGER NOT NULL DEFAULT 1");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private static void addColumnIfMissing(SQLiteDatabase db, String name, String type) {
        boolean found=false; try(Cursor c=db.rawQuery("PRAGMA table_info(bookings)",null)){while(c.moveToNext())if(name.equals(c.getString(1))){found=true;break;}}
        if(!found) db.execSQL("ALTER TABLE bookings ADD COLUMN "+name+" "+type);
    }

    /** v1 stored one combined fare and a single detection timestamp. */
    private static void migrateLegacyV1(SQLiteDatabase db) {
        Cursor exists = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='bookings'", null);
        boolean hasTable;
        try { hasTable = exists.moveToFirst(); } finally { exists.close(); }
        if (!hasTable) return;
        db.execSQL("DROP INDEX IF EXISTS booking_last_seen");
        db.execSQL("ALTER TABLE bookings RENAME TO bookings_v1_legacy");
        createSchema(db);
        db.execSQL("INSERT OR IGNORE INTO bookings(id,pickup,dropoff,base_fare,additional_fare,total_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,status,is_reference) " +
                "SELECT id,pickup,dropoff,fare,0,fare,pickup_km,confidence,detected_at,detected_at,fingerprint,status,is_reference FROM bookings_v1_legacy");
        db.execSQL("DROP TABLE bookings_v1_legacy");
    }

    public synchronized boolean upsert(Booking booking) {
        if (!BookingValidator.isValid(booking)) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            boolean isNew = true;
            int seenCount = 0;
            boolean matchedExisting = false;
            try (Cursor old = db.rawQuery("SELECT id,fingerprint,is_reference,first_seen,status,seen_count,dropoff,vehicle_type,booking_type,booking_code FROM bookings WHERE fingerprint=?",
                    new String[]{booking.fingerprint})) {
                if (old.moveToFirst()) {
                    matchedExisting = true;
                    isNew = false;
                    booking.id = old.getString(0);
                    booking.fingerprint = old.getString(1);
                    booking.reference = old.getInt(2) == 1;
                    booking.firstDetectedAt = Math.min(booking.firstDetectedAt, old.getLong(3));
                    seenCount = old.getInt(5);
                    if (booking.reference || "ACCEPTED".equals(old.getString(4))) booking.status = "ACCEPTED";
                    booking.dropoff = moreDetailedAddress(old.getString(6), booking.dropoff);
                    if (booking.vehicleType == null || booking.vehicleType.isEmpty()) booking.vehicleType = old.getString(7);
                    if (booking.bookingType == null || booking.bookingType.isEmpty()) booking.bookingType = old.getString(8);
                    if (booking.bookingCode == null || booking.bookingCode.isEmpty()) booking.bookingCode = old.getString(9);
                }
            }
            // A collapsed card and its expanded full-address view are the same job even
            // though OCR text (and therefore the raw fingerprint) becomes more detailed.
            if (!matchedExisting) {
                String[] equivalent = null;
                int equivalentCount = 0;
                try (Cursor old = db.rawQuery("SELECT id,fingerprint,is_reference,first_seen,status,seen_count,dropoff,vehicle_type,booking_type,booking_code FROM bookings WHERE pickup=? AND ABS(total_fare-?)<0.02 ORDER BY last_seen DESC LIMIT 20",
                        new String[]{booking.pickup, String.valueOf(booking.totalFare)})) {
                    String incoming = BookingValidator.normalize(booking.dropoff);
                    while (old.moveToNext()) {
                        String existing = BookingValidator.normalize(old.getString(6));
                        if (existing.length() < 5 || incoming.length() < 5) continue;
                        boolean sameAddress = existing.equals(incoming) || existing.contains(incoming) || incoming.contains(existing);
                        String oldCode = old.getString(9), newCode = booking.bookingCode;
                        if (!sameAddress || (oldCode != null && !oldCode.isEmpty() && newCode != null && !newCode.isEmpty() && !oldCode.equals(newCode))) continue;
                        equivalentCount++;
                        equivalent = new String[]{old.getString(0),old.getString(1),old.getString(2),old.getString(3),old.getString(4),old.getString(5),old.getString(6),old.getString(7),old.getString(8),old.getString(9)};
                    }
                }
                // Only reconcile collapsed/expanded OCR when there is exactly one safe match.
                if (equivalentCount == 1 && equivalent != null) {
                    matchedExisting = true;
                    isNew = false;
                    booking.id = equivalent[0];
                    booking.fingerprint = equivalent[1];
                    booking.reference = "1".equals(equivalent[2]);
                    booking.firstDetectedAt = Math.min(booking.firstDetectedAt, Long.parseLong(equivalent[3]));
                    seenCount = Integer.parseInt(equivalent[5]);
                    if (booking.reference || "ACCEPTED".equals(equivalent[4])) booking.status = "ACCEPTED";
                    booking.dropoff = moreDetailedAddress(equivalent[6], booking.dropoff);
                    if (booking.vehicleType == null || booking.vehicleType.isEmpty()) booking.vehicleType = equivalent[7];
                    if (booking.bookingType == null || booking.bookingType.isEmpty()) booking.bookingType = equivalent[8];
                    if (booking.bookingCode == null || booking.bookingCode.isEmpty()) booking.bookingCode = equivalent[9];
                }
            }
            ContentValues values = toValues(booking);
            values.put("seen_count", Math.max(1, seenCount + 1));
            // UPDATE existing rows instead of CONFLICT_REPLACE: REPLACE deletes/reinserts
            // and would scramble the original top-to-bottom insertion order on every scan.
            int updated = db.update(TABLE, values, "fingerprint=?", new String[]{booking.fingerprint});
            if (updated == 0) db.insertWithOnConflict(TABLE, null, values, SQLiteDatabase.CONFLICT_IGNORE);
            db.setTransactionSuccessful();
            return isNew;
        } finally { db.endTransaction(); }
    }

    public synchronized long getLastSeenAt(String fingerprint) {
        if (fingerprint == null || fingerprint.trim().isEmpty()) return 0L;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT last_seen FROM bookings WHERE fingerprint=? LIMIT 1", new String[]{fingerprint})) {
            return c.moveToFirst() ? c.getLong(0) : 0L;
        }
    }

    private static String moreDetailedAddress(String existing, String incoming) {
        if (existing == null || existing.trim().isEmpty()) return incoming;
        if (incoming == null || incoming.trim().isEmpty()) return existing;
        String a=BookingValidator.normalize(existing), b=BookingValidator.normalize(incoming);
        if (b.length()>a.length() && b.contains(a)) return incoming;
        return existing;
    }

    private static ContentValues toValues(Booking b) {
        ContentValues v = new ContentValues();
        v.put("id", b.id); v.put("pickup", b.pickup); v.put("dropoff", b.dropoff);
        v.put("base_fare", b.baseFare); v.put("additional_fare", b.additionalFare); v.put("total_fare", b.totalFare);
        if (Double.isFinite(b.pickupDistanceKm)) v.put("pickup_km", b.pickupDistanceKm); else v.putNull("pickup_km");
        v.put("confidence", b.confidence); v.put("first_seen", b.firstDetectedAt); v.put("last_seen", b.lastDetectedAt);
        v.put("fingerprint", b.fingerprint); v.put("status", b.status == null ? "DETECTED" : b.status);
        v.put("is_reference", b.reference ? 1 : 0);
        v.put("vehicle_type", b.vehicleType == null ? "" : b.vehicleType);
        v.put("booking_type", b.bookingType == null ? "" : b.bookingType);
        v.put("booking_code", b.bookingCode == null ? "" : b.bookingCode);
        return v;
    }

    public synchronized List<Booking> getRecent() {
        List<Booking> out = new ArrayList<>();
        // Keep a multi-day local seen-history so old cards resurfacing at the top are deduplicated.
        long cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,pickup,dropoff,base_fare,additional_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,is_reference,status,vehicle_type,booking_type,booking_code FROM bookings WHERE last_seen>? AND status!='REJECTED' ORDER BY first_seen DESC,rowid ASC LIMIT 500",
                new String[]{String.valueOf(cutoff)})) {
            while (c.moveToNext()) {
                double pickupKm = c.isNull(5) ? Double.NaN : c.getDouble(5);
                Booking b = new Booking(c.getString(1), c.getString(2), c.getDouble(3), c.getDouble(4),
                        pickupKm, c.getFloat(6), c.getLong(7), c.getLong(8));
                b.id = c.getString(0); b.fingerprint = c.getString(9);
                b.reference = c.getInt(10) == 1; b.status = c.getString(11);
                b.vehicleType=c.getString(12); b.bookingType=c.getString(13); b.bookingCode=c.getString(14);
                out.add(b);
            }
        }
        return out;
    }

    public synchronized Booking getReference() {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,pickup,dropoff,base_fare,additional_fare,pickup_km,confidence,first_seen,last_seen,fingerprint,status,vehicle_type,booking_type,booking_code FROM bookings WHERE is_reference=1 LIMIT 1", null)) {
            if (!c.moveToFirst()) return null;
            double pickupKm = c.isNull(5) ? Double.NaN : c.getDouble(5);
            Booking b = new Booking(c.getString(1), c.getString(2), c.getDouble(3), c.getDouble(4),
                    pickupKm, c.getFloat(6), c.getLong(7), c.getLong(8));
            b.id = c.getString(0); b.fingerprint = c.getString(9); b.reference = true; b.status = c.getString(10);
            b.vehicleType=c.getString(11); b.bookingType=c.getString(12); b.bookingCode=c.getString(13);
            return b;
        }
    }

    /**
     * Records every positively detected acceptance. The first accepted booking becomes
     * the reference only when no reference is currently selected.
     */
    public synchronized boolean recordAcceptedBooking(Booking accepted) {
        if (accepted == null || !BookingValidator.isValid(accepted)) return false;
        accepted.status = "ACCEPTED";
        upsert(accepted);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor c = db.rawQuery("SELECT id FROM bookings WHERE is_reference=1 LIMIT 1", null)) {
                if (c.moveToFirst()) {
                    db.setTransactionSuccessful();
                    return false;
                }
            }
            ContentValues selected = new ContentValues();
            selected.put("is_reference", 1);
            selected.put("status", "ACCEPTED");
            db.update(TABLE, selected, "fingerprint=?", new String[]{accepted.fingerprint});
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }

    /** Clears the current reference without deleting its accepted-booking history. */
    public synchronized void clearReference() {
        ContentValues clear = new ContentValues();
        clear.put("is_reference", 0);
        getWritableDatabase().update(TABLE, clear, null, null);
    }

    /** The rider explicitly selects the booking they have accepted in the delivery app. */
    public synchronized boolean setAcceptedReference(String bookingId) {
        if (bookingId == null || bookingId.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            try (Cursor c = db.rawQuery("SELECT id FROM bookings WHERE id=? AND status!='REJECTED'", new String[]{bookingId})) {
                if (!c.moveToFirst()) return false;
            }
            ContentValues clear = new ContentValues(); clear.put("is_reference", 0);
            db.update(TABLE, clear, null, null);
            ContentValues selected = new ContentValues();
            selected.put("is_reference", 1); selected.put("status", "ACCEPTED");
            db.update(TABLE, selected, "id=?", new String[]{bookingId});
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }


    /** Rider-confirmed full destination replaces an ambiguous short OCR label for future route checks. */
    public synchronized boolean confirmDestination(String bookingId, String fullDropoff) {
        if (bookingId == null || bookingId.trim().isEmpty() || fullDropoff == null || fullDropoff.trim().isEmpty()) return false;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Booking updated = null;
            try (Cursor c = db.rawQuery("SELECT pickup,base_fare,additional_fare,pickup_km,confidence,first_seen,last_seen,booking_code,status,is_reference FROM bookings WHERE id=?", new String[]{bookingId})) {
                if (c.moveToFirst()) {
                    double pickupKm = c.isNull(3) ? Double.NaN : c.getDouble(3);
                    updated = new Booking(c.getString(0), fullDropoff.trim(), c.getDouble(1), c.getDouble(2),
                            pickupKm, c.getFloat(4), c.getLong(5), c.getLong(6));
                    updated.bookingCode = c.getString(7);
                    if (updated.bookingCode != null && !updated.bookingCode.isEmpty()) updated.setBookingCode(updated.bookingCode);
                    updated.status = c.getString(8);
                    updated.reference = c.getInt(9) == 1;
                }
            }
            if (updated == null) return false;
            ContentValues values = toValues(updated);
            int changed = db.update(TABLE, values, "id=?", new String[]{bookingId});
            db.setTransactionSuccessful();
            return changed == 1;
        } finally { db.endTransaction(); }
    }

    public synchronized void expireOlderThan(long cutoff) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ContentValues stale = new ContentValues(); stale.put("status", "STALE");
            db.update(TABLE, stale, "last_seen<? AND is_reference=0", new String[]{String.valueOf(cutoff)});
            db.delete(TABLE, "last_seen<? AND is_reference=0", new String[]{String.valueOf(cutoff - 24L*60L*60L*1000L)});
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
}
