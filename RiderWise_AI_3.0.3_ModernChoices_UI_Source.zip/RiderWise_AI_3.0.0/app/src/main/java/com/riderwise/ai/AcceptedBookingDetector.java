package com.riderwise.ai;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.*;
import java.util.regex.*;

/** Detects Lalamove's explicit post-acceptance confirmation screen. */
public final class AcceptedBookingDetector {
    private static final Pattern BOOKING_CODE = Pattern.compile("\\bbooking\\s*(?:#|id|no\\.?|number)\\s*[:#-]?\\s*([A-Z0-9-]{4,})", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:₱|PHP)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE);
    private AcceptedBookingDetector() {}

    public static Booking detect(Text text) {
        if (text == null) return null;
        List<Text.Line> lines = new ArrayList<>();
        StringBuilder all = new StringBuilder();
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                lines.add(line);
                all.append(line.getText()).append('\n');
            }
        }
        String normalized = normalize(all.toString());
        // Require the explicit success banner; ordinary booking cards must never be auto-accepted.
        if (!(normalized.contains("great you got it") || normalized.contains("you got it"))) return null;

        Matcher money = MONEY.matcher(all.toString());
        if (!money.find()) return null;
        double fare;
        try { fare = Double.parseDouble(money.group(1).replace(",", "")); }
        catch (NumberFormatException e) { return null; }
        if (!(fare > 0 && fare < 100000)) return null;

        lines.sort(Comparator.comparingInt(AcceptedBookingDetector::top));
        List<List<String>> groups = new ArrayList<>();
        List<String> current = new ArrayList<>();
        int previousY = Integer.MIN_VALUE;
        for (Text.Line line : lines) {
            String raw = clean(line.getText());
            if (raw.isEmpty() || !looksLikeAddress(raw)) continue;
            int y = top(line);
            if (!current.isEmpty() && previousY != Integer.MIN_VALUE && y - previousY > 85) {
                groups.add(current);
                current = new ArrayList<>();
            }
            current.add(raw);
            previousY = y;
        }
        if (!current.isEmpty()) groups.add(current);

        List<String> places = new ArrayList<>();
        for (List<String> group : groups) {
            String place = dedupeAndJoin(group);
            if (place.length() >= 5 && (places.isEmpty() || !normalize(places.get(places.size()-1)).equals(normalize(place)))) {
                places.add(place);
            }
        }
        if (places.size() < 2) return null;

        // The first address block is pickup and the next distinct block is drop-off.
        String pickup = limit(places.get(0));
        String dropoff = limit(places.get(1));
        long now = System.currentTimeMillis();
        Booking accepted = new Booking(pickup, dropoff, fare, 0d, Double.NaN, 0.90f, now, now);
        Matcher code=BOOKING_CODE.matcher(all.toString());if(code.find())accepted.setBookingCode(code.group(1));
        accepted.status = "ACCEPTED";
        accepted.reference = true;
        return accepted;
    }

    private static boolean looksLikeAddress(String s) {
        String n = normalize(s);
        if (n.startsWith("client ") || n.startsWith("today ") || n.startsWith("proof of delivery")
                || n.startsWith("settle with") || n.startsWith("call customer")
                || n.startsWith("collect cash") || n.equals("delivery") || n.equals("regular")
                || n.contains("customer") || n.contains("₱") || n.matches(".*\\b0\\d{9,11}\\b.*")
                || n.matches(".*\\b\\d{10,12}\\b.*")) return false;
        return PsgcDataset.resolve(s)!=null || GeographicDataset.resolve(s)!=null || (s.contains(",") && (n.contains("city") || n.contains("metro manila")
                || n.contains("philippines") || n.contains("brgy") || n.contains("barangay")
                || n.contains("plaza") || n.contains("street") || n.contains("road")
                || n.contains("avenue") || n.contains("committee")));
    }

    private static String dedupeAndJoin(List<String> lines) {
        LinkedHashMap<String,String> unique = new LinkedHashMap<>();
        for (String line : lines) {
            String n = normalize(line);
            if (!n.isEmpty()) unique.putIfAbsent(n, line);
        }
        return String.join(", ", unique.values()).replaceAll("\\s+", " ").trim();
    }
    private static String limit(String s) { return s.length() <= 180 ? s : s.substring(0, 180).trim(); }
    private static String clean(String s) { return s == null ? "" : s.replaceAll("\\s+", " ").trim(); }
    private static String normalize(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim(); }
    private static int top(Text.Line line) { Rect r=line.getBoundingBox(); return r == null ? 0 : r.top; }
}
