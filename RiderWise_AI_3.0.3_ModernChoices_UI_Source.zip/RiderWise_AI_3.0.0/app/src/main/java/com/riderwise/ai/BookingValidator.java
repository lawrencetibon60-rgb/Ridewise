package com.riderwise.ai;

import java.text.Normalizer;
import java.util.Locale;

/** Central validation and normalization rules for OCR-derived bookings. */
public final class BookingValidator {
    private BookingValidator() { }

    public static boolean isValid(Booking b) {
        if (b == null || !clean(b.pickup) || !clean(b.dropoff)) return false;
        if (normalize(b.pickup).equals(normalize(b.dropoff))) return false;
        if (!Double.isFinite(b.baseFare) || !Double.isFinite(b.additionalFare)
                || !Double.isFinite(b.totalFare)) return false;
        if (b.baseFare < 0 || b.additionalFare < 0 || b.totalFare <= 0 || b.totalFare > 100000) return false;
        if (Math.abs((b.baseFare + b.additionalFare) - b.totalFare) > 0.011d) return false;
        if (!Float.isFinite(b.confidence) || b.confidence < 0.30f || b.confidence > 1f) return false;
        if (Double.isFinite(b.pickupDistanceKm) && b.pickupDistanceKm < 0) return false;
        return b.firstDetectedAt >= 0 && b.lastDetectedAt >= b.firstDetectedAt;
    }

    private static boolean clean(String s) {
        return s != null && s.trim().length() >= 2 && s.trim().length() <= 180;
    }

    public static String normalize(String s) {
        if (s == null) return "";
        return Normalizer.normalize(s.trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim().replaceAll("\\s+", " ");
    }
}
