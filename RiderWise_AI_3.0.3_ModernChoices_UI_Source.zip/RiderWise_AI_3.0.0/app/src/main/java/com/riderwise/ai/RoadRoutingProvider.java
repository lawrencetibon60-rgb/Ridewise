package com.riderwise.ai;

/** Pluggable contract for a future licensed road-routing service; no provider is bundled in 3.0.0. */
public interface RoadRoutingProvider {
    final class RouteResult {
        public final double roadDistanceKm, durationMinutes;
        public final String provider;
        public RouteResult(double distanceKm,double minutes,String providerName) {
            roadDistanceKm=distanceKm;durationMinutes=minutes;provider=providerName==null?"":providerName;
        }
    }
    RouteResult route(double fromLat,double fromLon,double toLat,double toLon);
}
