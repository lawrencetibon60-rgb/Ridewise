package com.riderwise.ai;

import java.util.List;

/**
 * Verifies ambiguous destination names before they enter route recommendations.
 * Reference context may propose a locality, but never upgrades an inference to verified.
 */
public final class LocationVerificationManager {
    public enum State { VERIFIED, NEEDS_USER_VERIFICATION, UNRESOLVED, NOT_APPLICABLE }
    public static final class Result {
        public final State state;
        public final String destinationName, proposedLocality, message;
        public final PsgcDataset.Record matchedRecord, localityRecord;
        Result(State state,String destination,String locality,String message,
               PsgcDataset.Record matched,PsgcDataset.Record parent) {
            this.state=state; destinationName=destination; proposedLocality=locality;
            this.message=message; matchedRecord=matched; localityRecord=parent;
        }
        public boolean requiresUserVerification(){return state==State.NEEDS_USER_VERIFICATION || state==State.UNRESOLVED;}
        public boolean isVerified(){return state==State.VERIFIED;}
    }
    private LocationVerificationManager() { }

    public static Result evaluate(Booking reference, Booking candidate) {
        if(reference==null||candidate==null||!BookingValidator.isValid(reference)||!BookingValidator.isValid(candidate))
            return new Result(State.NOT_APPLICABLE,"","","Booking details are incomplete.",null,null);
        String dropoff=candidate.dropoff==null?"":candidate.dropoff.trim();
        PsgcDataset.LocationResolution direct=PsgcDataset.resolveLocation(dropoff);
        if(direct!=null && !direct.inferredFromContext) {
            return new Result(State.VERIFIED,direct.matchedRecord.name,direct.localityRecord.name,
                    "Full locality context detected: "+direct.localityRecord.name,direct.matchedRecord,direct.localityRecord);
        }
        String shortName=lastPlaceToken(dropoff);
        List<PsgcDataset.Record> matches=PsgcDataset.findAllByName(shortName);
        // Keep legacy, uniquely indexed non-PSGC areas (e.g. Quezon Avenue) usable, but never
        // let a legacy city label override duplicate PSGC names such as San Mateo or Paltok.
        GeographicDataset.LocationMatch knownArea=GeographicDataset.resolveLocation(dropoff);
        if(direct==null && matches.isEmpty() && knownArea!=null && knownArea.matchedRecord==null
                && knownArea.coordinatePlace!=null) {
            return new Result(State.VERIFIED,dropoff,knownArea.coordinatePlace.province,
                    "Known local geographic index entry; coordinate remains approximate.",null,null);
        }
        if(matches.size()>1) {
            GeographicDataset.LocationMatch contextual=GeographicIntelligence.resolveAgainstReference(shortName,reference.dropoff);
            if(contextual!=null && contextual.matchedRecord!=null && contextual.localityRecord!=null) {
                return new Result(State.NEEDS_USER_VERIFICATION,contextual.matchedRecord.name,
                        contextual.localityRecord.name,
                        "Potentially compatible. Open the Lalamove booking card and verify the full destination address. Suggested match: "+contextual.localityRecord.name+". This is an inference, not confirmation.",
                        contextual.matchedRecord,contextual.localityRecord);
            }
            return new Result(State.NEEDS_USER_VERIFICATION,shortName,"",
                    "Destination name matches multiple places. Open the booking card and verify the full destination address.",null,null);
        }
        if(direct!=null) {
            return new Result(State.NEEDS_USER_VERIFICATION,direct.matchedRecord.name,direct.localityRecord.name,
                    "Open the booking card to verify the full destination address before final compatibility.",
                    direct.matchedRecord,direct.localityRecord);
        }
        return new Result(State.UNRESOLVED,shortName,"",
                "Destination could not be resolved confidently. Open the booking card and check the full address.",null,null);
    }

    /** Find the expanded OCR version of a previously short/ambiguous card. */
    public static Booking findExpandedCounterpart(Booking shortBooking,List<Booking> all) {
        if(shortBooking==null||all==null)return null;
        String shortDrop=BookingValidator.normalize(shortBooking.dropoff);
        for(Booking candidate:all) {
            if(candidate==null||candidate==shortBooking||!BookingValidator.isValid(candidate))continue;
            if(!sameLocationLabel(candidate.pickup,shortBooking.pickup))continue;
            if(Math.abs(candidate.totalFare-shortBooking.totalFare)>0.02d)continue;
            String full=BookingValidator.normalize(candidate.dropoff);
            if(full.equals(shortDrop)||!full.contains(shortDrop))continue;
            PsgcDataset.LocationResolution resolution=PsgcDataset.resolveLocation(candidate.dropoff);
            if(resolution!=null&&!resolution.inferredFromContext)return candidate;
        }
        return null;
    }

    public static boolean sameLocationLabel(String first,String second) {
        String a=BookingValidator.normalize(first), b=BookingValidator.normalize(second);
        return !a.isEmpty() && !b.isEmpty()
                && (a.equals(b) || a.startsWith(b+" ") || b.startsWith(a+" "));
    }

    private static String lastPlaceToken(String address) {
        if(address==null)return "";
        String[] parts=address.split("[,|]");
        for(int i=parts.length-1;i>=0;i--) {
            String token=parts[i].trim().replaceAll("(?i)^(brgy\\.?|barangay)\\s+","");
            if(!token.isEmpty())return token;
        }
        return address.trim();
    }
}
