package com.riderwise.ai;

/** Estimates only values supported by the supplied distance, duration and fuel inputs. */
public final class ProfitCalculator {
    public static final double UNAVAILABLE = Double.NaN;
    private ProfitCalculator() { }

    public static final class Result {
        public final double combinedFare, baseFare, additionalFare, distanceKm, durationHours;
        public final double fuelCost, netEarnings, earningsPerKm, earningsPerHour, detourKm;
        public final boolean available;
        private Result(double fare, double base, double extra, double distance, double hours,
                       double fuel, double net, double perKm, double perHour, double detour) {
            combinedFare= fare; baseFare=base; additionalFare=extra; distanceKm=distance;
            durationHours=hours; fuelCost=fuel; netEarnings=net; earningsPerKm=perKm;
            earningsPerHour=perHour; detourKm=detour;
            available=Double.isFinite(fare);
        }
    }

    public static Result calculate(Iterable<Booking> bookings, double distanceKm, double durationHours,
                                   double fuelPricePerLiter, double kmPerLiter, double detourKm) {
        double fare=0, base=0, extra=0; boolean found=false;
        if (bookings != null) for (Booking b : bookings) {
            if (BookingValidator.isValid(b)) { found=true; fare+=b.totalFare; base+=b.baseFare; extra+=b.additionalFare; }
        }
        if (!found) return new Result(UNAVAILABLE,UNAVAILABLE,UNAVAILABLE,distanceKm,durationHours,
                UNAVAILABLE,UNAVAILABLE,UNAVAILABLE,UNAVAILABLE,detourKm);
        double fuel=estimatedFuelCost(distanceKm,fuelPricePerLiter,kmPerLiter);
        return new Result(fare,base,extra,distanceKm,durationHours,fuel,netFare(fare,fuel),
                earningsPerKm(fare,distanceKm),earningsPerHour(fare,durationHours),
                Double.isFinite(detourKm)&&detourKm>=0?detourKm:UNAVAILABLE);
    }

    public static double estimatedFuelCost(double distanceKm,double fuelPricePerLiter,double kmPerLiter) {
        if (!Double.isFinite(distanceKm)||!Double.isFinite(fuelPricePerLiter)||!Double.isFinite(kmPerLiter)
                ||distanceKm<=0||fuelPricePerLiter<=0||kmPerLiter<=0) return UNAVAILABLE;
        return distanceKm/kmPerLiter*fuelPricePerLiter;
    }
    public static double netFare(double fare,double fuelCost) {
        return Double.isFinite(fare)&&Double.isFinite(fuelCost)?fare-fuelCost:UNAVAILABLE;
    }
    public static double earningsPerKm(double fare,double distanceKm) {
        return Double.isFinite(fare)&&Double.isFinite(distanceKm)&&fare>0&&distanceKm>0?fare/distanceKm:UNAVAILABLE;
    }
    public static double earningsPerHour(double fare,double durationHours) {
        return Double.isFinite(fare)&&Double.isFinite(durationHours)&&fare>0&&durationHours>0?fare/durationHours:UNAVAILABLE;
    }
}
