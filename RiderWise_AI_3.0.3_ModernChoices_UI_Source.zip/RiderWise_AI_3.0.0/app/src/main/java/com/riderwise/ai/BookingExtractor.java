package com.riderwise.ai;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Converts OCR lines into independent booking-card candidates. Incomplete cards are counted, never promoted. */
public class BookingExtractor {
    private static final Pattern FARE_PAIR = Pattern.compile("(?:₱|PHP)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)\\s*\\+\\s*(?:₱|PHP)?\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:₱|PHP)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern BOOKING_CODE = Pattern.compile("\\bbooking\\s*(?:#|id|no\\.?|number)\\s*[:#-]?\\s*([A-Z0-9-]{4,})", Pattern.CASE_INSENSITIVE);
    private static final Pattern KM = Pattern.compile("~?\\s*([0-9]+(?:\\.[0-9]+)?)\\s*km", Pattern.CASE_INSENSITIVE);
    private static final Pattern PICKUP = Pattern.compile("^(?:pickup|pick\\s*up|from)\\s*[:：-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern DROPOFF = Pattern.compile("^(?:drop\\s*off|dropoff|destination|to)\\s*[:：-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE);
    private static final String[] VEHICLES={"motorcycle","motorbike","sedan","hatchback","mpv","suv","van","4-wheeler","4 wheeler","6-wheeler","6 wheeler","10-wheeler","10 wheeler","truck","closed van","pickup truck"};
    private volatile int lastDetectedCardCount, lastPartialCardCount;

    public int getLastDetectedCardCount(){return lastDetectedCardCount;}
    public int getLastPartialCardCount(){return lastPartialCardCount;}

    public static final class FareComponents {
        public final double baseFare, additionalFare, totalFare;
        FareComponents(double base,double additional){baseFare=base;additionalFare=additional;totalFare=base+additional;}
    }
    public static FareComponents parseFareComponents(String raw){
        if(raw==null)return null;
        Matcher pair=FARE_PAIR.matcher(raw);
        if(pair.find())try{return new FareComponents(Double.parseDouble(pair.group(1).replace(",","")),Double.parseDouble(pair.group(2).replace(",","")));}catch(NumberFormatException ignored){return null;}
        Matcher one=MONEY.matcher(raw);
        if(one.find())try{return new FareComponents(Double.parseDouble(one.group(1).replace(",","")),0d);}catch(NumberFormatException ignored){return null;}
        return null;
    }

    public List<Booking> extract(Text text){return extract(text,Collections.emptyList());}
    public List<Booking> extract(Text text,List<Integer> visualHeaderTops){
        lastDetectedCardCount=0;lastPartialCardCount=0;
        if(text==null)return Collections.emptyList();
        List<Text.Line> lines=new ArrayList<>();
        for(Text.TextBlock block:text.getTextBlocks())lines.addAll(block.getLines());
        lines.sort(Comparator.comparingInt(BookingExtractor::top));
        if(lines.isEmpty())return Collections.emptyList();
        List<List<Text.Line>> cards=splitCards(lines,visualHeaderTops);
        lastDetectedCardCount=cards.size();
        List<Booking> result=new ArrayList<>();
        // One timestamp per screen frame preserves the visible top-to-bottom order when
        // records are first inserted into the persistent store.
        long frameDetectedAt=System.currentTimeMillis();
        for(List<Text.Line> card:cards){
            if(card.isEmpty())continue;
            Booking booking=parseCard(card,frameDetectedAt);
            if(BookingValidator.isValid(booking))result.add(booking);
            else if(looksLikeBookingFragment(card))lastPartialCardCount++;
        }
        return result;
    }

    private static List<List<Text.Line>> splitCards(List<Text.Line> lines,List<Integer> visualHeaderTops){
        List<List<Text.Line>> cards=new ArrayList<>();
        if(visualHeaderTops!=null&&!visualHeaderTops.isEmpty()){
            List<Integer> anchors=new ArrayList<>(visualHeaderTops);Collections.sort(anchors);
            for(int ignored:anchors)cards.add(new ArrayList<>());
            for(Text.Line line:lines){int y=top(line),idx=-1;for(int i=0;i<anchors.size();i++){if(y>=anchors.get(i)-8)idx=i;else break;}if(idx>=0)cards.get(idx).add(line);}
            cards.removeIf(List::isEmpty);return cards;
        }
        List<Text.Line> current=new ArrayList<>();int previousHeader=Integer.MIN_VALUE;
        for(Text.Line line:lines){
            String normalized=normalizeHeader(line.getText());int y=top(line);
            boolean header=isBookingHeader(normalized);
            boolean visualGap=!current.isEmpty()&&y-top(current.get(current.size()-1))>115;
            if((header&&(previousHeader==Integer.MIN_VALUE||Math.abs(y-previousHeader)>18))||visualGap){
                if(!current.isEmpty())cards.add(current);current=new ArrayList<>();
                if(header)previousHeader=y;
            }
            current.add(line);
        }
        if(!current.isEmpty())cards.add(current);
        // A single screen without clear card separators is kept as one candidate, never fabricated into several.
        return cards;
    }

    static String normalizeHeader(String value){return value==null?"":value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").trim();}
    static boolean isBookingHeader(String n){return n.contains("pick up now")||n.contains("pickup now")||n.matches(".*booking\\s*#?\\d+.*");}
    private static int top(Text.Line line){Rect r=line.getBoundingBox();return r==null?0:r.top;}

    private Booking parseCard(List<Text.Line> lines,long frameDetectedAt){
        StringBuilder all=new StringBuilder();List<Double> amounts=new ArrayList<>();List<String> places=new ArrayList<>();
        String pickup=null,dropoff=null,vehicle="",bookingType="",bookingCode="";double pickupKm=Double.NaN,base=Double.NaN,extra=0d;
        float confidence=0f;int confidenceCount=0;int lastPlaceTop=Integer.MIN_VALUE;
        for(Text.Line line:lines){
            String raw=line.getText()==null?"":line.getText().trim();if(raw.isEmpty())continue;all.append(raw).append('\n');
            Float c=line.getConfidence();confidence+=c==null?0.55f:c;confidenceCount++;
            Matcher codeMatch=BOOKING_CODE.matcher(raw);if(codeMatch.find())bookingCode=codeMatch.group(1);
            Matcher pm=PICKUP.matcher(raw),dm=DROPOFF.matcher(raw);
            if(pm.matches())pickup=cleanPlace(pm.group(1));else if(dm.matches())dropoff=cleanPlace(dm.group(1));
            Matcher money=MONEY.matcher(raw);while(money.find())try{amounts.add(Double.parseDouble(money.group(1).replace(",","")));}catch(NumberFormatException ignored){}
            Matcher km=KM.matcher(raw);if(km.find())try{pickupKm=Double.parseDouble(km.group(1));}catch(NumberFormatException ignored){}
            String lower=raw.toLowerCase(Locale.ROOT);
            for(String v:VEHICLES)if(lower.contains(v)){vehicle=canonicalVehicle(v);break;}
            if(lower.contains("priority"))bookingType="PRIORITY";else if(lower.contains("regular"))bookingType="REGULAR";else if(lower.contains("express"))bookingType="EXPRESS";
            String candidate=cleanPlace(raw);
            if(isPlausiblePlace(candidate)){
                int candidateTop=top(line);
                // Expanded Lalamove cards show a short place heading followed by one or
                // more comma-rich address lines. Attach nearby detail lines to that same
                // endpoint instead of mistaking the pickup address for the drop-off.
                boolean addressDetail=candidate.contains(",") && !places.isEmpty()
                        && lastPlaceTop!=Integer.MIN_VALUE && candidateTop-lastPlaceTop<=70;
                if(addressDetail){
                    int last=places.size()-1;
                    places.set(last,places.get(last)+", "+candidate);
                }else places.add(candidate);
                lastPlaceTop=candidateTop;
            }
        }
        FareComponents fare=parseFareComponents(all.toString());
        if(fare!=null){base=fare.baseFare;extra=fare.additionalFare;}else if(!amounts.isEmpty())base=amounts.get(0);
        // Infer route endpoints from address/place lines when Lalamove's labels are absent.
        if(pickup==null||dropoff==null){
            List<String> unique=new ArrayList<>();Set<String> seen=new HashSet<>();
            for(String value:places){String key=BookingValidator.normalize(value);if(seen.add(key))unique.add(value);}
            if(pickup==null&&!unique.isEmpty())pickup=unique.get(0);
            if(dropoff==null&&unique.size()>1)dropoff=unique.get(1);
        }
        if(pickup==null||dropoff==null||!Double.isFinite(base))return null;
        float avg=confidenceCount==0?0f:Math.min(1f,confidence/confidenceCount);
        Booking b=new Booking(PsgcDataset.canonicalize(pickup),PsgcDataset.canonicalize(dropoff),base,extra,pickupKm,avg,frameDetectedAt,frameDetectedAt);
        b.vehicleType=vehicle;b.bookingType=bookingType;b.setBookingCode(bookingCode);return b;
    }

    private static boolean isPlausiblePlace(String value){
        if(value==null||value.length()<3||value.matches(".*\\d{4,}.*")||isUiOrFareText(value))return false;
        String normalized=BookingValidator.normalize(value);
        // Lalamove collapsed cards often show bare endpoint names without PICKUP/DROPOFF
        // labels (for example "San Mateo" and "Paranaque City"). Accept exact PSGC
        // aliases even when the name is ambiguous; ambiguity is handled later by the
        // geographic verification layer, not by discarding the OCR text here.
        boolean knownAdministrativeName = !PsgcDataset.findAllByName(value).isEmpty();
        return value.contains(",") || knownAdministrativeName || PsgcDataset.resolve(value)!=null
                || normalized.contains("barangay") || normalized.startsWith("brgy ")
                || normalized.contains("city") || normalized.contains("municipality")
                || normalized.contains("quezon") || normalized.contains("manila")
                || normalized.equals("san mateo") || normalized.equals("san francisco del monte");
    }
    private static boolean looksLikeBookingFragment(List<Text.Line> lines){
        StringBuilder b=new StringBuilder();for(Text.Line l:lines)b.append(l.getText()).append(' ');
        String s=b.toString().toLowerCase(Locale.ROOT);
        return MONEY.matcher(s).find()||s.contains("pickup")||s.contains("dropoff")||s.contains("drop off")||s.contains("km");
    }
    private static String canonicalVehicle(String v){String x=v.toLowerCase(Locale.ROOT);if(x.contains("motor"))return "MOTORCYCLE";if(x.contains("sedan")||x.contains("hatchback"))return "CAR";if(x.equals("mpv")||x.equals("suv"))return x.toUpperCase(Locale.ROOT);if(x.contains("van"))return "VAN";if(x.contains("truck")||x.contains("wheeler"))return "TRUCK";return x.toUpperCase(Locale.ROOT);}
    private static String cleanPlace(String s){if(s==null)return null;String x=s.replaceAll("^[•·\\-–—]+\\s*","").replaceAll("\\s+"," ").trim();return x.length()<3?null:x;}
    private static boolean isUiOrFareText(String s){
        String x=s.toLowerCase(Locale.ROOT);
        return x.contains("pick up now")||x.contains("pickup now")||x.contains("drop off")||x.contains("php")||x.contains("km")
                ||x.contains("lalamove")||x.contains("motorcycle")||x.contains("priority")||x.contains("delivery")||x.contains("regular")
                ||x.contains("express")||x.contains("book now")||x.contains("accept")||x.matches(".*[₱+].*");
    }
}
