package com.riderwise.ai;

import java.util.*;

/** Offline recommendation ranking using local coordinates only; all route distances are straight-line estimates. */
public class RecommendationEngine {
    private static final int MAX_CANDIDATES=10, MAX_COMBINATION_NODES=6000, MAX_RESULTS=30;
    public static class Recommendation {
        public final List<Booking> bookings;
        public final double totalFare,score,detourKm,areaActivityScore,farePerReportedKm;
        public final String compatibility,sequence,explanation;
        Recommendation(List<Booking> bookings,double fare,double score,String label,String sequence,double detour,double area,double farePerKm,String explanation){
            this.bookings=Collections.unmodifiableList(new ArrayList<>(bookings));this.totalFare=fare;this.score=score;
            this.compatibility=label;this.sequence=sequence;this.detourKm=detour;this.areaActivityScore=area;this.farePerReportedKm=farePerKm;this.explanation=explanation;
        }
    }
    private static final class Search {double bestDistance=Double.POSITIVE_INFINITY;String bestSequence="";int nodes;}
    private final RouteCompatibilityEngine matcher=new RouteCompatibilityEngine();

    /**
     * Finds compatible booking pairs while the driver has not accepted a reference booking.
     * This is deliberately a route-similarity shortlist, not a claim that two jobs can be
     * combined operationally. Only locations with available coordinates are evaluated.
     */
    public List<Recommendation> recommendWithoutReference(List<Booking> all){
        if(all==null||all.size()<2)return Collections.emptyList();
        List<Booking> candidates=new ArrayList<>();
        Set<String> seen=new HashSet<>();
        for(Booking b:all){
            if(b==null||!BookingValidator.isValid(b)||b.reference||"ACCEPTED".equalsIgnoreCase(b.status))continue;
            if(!seen.add(b.fingerprint))continue;
            if(GeographicDataset.get(b.pickup)==null||GeographicDataset.get(b.dropoff)==null)continue;
            candidates.add(b);
        }
        // Preserve all locally seen cards (the store is bounded), but avoid quadratic work
        // on an unexpectedly large database result.
        if(candidates.size()>100)candidates=new ArrayList<>(candidates.subList(0,100));
        Map<String,Recommendation> bestBySuggestedBooking=new LinkedHashMap<>();
        for(int i=0;i<candidates.size();i++)for(int j=i+1;j<candidates.size();j++){
            Booking a=candidates.get(i),b=candidates.get(j);
            double pickupGap=GeoMatcher.distanceKm(GeographicDataset.get(a.pickup),GeographicDataset.get(b.pickup));
            double dropGap=GeoMatcher.distanceKm(GeographicDataset.get(a.dropoff),GeographicDataset.get(b.dropoff));
            if(!Double.isFinite(pickupGap)||!Double.isFinite(dropGap)||pickupGap>6d||dropGap>9d)continue;
            if(a.vehicleType!=null&&!a.vehicleType.isEmpty()&&b.vehicleType!=null&&!b.vehicleType.isEmpty()
                    &&!a.vehicleType.equalsIgnoreCase(b.vehicleType))continue;
            double pickupFit=Math.max(0d,1d-pickupGap/6d);
            double dropFit=Math.max(0d,1d-dropGap/9d);
            double score=pickupFit*.45d+dropFit*.55d;
            boolean ambiguousPickup=isAmbiguousBarePlace(a.pickup)||isAmbiguousBarePlace(b.pickup);
            boolean ambiguousDropoff=isAmbiguousBarePlace(a.dropoff)||isAmbiguousBarePlace(b.dropoff);
            boolean needsVerification=ambiguousPickup||ambiguousDropoff;
            if(needsVerification)score=Math.min(score,.59d);
            String label=needsVerification?"POTENTIALLY COMPATIBLE — VERIFY ADDRESS"
                    :((pickupGap<=2d&&dropGap<=3d)?"HIGH ROUTE SIMILARITY":"POTENTIALLY COMPATIBLE");
            // The booking first observed earlier is the comparison anchor; the later-seen
            // booking is the one surfaced as a candidate to review. Same-frame pairs keep
            // the visible top-to-bottom order from the OCR extractor.
            Booking anchor=a, suggested=b;
            if (b.firstDetectedAt<a.firstDetectedAt) { anchor=b; suggested=a; }
            String explanation="No accepted reference booking yet. Compare the previously observed route ("
                    +anchor.pickup+" → "+anchor.dropoff+") with this later-seen candidate ("
                    +suggested.pickup+" → "+suggested.dropoff+"). Their pickup areas are about "
                    +String.format(Locale.US,"%.1f km",pickupGap)+" apart and destinations about "
                    +String.format(Locale.US,"%.1f km",dropGap)+" apart. This is a straight-line place-centroid comparison, not road routing or proof they can be combined."
                    +(needsVerification?" At least one short place name is ambiguous; manually open the card and verify its full address before relying on this suggestion.":"");
            Recommendation recommendation=new Recommendation(Arrays.asList(anchor,suggested),
                    anchor.totalFare+suggested.totalFare,score,label,
                    "EARLIER OBSERVED: "+anchor.pickup+" → "+anchor.dropoff+" | REVIEW THIS BOOKING: "+suggested.pickup+" → "+suggested.dropoff,
                    Double.NaN,0d,Double.NaN,explanation);
            Recommendation previous=bestBySuggestedBooking.get(suggested.fingerprint);
            if(previous==null||recommendation.score>previous.score)bestBySuggestedBooking.put(suggested.fingerprint,recommendation);
        }
        List<Recommendation> out=new ArrayList<>(bestBySuggestedBooking.values());
        out.sort((a,b)->Double.compare(b.score,a.score));
        return new ArrayList<>(out.subList(0,Math.min(30,out.size())));
    }

    private static boolean isAmbiguousBarePlace(String raw){
        if(raw==null||raw.contains(","))return false;
        List<PsgcDataset.Record> matches=PsgcDataset.findAllByName(raw.trim());
        return matches.size()>1;
    }

    public List<Recommendation> recommend(List<Booking> all,Booking reference){
        if(reference==null||!BookingValidator.isValid(reference)||all==null)return Collections.emptyList();
        if(isAmbiguousBarePlace(reference.pickup)) return Collections.emptyList();
        List<Booking> candidates=new ArrayList<>();Set<String> seen=new HashSet<>();
        for(Booking b:all){
            if(b==null||!BookingValidator.isValid(b)||b.fingerprint.equals(reference.fingerprint))continue;
            if(isAmbiguousBarePlace(b.pickup)) continue;
            LocationVerificationManager.Result verification=LocationVerificationManager.evaluate(reference,b);
            if(verification.requiresUserVerification()) continue;
            if(reference.vehicleType!=null&&!reference.vehicleType.isEmpty()&&b.vehicleType!=null&&!b.vehicleType.isEmpty()
                    &&!reference.vehicleType.equalsIgnoreCase(b.vehicleType))continue;
            if(seen.add(b.fingerprint))candidates.add(b);
        }
        candidates.sort((a,b)->{int c=Float.compare(b.confidence,a.confidence);return c!=0?c:Long.compare(b.lastDetectedAt,a.lastDetectedAt);});
        if(candidates.size()>MAX_CANDIDATES)candidates=new ArrayList<>(candidates.subList(0,MAX_CANDIDATES));
        List<Recommendation> out=new ArrayList<>();Set<String> keys=new HashSet<>();
        enumerate(candidates,0,new ArrayList<>(),reference,all,out,keys);
        out.sort((a,b)->Double.compare(b.score,a.score));
        return new ArrayList<>(out.subList(0,Math.min(MAX_RESULTS,out.size())));
    }
    private void enumerate(List<Booking> source,int index,List<Booking> chosen,Booking reference,List<Booking> history,
                           List<Recommendation> out,Set<String> keys){
        if(!chosen.isEmpty())evaluate(chosen,reference,history,out,keys);
        if(chosen.size()>=6)return;
        for(int i=index;i<source.size();i++){chosen.add(source.get(i));enumerate(source,i+1,chosen,reference,history,out,keys);chosen.remove(chosen.size()-1);}
    }
    private void evaluate(List<Booking> chosen,Booking reference,List<Booking> history,List<Recommendation> out,Set<String> keys){
        List<String> ids=new ArrayList<>();for(Booking b:chosen)ids.add(b.fingerprint);Collections.sort(ids);
        if(!keys.add(String.join("||",ids)))return;
        GeographicDataset.Point start=GeographicDataset.get(reference.dropoff);if(start==null)return;
        for(Booking b:chosen)if(GeographicDataset.get(b.pickup)==null||GeographicDataset.get(b.dropoff)==null)return;
        Search search=new Search();dfs(chosen,new boolean[chosen.size()],new boolean[chosen.size()],start,0d,new ArrayList<>(),search);
        if(search.bestSequence.isEmpty()||!Double.isFinite(search.bestDistance))return;
        double fare=reference.totalFare,baseline=0d,confidence=reference.confidence,compatibility=0d,area=0d;
        // Lalamove's orange-header km value is rider-to-pickup proximity, not delivery distance.
        // Never use it as a denominator for fare-per-kilometre calculations.
        String label="SAME ROUTE";
        boolean parentLocalityFallback=false;
        for(Booking b:chosen){
            fare+=b.totalFare;confidence+=b.confidence;
            baseline+=GeoMatcher.distanceKm(GeographicDataset.get(b.pickup),GeographicDataset.get(b.dropoff));
            RouteCompatibilityEngine.Result r=matcher.evaluate(reference,b);compatibility+=r.score;
            parentLocalityFallback |= r.usesParentLocalityFallback;
            area+=GeographicIntelligence.localPickupActivityScore(b.pickup,history);
            if(!r.feasible)label=r.label;else if("SAME ROUTE".equals(label)&&!"SAME ROUTE".equals(r.label))label=r.label;
        }
        double detour=Math.max(0d,search.bestDistance-baseline),avgConfidence=confidence/(chosen.size()+1d);
        double avgCompatibility=compatibility/chosen.size(),avgArea=area/chosen.size();
        double detourFactor=1d/(1d+detour/15d),fareFactor=Math.min(1d,fare/1500d);
        double score=avgCompatibility*.36d+avgConfidence*.26d+detourFactor*.23d+fareFactor*.10d+avgArea*.05d;
        double farePerKm=Double.NaN;
        String fareText=" Fare/km unavailable: the visible Lalamove km value is rider-to-pickup distance, not delivery distance.";
        String localityNote=parentLocalityFallback
                ? " At least one barangay was resolved only to its parent city; this is a coarse city-level match, not a precise barangay route."
                : "";
        String why="Route fit "+Math.round(avgCompatibility*100)+"%; OCR confidence "+Math.round(avgConfidence*100)
                +"%; pickup-area history signal "+Math.round(avgArea*100)+"%."+fareText
                +" Route distance remains a straight-line estimate, not road routing."+localityNote;
        out.add(new Recommendation(chosen,fare,score,label,search.bestSequence,detour,avgArea,farePerKm,why));
    }
    private void dfs(List<Booking> bookings,boolean[] picked,boolean[] delivered,GeographicDataset.Point at,double distance,List<String> sequence,Search best){
        if(++best.nodes>MAX_COMBINATION_NODES||distance>=best.bestDistance)return;
        boolean complete=true;for(boolean value:delivered)if(!value){complete=false;break;}
        if(complete){best.bestDistance=distance;best.bestSequence=String.join(" → ",sequence);return;}
        for(int i=0;i<bookings.size();i++){
            GeographicDataset.Point pickup=GeographicDataset.get(bookings.get(i).pickup),drop=GeographicDataset.get(bookings.get(i).dropoff);
            if(!picked[i]){double leg=GeoMatcher.distanceKm(at,pickup);if(Double.isFinite(leg)&&leg<=60d){picked[i]=true;sequence.add("PICKUP "+bookings.get(i).pickup);dfs(bookings,picked,delivered,pickup,distance+leg,sequence,best);sequence.remove(sequence.size()-1);picked[i]=false;}}
            else if(!delivered[i]){double leg=GeoMatcher.distanceKm(at,drop);if(Double.isFinite(leg)&&leg<=80d){delivered[i]=true;sequence.add("DROP "+bookings.get(i).dropoff);dfs(bookings,picked,delivered,drop,distance+leg,sequence,best);sequence.remove(sequence.size()-1);delivered[i]=false;}}
        }
    }
}
