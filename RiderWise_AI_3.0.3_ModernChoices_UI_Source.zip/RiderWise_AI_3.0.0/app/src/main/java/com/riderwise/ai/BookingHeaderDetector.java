package com.riderwise.ai;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds wide orange Lalamove-style booking header bands independently of OCR.
 * This gives the UI a visual card count even when ML Kit misses header text.
 */
public final class BookingHeaderDetector {
    public interface PixelSource { int getPixel(int x, int y); }

    private BookingHeaderDetector() { }

    public static List<Integer> findHeaderTops(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return new ArrayList<>();
        return findHeaderTops(bitmap.getWidth(), bitmap.getHeight(), bitmap::getPixel);
    }

    /** Pure detector overload so band detection can be unit-tested without Android UI. */
    public static List<Integer> findHeaderTops(int width, int height, PixelSource pixels) {
        List<Integer> tops = new ArrayList<>();
        if (width < 100 || height < 100 || pixels == null) return tops;

        int stepX = Math.max(1, width / 600);
        int stepY = Math.max(1, height / 1200);
        int samplesPerRow = (width + stepX - 1) / stepX;
        int minOrange = (int) Math.ceil(samplesPerRow * 0.42);
        int minRun = (int) Math.ceil(samplesPerRow * 0.34);
        int minBandRows = Math.max(3, 6 / stepY);
        int maxGapRows = Math.max(1, 5 / stepY);

        int bandStart = -1;
        int lastCandidate = -1;
        int candidateRows = 0;
        for (int y = 0; y < height; y += stepY) {
            int orange = 0, longest = 0, run = 0;
            for (int x = 0; x < width; x += stepX) {
                if (isHeaderOrange(pixels.getPixel(x, y))) {
                    orange++;
                    run++;
                    if (run > longest) longest = run;
                } else run = 0;
            }
            boolean candidate = orange >= minOrange && longest >= minRun;
            if (candidate) {
                if (bandStart < 0 || (y - lastCandidate) / stepY > maxGapRows) {
                    if (bandStart >= 0 && candidateRows >= minBandRows) tops.add(bandStart);
                    bandStart = y;
                    candidateRows = 0;
                }
                candidateRows++;
                lastCandidate = y;
            }
        }
        if (bandStart >= 0 && candidateRows >= minBandRows) tops.add(bandStart);
        return tops;
    }

    private static boolean isHeaderOrange(int color) {
        int r = (color >>> 16) & 0xFF;
        int g = (color >>> 8) & 0xFF;
        int b = color & 0xFF;
        return r >= 185 && g >= 28 && g <= 155 && b <= 105 && r - g >= 55 && g - b >= 8;
    }
}
