package com.riderwise.ai;

/** Route comparison uses great-circle estimates only; it never reports road distance or travel time. */
public class RouteCompatibilityEngine {
    public static final class Result {
        public final String label;
        public final double score, deviationKm;
        public final boolean feasible;
        public final boolean usesParentLocalityFallback;
        public final String basis;
        Result(String label, double score, double deviationKm, boolean feasible) {
            this(label, score, deviationKm, feasible, false,
                    "STRAIGHT-LINE GEOGRAPHIC ESTIMATE; NOT ROAD ROUTING");
        }
        Result(String label, double score, double deviationKm, boolean feasible,
               boolean parentFallback, String basis) {
            this.label=label; this.score=score; this.deviationKm=deviationKm; this.feasible=feasible;
            this.usesParentLocalityFallback=parentFallback; this.basis=basis;
        }
    }

    public Result evaluate(Booking reference, Booking candidate) {
        if (!BookingValidator.isValid(reference) || !BookingValidator.isValid(candidate))
            return new Result("INCOMPATIBLE", 0d, Double.NaN, false);
        GeographicDataset.LocationMatch refPickup=GeographicDataset.resolveLocation(reference.pickup);
        GeographicDataset.LocationMatch refDrop=GeographicDataset.resolveLocation(reference.dropoff);
        GeographicDataset.LocationMatch candidatePickup=GeographicDataset.resolveLocation(candidate.pickup);
        GeographicDataset.LocationMatch candidateDrop=GeographicDataset.resolveLocation(candidate.dropoff);
        boolean parentFallback=(refPickup!=null&&refPickup.usesParentLocality)
                ||(refDrop!=null&&refDrop.usesParentLocality)
                ||(candidatePickup!=null&&candidatePickup.usesParentLocality)
                ||(candidateDrop!=null&&candidateDrop.usesParentLocality);
        String estimateBasis=parentFallback
                ? "CITY-LEVEL STRAIGHT-LINE ESTIMATE; BARANGAY RESOLVED TO PARENT CITY; NOT BARANGAY-LEVEL OR ROAD ROUTING"
                : "STRAIGHT-LINE GEOGRAPHIC ESTIMATE; NOT ROAD ROUTING";
        String suffix=parentFallback?" (CITY-LEVEL APPROX.)":"";
        GeographicDataset.Point start=GeographicDataset.get(reference.pickup);
        GeographicDataset.Point end=GeographicDataset.get(reference.dropoff);
        GeographicDataset.Point pickup=GeographicDataset.get(candidate.pickup);
        GeographicDataset.Point drop=GeographicDataset.get(candidate.dropoff);
        if (start==null||end==null||pickup==null||drop==null)
            return new Result("POSSIBLE COMPATIBILITY"+suffix,0.25d,Double.NaN,false,parentFallback,estimateBasis);

        double routeLength=GeoMatcher.distanceKm(start,end);
        double pickupDeviation=GeoMatcher.progress(start,end,pickup);
        double dropDeviation=GeoMatcher.progress(start,end,drop);
        double pickupProgress=GeoMatcher.distanceKm(start,pickup);
        double dropProgress=GeoMatcher.distanceKm(start,drop);
        double candidateLength=GeoMatcher.distanceKm(pickup,drop);
        double deviation=Math.max(pickupDeviation,dropDeviation);
        if (!Double.isFinite(routeLength)||!Double.isFinite(candidateLength)||routeLength<0.1d)
            return new Result("POSSIBLE COMPATIBILITY"+suffix,0.2d,Double.NaN,false,parentFallback,estimateBasis);
        if (candidateLength>60d || pickupProgress>Math.max(65d,routeLength+35d))
            return new Result("INCOMPATIBLE"+suffix,0.03d,deviation,false,parentFallback,estimateBasis);
        if (dropProgress+3d<pickupProgress)
            return new Result("REVERSE DIRECTION"+suffix,0.10d,deviation,false,parentFallback,estimateBasis);
        if (pickupProgress>routeLength+20d || pickupDeviation>20d || dropDeviation>25d)
            return new Result("EXCESSIVE BACKTRACKING"+suffix,0.08d,deviation,false,parentFallback,estimateBasis);
        if (pickupDeviation<=2d&&dropDeviation<=2d)
            return new Result("SAME ROUTE"+suffix,0.95d,deviation,true,parentFallback,estimateBasis);
        if (pickupDeviation<=5d&&dropDeviation<=7d)
            return new Result("ALONG THE WAY"+suffix,0.82d,deviation,true,parentFallback,estimateBasis);
        if (pickupDeviation<=10d||dropDeviation<=10d)
            return new Result("NEAR THE ROUTE"+suffix,0.60d,deviation,true,parentFallback,estimateBasis);
        return new Result("POSSIBLE COMPATIBILITY"+suffix,0.30d,deviation,false,parentFallback,estimateBasis);
    }
}
