package com.riderwise.ai;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_DATA = "resultData";
    private static final int NOTIFICATION_ID = 210;
    private Handler handler;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private OcrProcessor ocr;
    private BookingStore store;
    private RecommendationQueueStore recommendationQueue;
    private LiteRtLocalAnalyzer offlineAi;
    private volatile List<Integer> aiRankedIndexes = Collections.emptyList();
    private volatile String aiRankingSignature = "";
    private volatile String lastAiRankingRequest = "";
    private final AtomicBoolean aiRankingInFlight = new AtomicBoolean(false);
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private long lastFrameHash = Long.MIN_VALUE;
    private int captureWidth, captureHeight, captureDensity;
    private long lastFrameAt;
    private String lastAcceptedFingerprint = "";
    private long lastAcceptedAt = 0L;
    private volatile boolean projectionRevoked;
    private volatile boolean paused;
    private final Runnable scan = new Runnable() {
        @Override public void run() {
            if (!paused) captureAndProcess();
            if (handler != null && !paused) handler.postDelayed(this, UpgradeConfig.get(ScreenCaptureService.this).scanIntervalMs());
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        PsgcDataset.initialize(getApplicationContext());
        ocr = new OcrProcessor();
        store = new BookingStore(this);
        recommendationQueue = new RecommendationQueueStore(this);
        // Share the user-loaded model instance; do not auto-load a multi-GB model on service start.
        offlineAi = LiteRtLocalAnalyzer.get(getApplicationContext());
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "PAUSE".equals(intent.getAction())) { paused=true; if(handler!=null)handler.removeCallbacks(scan); FloatingAssistantService.update(this,"MONITORING PAUSED\nTap Resume in the floating panel."); return START_NOT_STICKY; }
        if (intent != null && "RESUME".equals(intent.getAction())) { if(projection==null||projectionRevoked){FloatingAssistantService.update(this,"Capture permission expired. Re-authorize in RiderWise.");return START_NOT_STICKY;} paused=false; if(handler!=null){handler.removeCallbacks(scan);handler.post(scan);} FloatingAssistantService.update(this,"Monitoring resumed"); return START_NOT_STICKY; }
        if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (intent == null || !intent.hasExtra(EXTRA_DATA)) { stopSelf(); return START_NOT_STICKY; }
        // A new explicit user authorization is required for every new projection session.
        if (projection != null) stopCapture();
        projectionRevoked = false;
        paused = false;
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(NOTIFICATION_ID, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(NOTIFICATION_ID, notification());
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) data = intent.getParcelableExtra(EXTRA_DATA, Intent.class);
        else data = (Intent) intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) { stopSelf(); return START_NOT_STICKY; }
        MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try { projection = mpm.getMediaProjection(resultCode, data); }
        catch (SecurityException revoked) {
            android.util.Log.e("RiderWise", "MediaProjection authorization rejected; request permission again", revoked);
            stopSelf(); return START_NOT_STICKY;
        }
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    projectionRevoked = true;
                    // Android/ColorOS revoked the token: clean up and wait for a fresh user grant.
                    stopCaptureResources(false);
                    stopSelf();
                }
            }, handler);
            startCapture();
        } catch (RuntimeException captureStartError) {
            android.util.Log.e("RiderWise", "MediaProjection could not start; fresh consent is required", captureStartError);
            stopCapture(); stopSelf(); return START_NOT_STICKY;
        }
        handler.removeCallbacks(scan);
        handler.post(scan);
        if (android.provider.Settings.canDrawOverlays(this)
                && UpgradeConfig.get(this).enabled("floating_dashboard")
                && getSharedPreferences(FloatingAssistantService.PREFS,0)
                    .getBoolean(FloatingAssistantService.KEY_VISIBLE,true)) {
            try { startService(new Intent(this, FloatingAssistantService.class)); }
            catch (RuntimeException startError) {
                android.util.Log.e("RiderWise", "Floating dashboard could not be started", startError);
            }
        }
        return START_NOT_STICKY;
    }

    private void startCapture() {
        if (projection == null || projectionRevoked) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        captureWidth = Math.max(1, dm.widthPixels);
        captureHeight = Math.max(1, dm.heightPixels);
        captureDensity = dm.densityDpi;
        reader = ImageReader.newInstance(captureWidth, captureHeight, android.graphics.PixelFormat.RGBA_8888, 2);
        display = projection.createVirtualDisplay("RiderWiseCapture", captureWidth, captureHeight, captureDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        if (display == null) throw new IllegalStateException("Unable to create MediaProjection virtual display");
    }

    private void refreshCaptureSizeIfChanged() {
        if (projection == null || projectionRevoked) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        if (dm.widthPixels != captureWidth || dm.heightPixels != captureHeight || dm.densityDpi != captureDensity) {
            // Keep the existing MediaProjection VirtualDisplay. Android 14+ restricts
            // creating multiple virtual displays from one projection token.
            if (reader != null) { reader.close(); reader = null; }
            captureWidth = Math.max(1, dm.widthPixels);
            captureHeight = Math.max(1, dm.heightPixels);
            captureDensity = dm.densityDpi;
            reader = ImageReader.newInstance(captureWidth, captureHeight, android.graphics.PixelFormat.RGBA_8888, 2);
            if (display == null) throw new IllegalStateException("Capture display is unavailable");
            display.resize(captureWidth, captureHeight, captureDensity);
            display.setSurface(reader.getSurface());
            lastFrameHash = Long.MIN_VALUE;
        }
    }

    private void captureAndProcess() {
        if (projection == null || projectionRevoked || reader == null) return;
        UpgradeConfig config = UpgradeConfig.get(this);
        if (!config.enabled("screen_capture") || !config.enabled("booking_ocr")) return;
        if (!processing.compareAndSet(false, true)) return;
        // The floating panel can cover the second/third Lalamove cards. Hide it briefly
        // before MediaProjection captures the display, then restore it after the frame copy.
        FloatingAssistantService.setTemporarilyHiddenForCapture(true);
        if (!handler.postDelayed(this::captureFrameWhileOverlayHidden, 220)) { FloatingAssistantService.setTemporarilyHiddenForCapture(false); processing.set(false); }
    }

    private void captureFrameWhileOverlayHidden() {
        Image image = null;
        try {
            if (projection == null || projectionRevoked) { processing.set(false); return; }
            try { refreshCaptureSizeIfChanged(); }
            catch (RuntimeException e) {
                android.util.Log.e("RiderWise", "Capture surface refresh failed", e);
                processing.set(false); return;
            }
            if (reader == null) { processing.set(false); return; }
            image = reader.acquireLatestImage();
            if (image == null) {
                // No fresh frame is available yet. The next scan tick retries.
                processing.set(false); return;
            }
            lastFrameAt = System.currentTimeMillis();
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
            int width = image.getWidth(), height = image.getHeight();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            Bitmap bitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
            padded.recycle();
            image.close(); image = null;

            long hash = sampleHash(bitmap);
            if (hash == lastFrameHash) {
                bitmap.recycle(); processing.set(false); return;
            }
            lastFrameHash = hash;
            // Orange header bands are a visual count independent of OCR text recognition.
            UpgradeConfig config = UpgradeConfig.get(this);
            java.util.List<Integer> visualHeaderTops = config.enabled("visual_booking_count")
                    ? BookingHeaderDetector.findHeaderTops(bitmap) : java.util.Collections.emptyList();
            boolean accepted = ocr.process(bitmap, visualHeaderTops, (bookings, recognizedText) -> {
                try {
                    if (recognizedText == null) lastFrameHash = Long.MIN_VALUE;
                    int uniqueBookingsAddedThisFrame = 0;
                    int previouslySeenCardsReRead = 0;
                    int oldBookingsReappeared = 0;
                    long observationNow = System.currentTimeMillis();
                    for (Booking b : bookings) {
                        long priorSeenAt = store.getLastSeenAt(b.fingerprint);
                        boolean firstTimeSeen = store.upsert(b);
                        if (firstTimeSeen) uniqueBookingsAddedThisFrame++;
                        else {
                            previouslySeenCardsReRead++;
                            if (priorSeenAt > 0L && observationNow - priorSeenAt > 10000L) oldBookingsReappeared++;
                        }
                    }
                    Booking detectedAccepted = config.enabled("accepted_booking_detection")
                            && config.enabled("accepted_booking_history")
                            ? AcceptedBookingDetector.detect(recognizedText) : null;
                    boolean firstAcceptedSaved = false;
                    boolean newAcceptedRecord = false;
                    if (detectedAccepted != null) {
                        long acceptedNow = System.currentTimeMillis();
                        boolean repeatedSameScreen = detectedAccepted.fingerprint.equals(lastAcceptedFingerprint)
                                && acceptedNow - lastAcceptedAt < 30000L;
                        if (!repeatedSameScreen) {
                            firstAcceptedSaved = store.recordAcceptedBooking(detectedAccepted);
                            newAcceptedRecord = true;
                            lastAcceptedFingerprint = detectedAccepted.fingerprint;
                            lastAcceptedAt = acceptedNow;
                        }
                    }
                    List<Booking> all = store.getRecent();
                    Booking reference = store.getReference();
                    int visibleCards = visualHeaderTops.isEmpty()
                            ? ocr.getLastDetectedCardCount() : visualHeaderTops.size();
                    int partialCards = ocr.getLastPartialCardCount();
                    StringBuilder summary = new StringBuilder("LIVE OCR • ")
                            .append(new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date()))
                            .append("\nVisible booking cards: ").append(visibleCards)
                            .append("\nParsed complete: ").append(bookings.size())
                            .append("\nPartial/incomplete cards: ").append(partialCards)
                            .append("\nNew unique bookings this scan: ").append(uniqueBookingsAddedThisFrame)
                            .append("\nPreviously seen cards re-read: ").append(previouslySeenCardsReRead)
                            .append("\nOld bookings reappeared after 10+ seconds: ").append(oldBookingsReappeared)
                            .append("\nSaved booking history (7 days): ").append(all.size())
                            .append("\nHistory order: first-seen time; resurfaced old cards are not treated as new.");
                    if (firstAcceptedSaved) summary.append("\nFIRST ACCEPTED BOOKING AUTO-SAVED as reference.");
                    else if (newAcceptedRecord && reference != null)
                        summary.append("\nAdditional accepted booking saved; current reference kept.");
                    if (reference != null) {
                        summary.append("\nACCEPTED REFERENCE: ").append(reference.pickup).append(" → ").append(reference.dropoff)
                                .append("\nOCR confidence: ").append(String.format(java.util.Locale.US,"%.0f%%",reference.confidence*100f));
                        if (PsgcDataset.findAllByName(reference.pickup).size()>1 && !reference.pickup.contains(","))
                            summary.append("\n⚠ REFERENCE PICKUP NEEDS ADDRESS VERIFICATION: the short place name is duplicated in the Philippine geographic index. Open the accepted booking details to confirm its city/municipality.");
                        boolean rideModeOn=getSharedPreferences(FloatingAssistantService.PREFS,0).getBoolean(FloatingAssistantService.KEY_RIDE,false);
                        java.util.List<RecommendationEngine.Recommendation> recs =
                                config.enabled("route_recommendations") && (!config.enabled("ride_mode_gate") || rideModeOn)
                                ? new RecommendationEngine().recommend(all, reference)
                                : java.util.Collections.emptyList();
                        recommendationQueue.refresh(recs, System.currentTimeMillis(), false);
                        if (config.enabled("offline_ai_recommendation_ranking") && !recs.isEmpty() && offlineAi != null && offlineAi.isReady()) {
                            String signature = buildAiRankingSignature(reference, recs);
                            if (!signature.equals(lastAiRankingRequest) && aiRankingInFlight.compareAndSet(false, true)) {
                                lastAiRankingRequest = signature;
                                offlineAi.rankRecommendations(reference, recs, new LiteRtLocalAnalyzer.RecommendationCallback() {
                                    @Override public void onRanked(java.util.List<Integer> order) {
                                        aiRankedIndexes = new java.util.ArrayList<>(order);
                                        aiRankingSignature = signature;
                                        aiRankingInFlight.set(false);
                                    }
                                    @Override public void onUnavailable(String reason) {
                                        android.util.Log.w("RiderWise", reason);
                                        aiRankingInFlight.set(false);
                                    }
                                });
                            }
                            if (signature.equals(aiRankingSignature) && !aiRankedIndexes.isEmpty()) {
                                recs = applyAiRanking(recs, aiRankedIndexes);
                                summary.append("\nOFFLINE AI: Ranked validated booking combinations using route fit, detour, OCR confidence and saved preferences.");
                            } else if (!signature.equals(lastAiRankingRequest)) {
                                summary.append("\nOFFLINE AI: Preparing analysis of validated combinations… deterministic ranking shown until ready.");
                            }
                        } else if (!recs.isEmpty()) {
                            summary.append("\nOFFLINE AI: Model not loaded; deterministic recommendation order remains active.");
                        }
                        // Ambiguous destinations stay visible as potential matches, but are excluded
                        // from final recommendation scoring until the rider expands the card and OCR
                        // reads a full locality-bearing address on a later scan.
                        java.util.Set<String> shownLocationWarnings = new java.util.HashSet<>();
                        for (Booking candidate : all) {
                            if (candidate == null || candidate.fingerprint.equals(reference.fingerprint)) continue;
                            LocationVerificationManager.Result verification =
                                    LocationVerificationManager.evaluate(reference, candidate);
                            if (verification.requiresUserVerification()) {
                                // If a later scan has already captured the expanded card, report
                                // that verified version instead of continuing to prompt for the short one.
                                if (LocationVerificationManager.findExpandedCounterpart(candidate, all) != null) continue;
                                if (!shownLocationWarnings.add(candidate.fingerprint)) continue;
                                boolean pickupSame = LocationVerificationManager.sameLocationLabel(
                                        candidate.pickup, reference.pickup);
                                if (pickupSame) summary.append("\nPOTENTIALLY COMPATIBLE: ").append(candidate.pickup)
                                        .append(" → ").append(candidate.dropoff)
                                        .append("\n⚠ DESTINATION NEEDS VERIFICATION: ")
                                        .append(verification.message)
                                        .append("\nACTION: Open this Lalamove booking card yourself to reveal the full address. RiderWise will re-check it on the next OCR scan. No automatic tap/click is performed.");
                                else summary.append("\nUNVERIFIED DESTINATION: ").append(candidate.pickup)
                                        .append(" → ").append(candidate.dropoff)
                                        .append("\n⚠ ").append(verification.message);
                                continue;
                            }
                            if (verification.isVerified()) {
                                Booking expanded = LocationVerificationManager.findExpandedCounterpart(candidate, all);
                                if (expanded != null) continue; // The expanded version is reported below.
                                if (candidate.dropoff.contains(",") && shownLocationWarnings.add(candidate.fingerprint)) {
                                    RouteCompatibilityEngine.Result route = new RouteCompatibilityEngine().evaluate(reference, candidate);
                                    summary.append("\nDESTINATION VERIFIED: ").append(verification.matchedRecord == null
                                            ? candidate.dropoff : verification.matchedRecord.name + ", " + verification.proposedLocality)
                                            .append("\nFINAL ROUTE CHECK: ").append(route.label)
                                            .append(" • ").append(route.basis);
                                }
                            }
                        }
                        for (Booking candidate : all) {
                            if (candidate == null || candidate.fingerprint.equals(reference.fingerprint)) continue;
                            Booking expanded = LocationVerificationManager.findExpandedCounterpart(candidate, all);
                            if (expanded == null) continue;
                            LocationVerificationManager.Result verified = LocationVerificationManager.evaluate(reference, expanded);
                            if (verified.isVerified() && shownLocationWarnings.add(expanded.fingerprint)) {
                                RouteCompatibilityEngine.Result route = new RouteCompatibilityEngine().evaluate(reference, expanded);
                                summary.append("\nFULL ADDRESS DETECTED: ").append(expanded.dropoff)
                                        .append("\nDESTINATION VERIFIED: ").append(verified.proposedLocality)
                                        .append("\nFINAL ROUTE CHECK: ").append(route.label)
                                        .append(" • ").append(route.basis);
                            }
                        }
                        int limit = Math.min(3, recs.size());
                        for (int n=0;n<limit;n++) {
                            RecommendationEngine.Recommendation r = recs.get(n);
                            summary.append("\n#").append(n+1).append(" ").append(r.bookings.size())
                                .append(" add • ₱").append(String.format(java.util.Locale.US,"%.2f",r.totalFare))
                                .append(" • ").append(r.compatibility)
                                .append(" • score ").append(Math.round(r.score*100)).append("/100")
                                .append(" • detour ").append(String.format(java.util.Locale.US,"%.1f km straight-line",r.detourKm))
                                .append("\n   ").append(r.explanation);
                        }
                        summary.append("\nPERSISTENT SAVED RECOMMENDATIONS: ").append(recommendationQueue.countActive())
                                .append("\nCandidates remain saved when buried; off-screen availability is unverified.")
                                .append(recommendationQueue.summary());
                        if (!config.enabled("route_recommendations"))
                            summary.append("\nRecommendations disabled by developer config.");
                        else if (!rideModeOn) summary.append("\nRide Mode OFF: ride-based recommendations paused.");
                        else if (recs.isEmpty()) summary.append("\nNo resolved compatible combination yet.");
                        summary.append("\nProfitability: ESTIMATE UNAVAILABLE (road distance/time not supplied)");
                    } else {
                        summary.append("\nNO ACCEPTED REFERENCE BOOKING YET.")
                                .append("\nScanning the available-booking history independently of a reference.");
                        boolean rideModeOn=getSharedPreferences(FloatingAssistantService.PREFS,0)
                                .getBoolean(FloatingAssistantService.KEY_RIDE,false);
                        List<RecommendationEngine.Recommendation> pairRecs =
                                config.enabled("route_recommendations") && (!config.enabled("ride_mode_gate") || rideModeOn)
                                ? new RecommendationEngine().recommendWithoutReference(all)
                                : Collections.emptyList();
                        recommendationQueue.refresh(pairRecs, System.currentTimeMillis(), false);
                        if (!pairRecs.isEmpty()) {
                            summary.append("\nREFERENCE-FREE MATCHING: Found ").append(pairRecs.size())
                                    .append(" candidate bookings related to previously scanned available routes.")
                                    .append("\nThese are suggestions to review; no booking is accepted automatically.");
                            int pairLimit=Math.min(5,pairRecs.size());
                            for(int n=0;n<pairLimit;n++){
                                RecommendationEngine.Recommendation r=pairRecs.get(n);
                                summary.append("\n#").append(n+1).append(" ").append(r.compatibility)
                                        .append(" • combined displayed fare ₱")
                                        .append(String.format(java.util.Locale.US,"%.2f",r.totalFare))
                                        .append(" • similarity score ").append(Math.round(r.score*100)).append("/100")
                                        .append("\n   ").append(r.sequence)
                                        .append("\n   ").append(r.explanation);
                            }
                        } else {
                            summary.append("\nNo route-similar pair can be verified from the currently indexed coordinates. Keep scrolling; detected bookings remain in local history.");
                        }
                        summary.append("\nSAVED REFERENCE-FREE SUGGESTIONS: ").append(recommendationQueue.countActive())
                                .append("\nSuggestions persist when their cards are buried; availability is not assumed.")
                                .append(recommendationQueue.summary());
                        if (!config.enabled("route_recommendations"))
                            summary.append("\nRecommendations disabled by developer config.");
                        else if (!rideModeOn && config.enabled("ride_mode_gate"))
                            summary.append("\nRide Mode OFF: recommendation display is paused, but booking history scanning continues.");
                    }
                    FloatingAssistantService.update(this, summary.toString());
                } catch (Exception callbackError) {
                    android.util.Log.e("RiderWise", "OCR result handling failed", callbackError);
                } finally { processing.set(false); }
            });
            if (!accepted) processing.set(false);
        } catch (Exception e) {
            if (image != null) image.close();
            processing.set(false);
            android.util.Log.e("RiderWise", "Capture/OCR cycle failed", e);
        } finally {
            FloatingAssistantService.setTemporarilyHiddenForCapture(false);
        }
    }


    private String buildAiRankingSignature(Booking reference, List<RecommendationEngine.Recommendation> recommendations) {
        StringBuilder value = new StringBuilder(reference.fingerprint).append('|');
        int count = Math.min(8, recommendations.size());
        for (int i = 0; i < count; i++) {
            List<String> ids = new ArrayList<>();
            for (Booking booking : recommendations.get(i).bookings) ids.add(booking.fingerprint);
            Collections.sort(ids);
            value.append(String.join(",", ids)).append(';');
        }
        return value.toString();
    }

    private List<RecommendationEngine.Recommendation> applyAiRanking(
            List<RecommendationEngine.Recommendation> recommendations, List<Integer> order) {
        List<RecommendationEngine.Recommendation> ranked = new ArrayList<>();
        Set<Integer> used = new HashSet<>();
        for (Integer index : order) {
            if (index != null && index >= 0 && index < recommendations.size() && used.add(index))
                ranked.add(recommendations.get(index));
        }
        for (int i = 0; i < recommendations.size(); i++) if (used.add(i)) ranked.add(recommendations.get(i));
        return ranked;
    }

    private long sampleHash(Bitmap bitmap) {
        long h=1469598103934665603L; int w=bitmap.getWidth(), height=bitmap.getHeight();
        for(int y=0;y<height;y+=Math.max(1,height/24)) for(int x=0;x<w;x+=Math.max(1,w/24))
            h=(h ^ bitmap.getPixel(x,y))*1099511628211L;
        return h;
    }
    private void stopCapture() { stopCaptureResources(true); }

    private void stopCaptureResources(boolean stopProjection) {
        FloatingAssistantService.setTemporarilyHiddenForCapture(false);
        if (handler != null) handler.removeCallbacks(scan);
        if (display != null) { display.release(); display = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (stopProjection && projection != null) {
            MediaProjection old = projection; projection = null;
            try { old.stop(); } catch (RuntimeException ignored) { }
        } else if (!stopProjection) {
            projection = null;
        }
        captureWidth = captureHeight = captureDensity = 0;
        processing.set(false);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("riderwise_capture", "RiderWise monitoring", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "riderwise_capture") : new Notification.Builder(this);
        return b.setContentTitle("RiderWise AI is monitoring")
                .setContentText("OCR scan interval: 2.5 seconds. Use only while safely stopped.")
                .setSmallIcon(android.R.drawable.ic_menu_view).build();
    }
    @Override public void onDestroy() { stopCapture(); if (ocr != null) ocr.close(); if (store != null) store.close(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
