package com.riderwise.ai;

import java.util.*;

/**
 * Offline-first geographic analytics over locally detected bookings.
 * It never invents coordinates: a heatmap point is emitted only when the
 * existing geographic index has a coordinate for the resolved place.
 */
public final class GeographicIntelligence {
    public static final String VERSION = "3.0.0-luzon-master-brain";
    private static final Set<String> LUZON_REGIONS = new HashSet<>(Arrays.asList(
            "National Capital Region (NCR)", "Cordillera Administrative Region (CAR)",
            "Region I (Ilocos Region)", "Region II (Cagayan Valley)",
            "Region III (Central Luzon)", "Region IV-A (CALABARZON)",
            "MIMAROPA Region", "Region V (Bicol Region)"));

    public static final class Hotspot {
        public final String place;
        public final int pickupCount, dropoffCount, totalCount;
        public final double latitude, longitude;
        public final boolean mappable;
        Hotspot(String name, int pickups, int dropoffs, GeographicDataset.Point point) {
            place=name; pickupCount=pickups; dropoffCount=dropoffs;
            totalCount=pickups+dropoffs; mappable=point!=null;
            latitude=point==null?Double.NaN:point.lat;
            longitude=point==null?Double.NaN:point.lon;
        }
    }

    public static final class Analysis {
        public final int bookingCount, pickupStops, dropoffStops, mappedStops, unresolvedStops;
        public final List<Hotspot> hotspots;
        public final String coverageLabel;
        Analysis(int bookings,int pickups,int drops,int mapped,int unresolved,List<Hotspot> top,String coverage) {
            bookingCount=bookings; pickupStops=pickups; dropoffStops=drops;
            mappedStops=mapped; unresolvedStops=unresolved;
            hotspots=Collections.unmodifiableList(top); coverageLabel=coverage;
        }
        public String summary() {
            return "Bookings analyzed: "+bookingCount+"\nPickup/drop-off stops: "+(pickupStops+dropoffStops)
                    +"\nStops with available approximate coordinates: "+mappedStops
                    +"\nUnmapped stops: "+unresolvedStops+"\nGeographic coverage: "+coverageLabel;
        }
    }

    private static final class Counts { int pickup, dropoff; }
    private GeographicIntelligence() {}

    public static Analysis analyze(List<Booking> bookings) {
        Map<String,Counts> counts=new HashMap<>();
        int pickupStops=0,dropoffStops=0,mapped=0,unresolved=0,valid=0;
        if(bookings!=null) for(Booking b:bookings) {
            if(!BookingValidator.isValid(b)) continue;
            valid++; pickupStops++; dropoffStops++;
            mapped += countStop(b.pickup,counts,true);
            mapped += countStop(b.dropoff,counts,false);
        }
        unresolved=pickupStops+dropoffStops-mapped;
        List<Hotspot> all=new ArrayList<>();
        for(Map.Entry<String,Counts> e:counts.entrySet()) {
            Counts c=e.getValue(); all.add(new Hotspot(e.getKey(),c.pickup,c.dropoff,GeographicDataset.get(e.getKey())));
        }
        all.sort((a,b)->{int c=Integer.compare(b.totalCount,a.totalCount);return c!=0?c:a.place.compareToIgnoreCase(b.place);});
        List<Hotspot> top=new ArrayList<>();
        for(Hotspot h:all) if(h.mappable&&top.size()<8) top.add(h);
        return new Analysis(valid,pickupStops,dropoffStops,mapped,unresolved,top,coverageDescription());
    }

    private static int countStop(String raw,Map<String,Counts> counts,boolean pickup) {
        GeographicDataset.Place place=GeographicDataset.resolve(raw);
        if(place==null) {
            PsgcDataset.Record record=PsgcDataset.resolveFromAddress(raw);
            if(record==null)record=PsgcDataset.resolve(raw);
            if(record!=null) {
                String canonical=record.name;
                Counts c=counts.computeIfAbsent(canonical,k->new Counts());
                if(pickup)c.pickup++;else c.dropoff++;
                return GeographicDataset.get(canonical)==null?0:1;
            }
            return 0;
        }
        Counts c=counts.computeIfAbsent(place.name,k->new Counts());
        if(pickup)c.pickup++;else c.dropoff++;
        return place.hasCoordinates()?1:0;
    }

    /**
     * Attempts to disambiguate a duplicate barangay name using the destination locality of the
     * accepted reference booking. A contextual result is inferred, not verified, and callers
     * must display a warning rather than treating it as an exact address.
     */
    public static GeographicDataset.LocationMatch resolveAgainstReference(String candidatePlace, String referenceDropoff) {
        GeographicDataset.LocationMatch direct=GeographicDataset.resolveLocation(candidatePlace);
        if(direct!=null) return direct;
        GeographicDataset.Place reference=GeographicDataset.resolve(referenceDropoff);
        String localityHint=reference==null?null:reference.province;
        if((localityHint==null||localityHint.trim().isEmpty())) {
            PsgcDataset.LocationResolution refAdmin=PsgcDataset.resolveLocation(referenceDropoff);
            if(refAdmin!=null && refAdmin.localityRecord!=null) localityHint=refAdmin.localityRecord.name;
        }
        return localityHint==null?null:GeographicDataset.resolveLocation(candidatePlace, localityHint);
    }

    /** Local-history signal for ranking a candidate pickup area (0..1, never a demand forecast). */
    public static double localPickupActivityScore(String placeName,List<Booking> history) {
        if(placeName==null||history==null||history.isEmpty())return 0d;
        String key=BookingValidator.normalize(placeName); if(key.isEmpty())return 0d;
        int hits=0;
        for(Booking b:history) if(BookingValidator.isValid(b)
                && BookingValidator.normalize(b.pickup).equals(key)) hits++;
        return Math.min(1d,hits/4d);
    }

    public static String coverageDescription() {
        if(!PsgcDataset.isLoaded()) return "PSGC unavailable";
        return "Luzon administrative index (NCR, CAR, Regions I–V incl. MIMAROPA); not a road map";
    }

    /** Returns true only when a resolved PSGC record belongs to this bundled Luzon scope. */
    public static boolean isWithinBundledLuzon(String placeName) {
        PsgcDataset.Record r=PsgcDataset.resolve(placeName);
        if(r==null)return false;
        String hierarchy=PsgcDataset.hierarchy(r);
        for(String region:LUZON_REGIONS) if(hierarchy.contains(region)) return true;
        return false;
    }
}
