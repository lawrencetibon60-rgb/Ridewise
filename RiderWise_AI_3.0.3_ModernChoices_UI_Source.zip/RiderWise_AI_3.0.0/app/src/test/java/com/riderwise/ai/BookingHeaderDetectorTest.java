package com.riderwise.ai;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class BookingHeaderDetectorTest {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int LALAMOVE_ORANGE = 0xFFFF4B00;

    @Test public void detectsThreeWideOrangeBookingHeaders() {
        int width = 600, height = 500;
        int[] pixels = new int[width * height];
        java.util.Arrays.fill(pixels, WHITE);
        paintBand(pixels, width, 45, 88, 35, 565);
        paintBand(pixels, width, 190, 233, 35, 565);
        paintBand(pixels, width, 335, 378, 35, 565);
        List<Integer> tops = BookingHeaderDetector.findHeaderTops(width, height,
                (x, y) -> pixels[y * width + x]);
        assertEquals(3, tops.size());
        assertEquals(Integer.valueOf(45), tops.get(0));
        assertEquals(Integer.valueOf(190), tops.get(1));
        assertEquals(Integer.valueOf(335), tops.get(2));
    }

    @Test public void ignoresSmallOrangeTabUnderline() {
        int width = 600, height = 300;
        int[] pixels = new int[width * height];
        java.util.Arrays.fill(pixels, WHITE);
        paintBand(pixels, width, 40, 54, 20, 105);
        assertTrue(BookingHeaderDetector.findHeaderTops(width, height,
                (x, y) -> pixels[y * width + x]).isEmpty());
    }

    @Test public void recognizesPickUpNowHeaderWithDistancePrefix() {
        String header = BookingExtractor.normalizeHeader("(~2.5 km) Pick Up Now");
        assertTrue(BookingExtractor.isBookingHeader(header));
    }

    private static void paintBand(int[] pixels, int width, int top, int bottom, int left, int right) {
        for (int y = top; y < bottom; y++)
            for (int x = left; x < right; x++) pixels[y * width + x] = LALAMOVE_ORANGE;
    }
}
