package com.riderwise.ai;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

public class BookingAndGeoTest {
    @Test public void barangayOnlyTatalonResolvesToQuezonCityParentWithoutClaimingBarangayCoordinates() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300121\",\"name\":\"Tatalon\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"}]}" );
        PsgcDataset.LocationResolution admin=PsgcDataset.resolveLocation("Tatalon");
        assertNotNull(admin);
        assertEquals("Tatalon",admin.matchedRecord.name);
        assertEquals("Bgy",admin.matchedRecord.level);
        assertEquals("Quezon City",admin.localityRecord.name);
        assertTrue(admin.resolvedFromBarangay);
        PsgcDataset.LocationResolution fullAddress=PsgcDataset.resolveLocation("Tatalon, Quezon City");
        assertNotNull(fullAddress);
        assertEquals("Tatalon",fullAddress.matchedRecord.name);
        assertEquals("Quezon City",fullAddress.localityRecord.name);
    }

    @Test public void barangayAddressCanUseParentCityForCoarseMapMatching() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300121\",\"name\":\"Tatalon\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"}]}" );
        GeographicDataset.LocationMatch match=GeographicDataset.resolveLocation("Brgy. Tatalon");
        assertNotNull(match);
        assertEquals("Tatalon",match.matchedRecord.name);
        assertEquals("Quezon City",match.localityRecord.name);
        assertTrue(match.usesParentLocality);
        assertNotNull(match.coordinatePlace);
        assertEquals("APPROXIMATE_CENTROID",match.coordinatePlace.coordinateStatus);
    }

    @Test public void sanMateoToTatalonCandidateCanBeComparedAtParentCityLevel() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300121\",\"name\":\"Tatalon\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"}]}" );
        Booking reference=new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking candidate=new Booking("San Mateo", "Tatalon", 120, Double.NaN, .90f, 2);
        RouteCompatibilityEngine.Result result=new RouteCompatibilityEngine().evaluate(reference,candidate);
        assertTrue(result.usesParentLocalityFallback);
        assertTrue(result.basis.contains("PARENT CITY"));
        assertTrue(result.label.contains("CITY-LEVEL APPROX."));
    }

    @Test public void duplicatePaltokUsesReferenceDestinationAsWarningOnlyInference() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300100\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"},"
                +"{\"psgc\":\"0301400000\",\"name\":\"Bulacan\",\"level\":\"Prov\",\"parentPsgc\":null},"
                +"{\"psgc\":\"0301404000\",\"name\":\"Angat\",\"level\":\"Mun\",\"parentPsgc\":\"0301400000\"},"
                +"{\"psgc\":\"0301404001\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"0301404000\"}]}");
        assertNull(PsgcDataset.resolveLocation("Paltok"));
        GeographicDataset.LocationMatch inferred = GeographicIntelligence.resolveAgainstReference("Paltok", "Quezon Avenue");
        assertNotNull(inferred);
        assertEquals("Paltok", inferred.matchedRecord.name);
        assertEquals("Quezon City", inferred.localityRecord.name);
        assertTrue(inferred.inferredFromContext);
        assertTrue(inferred.usesParentLocality);
        assertNull(GeographicDataset.get("Paltok"));
    }

    @Test public void duplicatePaltokStaysPotentialUntilFullAddressIsDetected() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300100\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"},"
                +"{\"psgc\":\"0301400000\",\"name\":\"Bulacan\",\"level\":\"Prov\",\"parentPsgc\":null},"
                +"{\"psgc\":\"0301404000\",\"name\":\"Angat\",\"level\":\"Mun\",\"parentPsgc\":\"0301400000\"},"
                +"{\"psgc\":\"0301404001\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"0301404000\"}]}");
        Booking reference=new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking shortCandidate=new Booking("San Mateo", "Paltok", 120, Double.NaN, .90f, 2);
        LocationVerificationManager.Result pending=LocationVerificationManager.evaluate(reference,shortCandidate);
        assertEquals(LocationVerificationManager.State.NEEDS_USER_VERIFICATION,pending.state);
        assertEquals("Quezon City",pending.proposedLocality);
        Booking expanded=new Booking("San Mateo", "Paltok, Quezon City", 120, Double.NaN, .90f, 3);
        LocationVerificationManager.Result verified=LocationVerificationManager.evaluate(reference,expanded);
        assertEquals(LocationVerificationManager.State.VERIFIED,verified.state);
        assertEquals("Quezon City",verified.proposedLocality);
    }

    @Test public void riderConfirmedPaltokFullHierarchyBecomesVerified() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"1300000000\",\"name\":\"National Capital Region (NCR)\",\"level\":\"Reg\",\"parentPsgc\":null},"
                +"{\"psgc\":\"1381300000\",\"name\":\"Quezon City\",\"level\":\"City\",\"parentPsgc\":\"1300000000\"},"
                +"{\"psgc\":\"1381300100\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"1381300000\"},"
                +"{\"psgc\":\"0301400000\",\"name\":\"Bulacan\",\"level\":\"Prov\",\"parentPsgc\":null},"
                +"{\"psgc\":\"0301404000\",\"name\":\"Angat\",\"level\":\"Mun\",\"parentPsgc\":\"0301400000\"},"
                +"{\"psgc\":\"0301404001\",\"name\":\"Paltok\",\"level\":\"Bgy\",\"parentPsgc\":\"0301404000\"}]}" );
        Booking reference=new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking confirmed=new Booking("San Mateo", "Paltok, Quezon City, National Capital Region (NCR)", 120, Double.NaN, .90f, 2);
        LocationVerificationManager.Result result=LocationVerificationManager.evaluate(reference,confirmed);
        assertEquals(LocationVerificationManager.State.VERIFIED,result.state);
        assertEquals("Paltok",result.destinationName);
        assertEquals("Quezon City",result.proposedLocality);
    }

    @Test public void ambiguousSanMateoWithoutParentContextDoesNotResolveInPsgc() throws Exception {
        PsgcDataset.loadJson("{\"records\":["
                +"{\"psgc\":\"0405800000\",\"name\":\"Rizal\",\"level\":\"Prov\",\"parentPsgc\":null},"
                +"{\"psgc\":\"0405811000\",\"name\":\"San Mateo\",\"level\":\"Mun\",\"parentPsgc\":\"0405800000\"},"
                +"{\"psgc\":\"0102805040\",\"name\":\"San Mateo\",\"level\":\"Bgy\",\"parentPsgc\":\"0102805000\"}]}" );
        assertNull(PsgcDataset.resolveLocation("San Mateo"));
        PsgcDataset.LocationResolution contextual=PsgcDataset.resolveLocation("San Mateo, Rizal");
        assertNotNull(contextual);
        assertEquals("Mun",contextual.localityRecord.level);
        assertEquals("San Mateo",contextual.localityRecord.name);
    }

    @Test public void fareComponentsRemainSeparate() {
        Booking b = new Booking("San Mateo", "Quezon Avenue", 184, 34, Double.NaN, .9f, 1, 2);
        assertEquals(184, b.baseFare, .001); assertEquals(34, b.additionalFare, .001);
        assertEquals(218, b.totalFare, .001); assertTrue(BookingValidator.isValid(b));
    }
    @Test public void displayedFarePairIsParsedIntoSeparateComponents() {
        BookingExtractor.FareComponents fare = BookingExtractor.parseFareComponents("₱184.00 + ₱34.00");
        assertNotNull(fare); assertEquals(184, fare.baseFare, .001);
        assertEquals(34, fare.additionalFare, .001); assertEquals(218, fare.totalFare, .001);
    }
    @Test public void accentAndCaseInsensitiveAliasesResolve() {
        assertNotNull(GeographicDataset.get("QC")); assertNotNull(GeographicDataset.get("quezon city"));
        assertNotNull(GeographicDataset.get("Sta. Rosa"));
        assertEquals("dasmarinas", BookingValidator.normalize("Dasmariñas"));
    }
    @Test public void unknownOrUnverifiedCoordinatesRemainUnresolved() {
        assertNull(GeographicDataset.get("Imaginary Municipality"));
        assertNull(GeographicDataset.get("Puerto Princesa"));
    }
    @Test public void differentPickupCanBeAlongTheWay() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .9f, 1);
        Booking candidate = new Booking("Batasan", "Diliman", 80, Double.NaN, .9f, 1);
        assertNotNull(new RouteCompatibilityEngine().evaluate(ref, candidate));
    }
    @Test public void incompleteBookingRejected() {
        assertFalse(BookingValidator.isValid(new Booking("", "Quezon Avenue", 100, Double.NaN, .9f, 1)));
    }
    @Test public void fareTotalMustEqualSeparatedComponents() {
        Booking b = new Booking("San Mateo", "Quezon Avenue", 184, 34, Double.NaN, .9f, 1, 2);
        b.totalFare = 199;
        assertFalse(BookingValidator.isValid(b));
    }
    @Test public void recommendationUsesPickupBeforeDropoffSequence() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking extra = new Booking("Batasan", "Diliman", 80, Double.NaN, .90f, 2);
        List<RecommendationEngine.Recommendation> results =
                new RecommendationEngine().recommend(Arrays.asList(ref, extra), ref);
        assertFalse(results.isEmpty());
        assertTrue(results.get(0).sequence.indexOf("PICKUP Batasan") < results.get(0).sequence.indexOf("DROP Diliman"));
        assertEquals(264, results.get(0).totalFare, .001);
        assertTrue(results.get(0).areaActivityScore >= 0d && results.get(0).areaActivityScore <= 1d);
    }
    @Test public void geographicIntelligenceBuildsLocalBookingHotspotsWithoutInventingCoordinates() {
        Booking known = new Booking("Quezon City", "Makati", 150, Double.NaN, .9f, 1);
        Booking unknown = new Booking("Unknown Place", "Antipolo", 120, Double.NaN, .9f, 2);
        GeographicIntelligence.Analysis analysis = GeographicIntelligence.analyze(Arrays.asList(known, unknown));
        assertEquals(2, analysis.bookingCount);
        assertEquals(4, analysis.pickupStops + analysis.dropoffStops);
        assertTrue(analysis.mappedStops >= 3);
        assertTrue(analysis.unresolvedStops >= 1);
        assertFalse(analysis.hotspots.isEmpty());
        assertTrue(analysis.hotspots.get(0).mappable);
    }

    @Test public void bookingCodeChangesFingerprint() {
        Booking b = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        String before = b.fingerprint; b.setBookingCode("LM12345");
        assertNotEquals(before, b.fingerprint);
        assertEquals("LM12345", b.bookingCode);
    }

    @Test public void visibleBookingCodesPreventFalseDedupOfIdenticalRoutes() {
        Booking first = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking second = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 2);
        first.setBookingCode("LM12345"); second.setBookingCode("LM12346");
        assertNotEquals(first.fingerprint, second.fingerprint);
    }

    @Test public void recommendationExplanationDisclosesEstimateBasis() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking extra = new Booking("Batasan", "Diliman", 80, Double.NaN, .90f, 2);
        List<RecommendationEngine.Recommendation> results = new RecommendationEngine().recommend(Arrays.asList(ref, extra), ref);
        assertFalse(results.isEmpty());
        assertTrue(results.get(0).explanation.contains("straight-line estimate"));
    }

    @Test public void geographicIntelligenceHandlesEmptyHistory() {
        GeographicIntelligence.Analysis analysis = GeographicIntelligence.analyze(java.util.Collections.emptyList());
        assertEquals(0, analysis.bookingCount);
        assertTrue(analysis.hotspots.isEmpty());
    }

    @Test public void referenceBookingIsNotReplacedByDuplicateCandidate() {
        Booking ref = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 1);
        Booking duplicate = new Booking("San Mateo", "Quezon Avenue", 184, Double.NaN, .95f, 2);
        assertEquals(ref.fingerprint, duplicate.fingerprint);
        assertEquals(ref.id, duplicate.id);
    }
    @Test public void referenceFreeModeFindsSimilarAvailableBookingRoutes() {
        Booking quezonAve=new Booking("San Mateo","Quezon Avenue",281,Double.NaN,.92f,1000);
        Booking batasan=new Booking("San Mateo","Batasan",210,Double.NaN,.88f,1000);
        List<RecommendationEngine.Recommendation> suggestions=
                new RecommendationEngine().recommendWithoutReference(Arrays.asList(quezonAve,batasan));
        assertEquals(1,suggestions.size());
        assertTrue(suggestions.get(0).compatibility.contains("COMPATIBLE")
                || suggestions.get(0).compatibility.contains("SIMILARITY"));
        assertEquals(491d,suggestions.get(0).totalFare,.001d);
        assertTrue(suggestions.get(0).explanation.contains("No accepted reference booking yet"));
    }

    @Test public void referenceFreeModeDoesNotInventRoutesWithoutCoordinates() {
        Booking unresolvedA=new Booking("Unknown Barangay A","Unknown Destination A",100,Double.NaN,.9f,1000);
        Booking unresolvedB=new Booking("Unknown Barangay B","Unknown Destination B",120,Double.NaN,.9f,1000);
        assertTrue(new RecommendationEngine().recommendWithoutReference(Arrays.asList(unresolvedA,unresolvedB)).isEmpty());
    }

}
