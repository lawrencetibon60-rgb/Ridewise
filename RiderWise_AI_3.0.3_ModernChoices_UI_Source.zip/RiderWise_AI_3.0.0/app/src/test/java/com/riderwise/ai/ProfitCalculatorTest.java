package com.riderwise.ai;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Collections;
public class ProfitCalculatorTest {
    @Test public void unavailableInputsRemainUnavailable() {
        assertTrue(Double.isNaN(ProfitCalculator.estimatedFuelCost(Double.NaN,60,40)));
        assertTrue(Double.isNaN(ProfitCalculator.earningsPerHour(200,Double.NaN)));
    }
    @Test public void fuelCostUsesConfigurableInputs() {
        assertEquals(30,ProfitCalculator.estimatedFuelCost(20,60,40),.001);
    }
    @Test public void resultSeparatesFareComponentsAndNetEstimate() {
        Booking b=new Booking("San Mateo","Quezon Avenue",184,34,Double.NaN,.9f,1,2);
        ProfitCalculator.Result r=ProfitCalculator.calculate(Collections.singletonList(b),20,1,60,40,3);
        assertEquals(218,r.combinedFare,.001); assertEquals(184,r.baseFare,.001);
        assertEquals(34,r.additionalFare,.001); assertEquals(30,r.fuelCost,.001);
        assertEquals(188,r.netEarnings,.001); assertEquals(3,r.detourKm,.001);
    }
}
