# RiderWise AI 3.0 — Master Brain, Lalamove UI-Aware Booking Intelligence & Advanced Offline AI

This source package is an upgrade of the supplied RiderWise AI v2.8.4 project. It is a **source-code release candidate**, not a verified installable APK.

## Release identity

- Android `versionCode`: 18
- Android `versionName`: `3.0.0`
- Developer configuration target: `3.0.0`
- Database schema: version 6 (adds persistent seen-count tracking while retaining existing booking history)
- OCR scan interval: 2,500 ms
- AI architecture: Advanced Offline AI (no online AI API)

## 3.0 Lalamove dynamic booking intelligence (new)

- Treat the visible list as a moving window over a larger available-booking queue: only visible cards are OCR-scanned; scrolling reveals additional cards for later scans.
- Persist unique detected bookings for seven days (up to 500 records in the recommendation/history query), rather than keeping only the current screen.
- Keep `first_seen` stable when a booking reappears. Existing rows are updated in place (not deleted/reinserted), and a per-booking `seen_count` tracks repeated appearances.
- Sort history by original first-seen time, with same-frame rows retaining their original top-to-bottom insertion order. A resurfaced old booking is reported as previously seen, not a newly discovered booking.
- In each OCR frame, use one shared timestamp so cards on the same screen preserve their visible order.
- Recognize bare PSGC place names such as `San Mateo` even without `PICKUP`/`DROPOFF` labels; ambiguous names are retained as text for later verification rather than silently discarded or auto-resolved.
- On expanded booking screens, group a location heading with nearby comma-rich address detail lines so the pickup address is not mistaken for the drop-off endpoint.
- Reconcile a collapsed card with its expanded full-address view only when one unique record matches pickup, fare, address containment, and any visible booking-code constraint.
- When no accepted reference exists, run a reference-free pair analysis across the accumulated available-booking history. It suggests pairs with nearby pickup and drop-off areas, subject to known local coordinates and vehicle compatibility. These are route-similarity suggestions, not a claim that Lalamove permits combining orders.
- When an accepted reference exists, continue using the reference-based recommendation engine.
- The scanner remains read-only. It does not scroll the Lalamove list, tap cards, or accept/reject orders. The driver scrolls manually; RiderWise records each screen it actually captures.

**Important limitation:** A 2.5-second scan cadence cannot guarantee capture of every card if the driver scrolls faster than the OCR cycle. Scroll at a pace that lets each screen remain visible for at least one scan. Missed screens cannot be reconstructed from the list total alone.

## Implemented in this source update

### 1. OCR and booking extraction

- Set the configured continuous scan interval to 2.5 seconds.
- Continue scanning only during an explicitly authorized MediaProjection session; no auto-scroll or touch injection is performed.
- Keep a single-flight OCR guard to prevent overlapping ML Kit jobs.
- Split visible cards using detected orange header positions, booking headers, and vertical card gaps.
- Extract pickup/drop-off labels and attempt address-line inference when labels are absent.
- Parse displayed fare, additional fare, OCR-reported distance, vehicle type, and booking type where readable.
- Track partial/incomplete card candidates separately; incomplete candidates are not stored as complete bookings.
- Use visible booking codes in fingerprints when the screen exposes them, reducing false deduplication of otherwise identical jobs.
- Retry an unchanged frame after OCR failure rather than permanently skipping that frame.
- Preserve local database accumulation across scrolls and repeated scans.

**Important:** The 2.5-second interval is a requested scan cadence, not a guarantee that OCR completes every 2.5 seconds. Device load, image acquisition, and ML Kit processing can delay a cycle. The current extractor still needs validation against real Lalamove screen captures from different layouts and screen sizes.

### 2. Floating dashboard

- Keep drag-to-move header behavior.
- Make the two bottom corner grips resize both width and the scrollable content height.
- Persist width and content height in SharedPreferences so they survive hide/show and service restart.
- Scale dashboard text with width.
- Toggle resize controls with the expanded/collapsed state.
- Restore dashboard visibility after every screenshot acquisition exit path and when capture resources stop.

### 3. Accepted booking intelligence

- Preserve the explicit acceptance success-banner requirement.
- Preserve accepted-booking history and first-reference protection.
- Preserve manual replace-reference and clear-reference controls.
- Use a visible booking identifier in the accepted booking fingerprint when available.

### 4. Recommendations and Ride Mode

- Ride Mode OFF now suppresses ride-based recommendations.
- Ride Mode ON uses the saved accepted booking reference.
- Keep pickup-before-dropoff sequence search and vehicle-type mismatch filtering when both vehicle types are known.
- Display a 0–100 recommendation score and a short explanation of route fit, OCR confidence, and local pickup-history signal.
- Display fare per OCR-reported kilometre only when the OCR distance is available.
- Explicitly label route/detour calculations as straight-line geographic estimates, never as road distance or travel time.

### 5. Geographic intelligence (Luzon scope)

- Preserve the bundled PSA PSGC 3Q 2026 gzip dataset and JSON fallback loader.
- Preserve validation of the 21,330 administrative records and parent links.
- Resolve a unique barangay name (including `Brgy. Tatalon`) to its exact PSGC barangay record and parent city/municipality.
- Resolve full addresses such as `Tatalon, Quezon City` while checking that recognized administrative tokens belong to the same hierarchy; conflicting or ambiguous names remain unresolved.
- Preserve the exact barangay match separately from its parent locality, so the app does not claim that a city centroid is a barangay coordinate.
- Permit coarse city-level geographic comparison only when a parent city/municipality coordinate entry exists; route labels carry `(CITY-LEVEL APPROX.)` and explicitly disclose straight-line centroid estimates.
- Keep the local booking-area frequency analysis and only emit map coordinates where a coordinate entry exists.
- Use the existing approximate city/area centroids with their unverified status clearly retained.
- Add reference-aware candidate ranking for duplicate barangay names: the accepted reference destination can suggest one plausible parent locality, but the suggestion is never treated as confirmed.
- Surface duplicate-name candidates (such as `Paltok`) as `POTENTIALLY COMPATIBLE` only when pickup text matches the accepted reference pickup; show the suggested parent locality as an inference and ask the rider to open the Lalamove card manually.
- Keep ambiguous inferred matches out of final route scoring. When a later OCR scan reads the expanded address (for example, `Paltok, Quezon City`), resolve the parent city directly, label it verified, and then run a city-level approximate route comparison. No tap, click, auto-scroll, or booking acceptance is performed.

**Coverage limitation:** The bundled PSGC file covers NCR, CAR, Regions I, II, III, IV-A, MIMAROPA, and V. It is not a nationwide PSGC release. The PSGC dataset contains administrative names and identifiers, not coordinates, road geometry, barangay polygons, traffic, or delivery-service boundaries.

### 6. Advanced Offline AI

- Local ML Kit OCR and deterministic booking/route validation remain authoritative.
- `LiteRtLocalAnalyzer` runs the on-device model and ranks only the best eight combinations already accepted by deterministic validation.
- AI ranking considers route fit, straight-line detour estimate, OCR confidence, vehicle/booking type and saved driver preferences. It can reorder supplied options only; it cannot change fare, distance, coordinates, OCR fields, booking validity or hard constraints.
- `OfflineAiCoordinator` provides a local-only orchestration path. If the model is absent or fails, deterministic recommendations remain active.
- The model is downloaded only after a user action into app-private storage; it is not bundled in the APK.
- No Gemini client, online AI endpoint, API-key storage or online AI consent flow remains. Internet access is retained solely for the one-time model download.
- AI ranking is requested when the validated recommendation set changes, not on every 2.5-second OCR scan.

**Device limitation:** The configured Gemma 4 E2B artifact is approximately 2.6 GB. The target phone's 8 GB RAM does not guarantee smooth inference. The exact model/runtime compatibility, full Android build, actual model load/inference and Oppo Reno 5 performance still require verification. See `docs/OFFLINE_AI_IMPLEMENTATION.md`.

## Preserved existing functionality

- Screen-capture permission flow and read-only monitoring
- ML Kit OCR dependency
- Accepted-booking reference/history storage
- Existing booking store and legacy database migration path
- Dark Mode preference
- Floating dashboard service and controls
- Existing profit calculator and PSGC fallback resources

## Not completed / requires further work

- Verified barangay polygon boundaries and barangay-level coordinates
- A true interactive Philippine basemap and visual map heatmap
- Complete Luzon road geometry and turn-by-turn road routing
- Live traffic and ETA provider
- Live Lalamove server-side service coverage or private order-demand data
- Full validation on real Lalamove APK screens and physical Android devices

The current local hotspot report is a **booking-history frequency summary**, not a live demand forecast. Where approximate city centroids are used, they must not be interpreted as exact pickup/drop-off pins. For a barangay-only match such as Tatalon, the routing fallback is only the parent Quezon City locality; it does not know the precise barangay coordinate or road route. Any route label carries `(CITY-LEVEL APPROX.)` when a parent-locality fallback is used.

For duplicate barangay names such as **Paltok** (Quezon City and Angat, Bulacan), the reference-aware resolver may suggest a parent locality (for example, Quezon Avenue → Quezon City), but the dashboard keeps it as `POTENTIALLY COMPATIBLE` with a warning. The rider must manually open the booking card; only a subsequent OCR scan containing the full locality-bearing address can verify it and allow route scoring. This confirmation is still a city-level approximation when coordinates come from a city centroid, not an exact barangay route.

## Build and verification status

- `tools/verify_psgc.py`: PASS — 21,330 records; PSGC identifiers and parent links are internally consistent; the PSA source has no coordinates.
- `OfflineAiCoordinator` and `Booking`: Java 17 syntax/type check PASS.
- `LiteRtLocalAnalyzer.kt`: Kotlin syntax/type check PASS against API-shaped local stubs; actual LiteRT-LM AAR compatibility is not verified.
- PSGC dataset inspection confirms `Paltok` occurs twice in the bundled data: Quezon City and Angat, Bulacan. New JUnit cases cover the pending-verification → full-address-confirmed workflow; the tests have not been executed in this environment.
- Full Android Gradle build and unit-test task: **not run successfully**. The Gradle wrapper could not download Gradle 8.9 because `services.gradle.org` was unreachable in the build environment. No APK is claimed as built or tested.
- Real-device checks still required: 1-card/3-card OCR, scrolling, duplicate suppression, partial cards, accepted reference, Ride Mode OFF/ON, dashboard corner resizing, hide/show persistence, permission revocation, and Dark Mode contrast.

## Build locally

Use Android Studio with JDK 17, Android SDK 35, and network access for Gradle/plugin dependencies. Open this project folder and run the unit tests before installing the debug APK on a test device.

The app remains read-only: it does not accept, reject, tap, or auto-scroll Lalamove bookings.

## Advanced Offline AI (3.0.0)

RiderWise AI uses a local LiteRT-LM model to rank pre-validated booking combinations. OCR, fare calculations, geographic verification and hard compatibility rules remain deterministic. No online AI API or cloud fallback is included.

- The configured Gemma 4 E2B model is downloaded separately (about 2.6 GB) after user confirmation.
- Internet is needed for that initial download only; local inference runs on-device after installation.
- If the model is unavailable, normal OCR and deterministic recommendations continue.
- Device memory, speed, heat and battery performance must be tested on the target Oppo Reno 5.

See `docs/OFFLINE_AI_IMPLEMENTATION.md` for the validation boundary and limitations.


## 3.0.2 — Persistent recommendation review integration

- The floating dashboard now has a **Saved (N)** control when the dashboard is expanded and interactive.
- Saved recommendation entries can be opened to review their description, score, first-seen time, last-recommended time, and availability evidence.
- A driver can dismiss a recommendation or archive it after accepting it manually in Lalamove. Archiving in RiderWise does not interact with Lalamove and does not automatically set the accepted reference.
- Saved entries are retained locally; entries not refreshed by the latest recommendation pass are labelled as not re-confirmed rather than being treated as expired or currently available.
- The queue remains advisory: off-screen recommendations must be manually found and their current availability checked in Lalamove.

### Validation status for this source update

- ZIP structure and required source files: checked.
- Java source edits: inspected.
- Full Gradle compilation: **not completed**. The wrapper attempted to download Gradle 8.9 and failed with `UnknownHostException: services.gradle.org`.
- APK generation and Oppo Reno 5 / live Lalamove testing: **not completed**.
