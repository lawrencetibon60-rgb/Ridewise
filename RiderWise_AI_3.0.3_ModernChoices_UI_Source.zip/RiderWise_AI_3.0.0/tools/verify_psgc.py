#!/usr/bin/env python3
"""Validate the bundled Luzon PSGC 3Q 2026 asset without third-party packages."""
import collections, gzip, json, pathlib, sys
asset = pathlib.Path(__file__).resolve().parents[1] / "app/src/main/assets/luzon_psgc_3q_2026.json.gz"
with gzip.open(asset, "rt", encoding="utf-8") as f:
    root = json.load(f)
records = root.get("records", [])
expected = {"Reg": 8, "Prov": 38, "City": 77, "Mun": 694, "SubMun": 14, "Bgy": 20499}
counts = collections.Counter(r.get("level") for r in records)
assert root.get("source", "").startswith("Philippine Statistics Authority"), "Unexpected source metadata"
assert root.get("publicationDate") == "2026-09-30", "Unexpected publication date"
assert root.get("recordCount") == 21330 == len(records), "Record count mismatch"
assert dict(counts) == expected, f"Level counts mismatch: {dict(counts)}"
codes = {r["psgc"] for r in records}
assert len(codes) == len(records), "Duplicate PSGC codes"
missing = [r["psgc"] for r in records if r.get("parentPsgc") and r["parentPsgc"] not in codes]
assert not missing, f"Missing parent codes: {missing[:5]}"
assert all(r.get("name") and r.get("level") and r.get("psgc") for r in records), "Incomplete record"
print("PSGC validation PASS")
print(f"{len(records):,} records | {dict(counts)}")
print("PSGC identifiers and parent links are internally consistent.")
print("Coordinates are not included in the PSA source and are not fabricated.")
